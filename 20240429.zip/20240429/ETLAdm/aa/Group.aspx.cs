﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.util;
using gbs.bao.etl.bo;
using gbs.bao.etl.entity;
using gbs.bao.etl.dao;

namespace ETLAdm.aa
{
    public partial class Group : EtlAdmPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ObjectDataSource3_selectProject.SelectParameters[0].DefaultValue = UserName;
                ObjectDataSource3_selectProject.SelectParameters[1].DefaultValue = this.Project_Id + "";
                ObjectDataSource5_selectFTP.SelectParameters[0].DefaultValue = this.Project_Id + "";
                TreeView_DataBind(-1);
                toggle(false);
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "showTbl", "$(function(){{ $('#tbl_ETLGRP').removeClass('hide'); }});", true);
                if (ddlProject.SelectedIndex != 0)
                {
                    ObjectDataSource5_selectFTP.SelectParameters[0].DefaultValue = ddlProject.SelectedValue;
                }
            }
        }

        private void TreeView_DataBind(int apId)
        {
            TreeView1.Nodes.Clear();

            GroupBO bo = new GroupBO();
            bo.UserName = this.UserName;
            bo.TreeViewBinding(TreeView1, apId, this.Project_Id, this.UserName);
        }

        private void toggle(bool b)
        {
            ddlProject.Visible = b;
            cbxRoles.Visible = b;
            pnlButtons.Visible = b;
        }

        protected void user_name_Click(object sender, EventArgs e)
        {
            LinkButton btn = sender as LinkButton;
            tbxUserAccount.Text = (sender as LinkButton).CommandArgument;
            hdnApId.Value = "-1";
            ddlProject.SelectedIndex = 0;
            ddlProject_SelectedIndexChanged(ddlProject, e);
            cbxRoles.Items.Clear();
            lbxFTPs.Items.Clear();
            lFTPServer.Visible = false;
            lbxFTPs.Visible = false;
            toggle(true);
        }

        public void TreeView1_SelectedNodeChanged(object sender, EventArgs e) // cssfriendly must using public
        {
            if (ddlProject.Items.Count < 2)
            {
                ddlProject.DataBind();
            }
            TreeView treeview = sender as TreeView;
            TreeNode node = treeview.SelectedNode;
            hdnApId.Value = treeview.SelectedValue;
            int apId = Convert.ToInt32(treeview.SelectedValue);            
            cbxRoles_DataBind(apId);
            toggle(true);
        }

        private void cbxRoles_DataBind(int apId)
        {
            using (GroupDAO dao = new GroupDAO())
            using (FTPUserDAO ftpDao = new FTPUserDAO())
            {
                ETLGRP grp = dao.selectGroupsByApId(apId);

                if (grp == null)
                {
                    cbxRoles_DataBind(dao, -1, string.Empty);
                    lbxFTPs_DataBind(ftpDao, -1, string.Empty);
                }
                else
                {
                    tbxUserAccount.Text = grp.USR_NAME;
                    ddlProject.SelectedValue = grp.PRJ_ID.ToString();
                    ddlProject_SelectedIndexChanged(ddlProject, new EventArgs());
                    cbxRoles_DataBind(dao, grp.PRJ_ID, grp.USR_NAME);
                    lbxFTPs_DataBind(ftpDao, grp.PRJ_ID, grp.USR_NAME);
                }
            }
        }

        private void cbxRoles_DataBind(GroupDAO dao, int prj_id, string usr_name)
        {
            foreach (ListItem item in cbxRoles.Items)
            {
                item.Selected = false;
            }
            foreach (var v in dao.selectGroupsByUser(prj_id, usr_name))
            {
                ListItem item = cbxRoles.Items.FindByValue(v.GRP_NAME);
                if (item != null)
                {
                    item.Selected = true;
                }
                else
                {
                    logger.Warn(string.Format("prj_id={0}, usr_name={1}, GRP_NAME={2} not found.", prj_id, usr_name, v.GRP_NAME));
                }
            }
        }

        private void lbxFTPs_DataBind(FTPUserDAO dao, int prj_id, string usr_name)
        {
            lbxFTPs.Rows = lbxFTPs.Items.Count > 2 ? 3 : lbxFTPs.Items.Count == 0 ? 1 : lbxFTPs.Items.Count;

            foreach (ListItem item in lbxFTPs.Items)
            {
                item.Selected = false;
            }
            
            foreach (var v in dao.selectFTPs(prj_id, usr_name))
            {
                ListItem item = lbxFTPs.Items.FindByText(v.SVR_NAME);
                if (item != null)
                {
                    item.Selected = true;
                    //cbxFTP.Checked = true;
                }
                else
                {
                    logger.Warn(string.Format("prj_id={0}, VAR_NAME={1} not found.", prj_id, v.SVR_NAME));
                }
            }
        }

        protected void ddlProject_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbxRoles.Items.Clear();
            cbxRoles.DataBind();
            lbxFTPs.Items.Clear();
            lbxFTPs.DataBind();
            //cbxFTP.Checked = false;

            //List<ListItem> removes = new List<ListItem>();
            // ddlProject [{value=0 , text=SYSADM} , {value=1, text=xxx}]
            // cbxRoles [{value=SYSADM, text=系統管理群組}]
            //foreach (ListItem item in cbxRoles.Items)
            //{
            //    if ( ddlProject.SelectedValue == "0" && (!"SYSADM".Equals(item.Value)))
            //    {
            //        removes.Add(item);
            //    }
            //    if (ddlProject.SelectedValue != "0" && "SYSADM".Equals(item.Value))
            //    {
            //        removes.Add(item);
            //    }
            //    if (ddlProject.SelectedIndex == 0)
            //    {
            //        removes.Add(item);
            //    }
            //}
            //for (int i = 0; i < removes.Count(); i++)
            //{
            //    cbxRoles.Items.Remove(removes[i]);
            //}

            if (!"".Equals(tbxUserAccount.Text) && ddlProject.SelectedIndex != 0)
            {
                using (GroupDAO dao = new GroupDAO())
                using (FTPUserDAO ftpDao = new FTPUserDAO())
                {
                    cbxRoles_DataBind(dao, Convert.ToInt32(ddlProject.SelectedValue), tbxUserAccount.Text);
                    lbxFTPs_DataBind(ftpDao, Convert.ToInt32(ddlProject.SelectedValue), tbxUserAccount.Text);
                    lbxFTPs.Visible = true;
                    lFTPServer.Visible = true;
                }
            }

            //if ((tbxUserAccount.Text.Equals("etladm") && ddlProject.SelectedValue == "0") || ddlProject.SelectedIndex==0)
            //{
            //    if(cbxRoles.Items.Count>0)
            //        cbxRoles.Items[0].Enabled = false;
            //    btnOk.Enabled = false;
            //    btnDelete.Enabled = false;
            //    btnClear.Enabled = false;
            //}
            //else
            //{
                btnOk.Enabled = true;
                btnDelete.Enabled = true;
                btnClear.Enabled = true;
            //}
        }

        protected void check_FTP(object sender, EventArgs e)
        {
            CheckBox cbx = sender as CheckBox;

            if (!cbx.Checked)
            {
                foreach (ListItem item in lbxFTPs.Items)
                {
                    item.Selected = false;
                }
            }
        }

        protected void btnOk_Click(object sender, EventArgs e)
        {
            int apId = Int32.TryParse(hdnApId.Value, out apId) ? apId : -1;
            int prj_id = Convert.ToInt32(ddlProject.SelectedValue);
            string user_name = tbxUserAccount.Text;

            FTPUserBO ftpBo = new FTPUserBO();
            ftpBo.UserName = this.UserName;
            List<FTPUSD> ftps = new List<FTPUSD>();

            foreach (ListItem item in lbxFTPs.Items)
            {
                if (item.Selected)
                {
                    ftps.Add(new FTPUSD() { PRJ_ID = prj_id, SVR_NAME = item.Text, USR_NAME = user_name });
                }
            }

            ResultBean ftpResult = setMessage(ftpBo.mergeFTPUser(prj_id, user_name, ftps));

            GroupBO bo = new GroupBO();
            bo.UserName = this.UserName;

            List<ETLGRP> grps = new List<ETLGRP>();
            foreach (ListItem item in cbxRoles.Items)
            {
                if (item.Selected)
                {
                    grps.Add(new ETLGRP() { PRJ_ID = prj_id, USR_NAME = user_name, GRP_NAME = item.Value });
                }
            }

            ResultBean result = setMessage(bo.mergeGroup(prj_id, user_name, grps, new SeqBO()));

            if (result.success && ftpResult.success)
            {
                TreeView_DataBind(apId);
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            int prj_id = Convert.ToInt32(ddlProject.SelectedValue);
            FTPUserBO ftpBo = new FTPUserBO();
            ftpBo.deleteFTPUser(prj_id, tbxUserAccount.Text);

            GroupBO bo = new GroupBO();
            bo.UserName = this.UserName;
            ResultBean result = setMessage(bo.removeGroupALL(prj_id, tbxUserAccount.Text));
            if (result.success)
            {
                TreeView_DataBind(-1);
                ddlProject_SelectedIndexChanged(ddlProject, e);
            }
        }

        protected void cbxRoles_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (ListItem checkBox in cbxRoles.Items)
            {
                if (checkBox.Value.Equals("VADFTP"))
                {
                    if (checkBox.Selected)
                    {
                        using (FTPUserDAO ftpDao = new FTPUserDAO())
                        {
                            lbxFTPs_DataBind(ftpDao, Convert.ToInt32(ddlProject.SelectedValue), tbxUserAccount.Text);
                        }

                        lbxFTPs.Visible = true;
                        lFTPServer.Visible = true;
                    }
                    else
                    {
                        foreach (ListItem item in lbxFTPs.Items)
                        {
                            item.Selected = false;
                        }

                        lbxFTPs.Visible = false;
                        lFTPServer.Visible = false;
                    }
                }
            }
        }
    }
}
