﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Script.Services;
using System.Web.Script.Serialization;

using NLog;
using System.Runtime.Serialization;

namespace ETLAdm.aa
{
    /// <summary>
    /// AAService 的摘要描述
    /// </summary>
    [WebService(Namespace = "http://gbs.bao.etl/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]    
    [System.Web.Script.Services.ScriptService]
    public class AAService : System.Web.Services.WebService
    {
        static Logger logger = LogManager.GetCurrentClassLogger();

        [WebMethod]
        [ScriptMethod(ResponseFormat= ResponseFormat.Json)]
        public void HelloWorld()
        {
            HttpResponse response = this.Context.Response;
            JavaScriptSerializer js = new JavaScriptSerializer();
            Dictionary<string, object> result = new Dictionary<string, object>();
            try
            {
                string inputUser = this.Context.Request.Form["data"];
                
                InputUser user = js.Deserialize<InputUser>(inputUser);
                
                string str = "hello, " + user.firstname + "," + user.lastname;
                
                result["data"] = str;
                result["st"] = true;
                result["message"] = "ok";                
            }
            catch (Exception ex)
            {
                result["st"] = false;
                result["message"] = "系統異常";
                logger.ErrorException(ex.Message, ex);
                result["data"] = "{}";
            }
            
            result["sysdate"] = DateTime.Now;
            response.ContentType = "application/json; charset=utf-8";            
            response.Write(new JavaScriptSerializer().Serialize(result));            
        }
        [WebMethod]
        [ScriptMethod(ResponseFormat=ResponseFormat.Json)]
        public void CheckTime()
        {
            HttpResponse response = this.Context.Response;
            JavaScriptSerializer js = new JavaScriptSerializer();
            Dictionary<string, object> result = new Dictionary<string, object>();
            try
            {
                string inputUser = this.Context.Request.Form["data"];

                ClientTime user = js.Deserialize<ClientTime>(inputUser);

                DateTime b = DateTime.Now.AddMinutes(-5);
                DateTime e = DateTime.Now.AddMinutes(5);

                bool rtn = user.now >= b && user.now <= e;

                result["data"] = rtn;
                result["st"] = true;
                result["message"] = "ok";
            }
            catch (Exception ex)
            {
                result["st"] = false;
                result["message"] = "系統異常";
                result["data"] = "{}";
                logger.ErrorException(ex.Message, ex);
            }

            result["sysdate"] = DateTime.Now;
            response.ContentType = "application/json; charset=utf-8";
            response.Write(new JavaScriptSerializer().Serialize(result));           
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public void Chinese()
        {
            HttpResponse response = this.Context.Response;
            JavaScriptSerializer js = new JavaScriptSerializer();
            Dictionary<string, object> result = new Dictionary<string, object>();
            try
            {               

                string inputUser = this.Context.Request.Form["data"];

                InputUser user = js.Deserialize<InputUser>(inputUser);
                
                string str = "hello, " + user.firstname + "," + user.lastname;

                result["data"] = str;
                result["st"] = true;
                result["message"] = "ok";
            }
            catch (Exception ex)
            {
                result["st"] = false;
                result["message"] = "系統異常";
                result["data"] = "{}";
                logger.ErrorException(ex.Message, ex);
            }

            result["sysdate"] = DateTime.Now;
            response.ContentType = "application/json; charset=utf-8";
            response.Write(new JavaScriptSerializer().Serialize(result));
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public void ThrowException()
        {
            HttpResponse response = this.Context.Response;
            JavaScriptSerializer js = new JavaScriptSerializer();
            Dictionary<string, object> result = new Dictionary<string, object>();
            try
            {
                throw new Exception("unknow error");
            }
            catch (Exception ex)
            {
                result["st"] = false;
                result["message"] = "系統異常";
                result["data"] = "{}";
                logger.ErrorException(ex.Message, ex);
            }

            result["sysdate"] = DateTime.Now;
            response.ContentType = "application/json; charset=utf-8";
            response.Write(new JavaScriptSerializer().Serialize(result));
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public void Array()
        {
            HttpResponse response = this.Context.Response;
            JavaScriptSerializer js = new JavaScriptSerializer();
            Dictionary<string, object> result = new Dictionary<string, object>();
            try
            {
                string inputUser = this.Context.Request.Form["data"];

                ArrayObject user = js.Deserialize<ArrayObject>(inputUser);

                string str = "hello, " + user.array[0].firstname + "," + user.array[0].lastname
                     + user.array[1].firstname + "," + user.array[1].lastname;

                result["data"] = str;
                result["st"] = true;
                result["message"] = "ok";                
            }
            catch (Exception ex)
            {
                result["st"] = false;
                result["message"] = "系統異常";
                result["data"] = "{}";
                logger.ErrorException(ex.Message, ex);
            }

            result["sysdate"] = DateTime.Now;
            response.ContentType = "application/json; charset=utf-8";
            response.Write(new JavaScriptSerializer().Serialize(result));
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public void SendObject(string input)
        {
            HttpResponse response = this.Context.Response;
            JavaScriptSerializer js = new JavaScriptSerializer();
            Dictionary<string, object> result = new Dictionary<string, object>();
            try
            {
                result["st"] = true;
                result["message"] = "ok";
                result["data"] = input;
            }
            catch (Exception ex)
            {
                result["st"] = false;
                result["message"] = "系統異常";
                result["data"] = "{}";
                logger.ErrorException(ex.Message, ex);
            }

            result["sysdate"] = DateTime.Now;
            response.ContentType = "application/json; charset=utf-8";
            response.Write(js.Serialize(result));
        }                
        
    }

    
    public class InputUser 
    {
        public string firstname, lastname;
    }
    public class ClientTime
    {
        public DateTime now;
    }

    public class ArrayObject
    {
        public List<InputUser> array;
    }
}
