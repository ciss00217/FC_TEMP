﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.util;
using gbs.bao.etl.dao;
using gbs.bao.etl.entity.proxy;
using gbs.bao.etl.bo;
using gbs.bao.etl.entity;
using System.Xml;
using System.IO;
using System.Text;
using System.Xml.Serialization;
using gbs.bao.etl.entity.deploy;
using System.Drawing;

namespace ETLAdm.setting
{
    public partial class FrequencyImport : EtlAdmPage
    {
        protected override void Page_Init(object sender, EventArgs e)
        {
            base.Page_Init(sender, e);
            ((SiteMaster)Page.Master).HideTop1 = true;
            ((SiteMaster)Page.Master).HideLeft1 = true;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                
            }
        }

        protected void Wizard1_NextButtonClick(object sender, WizardNavigationEventArgs e)
        {
            int idx = e.CurrentStepIndex;
           
            switch (idx)
            {
                case 0:
                    if (FileUpload1.HasFile)
                    {
                        
                        string fileExt = System.IO.Path.GetExtension(FileUpload1.FileName);
                        if (".XML".Equals(fileExt, StringComparison.OrdinalIgnoreCase))
                        {
                            ResultBean result = IOUtility.Save(Server, FileUpload1);
                            if (result.success)
                            {
                                GridView1_DataBind(result);
                            }
                            else
                            {
                                setMessage(result);
                                e.Cancel = true;
                            }
                        }
                    }
                    break;
            }
            
        }

        private void GridView1_DataBind(ResultBean result)
        {
            string path = result.data.ToString();
            Path.Value = Convert.ToBase64String(Encoding.Default.GetBytes(path));
            IETLRepository bean = IOUtility.FromXml<IETLRepository>(path);

            GridView1.DataSource = bean.IETLJFQs;
            GridView1.DataBind();
        }

        protected void Wizard1_FinishButtonClick(object sender, WizardNavigationEventArgs e)
        {
            List<string> messages = new List<string>();
            string currentStep = "";
            string prcsId = DateTime.Now.ToString("yyyyMMddHHmmss");
            Dictionary<string, object> prcs = InitInjectValues(prcsId);
            try
            {   
                currentStep = "讀取匯入檔";
                messages.Add("1. 開始" + currentStep);
                IETLRepository bean = ReadFromXml();
                messages.Add("=>" + DateTime.Now.ToString("HH:mm:ss") + " 成功...");

                currentStep = "讀取執行週期";
                messages.Add("　1-1. 開始" + currentStep);
                List<ETLJFQ_STG> jfqStgs = InitJFQ_STG(prcs, bean);
                messages.Add("　=> " + DateTime.Now.ToString("HH:mm:ss") + " 成功...");

                currentStep = "寫入暫存區";
                messages.Add("2. 開始" + currentStep);
                BulkInsertAll(jfqStgs);
                messages.Add("=> " + DateTime.Now.ToString("HH:mm:ss") + " 成功...");

                using (ETLDB_STGDataContext context = new ETLDB_STGDataContext())
                {
                    context.Log = new gbs.bao.etl.util.NLogTextWriter(this.logger);
                    currentStep = "寫入執行週期";
                    messages.Add("3. 開始" + currentStep);
                    context.ps_MergeJfq(prcsId, this.UserName);
                    messages.Add("=> " + DateTime.Now.ToString("HH:mm:ss") + " 成功...");
                }
                ResultMessage.ForeColor = Color.Green;
                ResultMessage.Text = "◆ 匯入完成 ◆";
                this.logger.Info("◆ 匯入執行週期完成 ◆" + string.Join("\r\n", messages.ToArray()));
            }
            catch (Exception ex)
            {
                ResultMessage.ForeColor = Color.Red;
                ResultMessage.Text = "◇ 匯入失敗 ◇";
                messages.Add("=> " + DateTime.Now.ToString("HH:mm:ss") + " 失敗!!!");
                messages.Add("★" + ex.GetType().Name + "　" + ex.Message);
                this.logger.Error("◇ 匯入執行週期失敗 ◇" + string.Join("\r\n", messages.ToArray()), ex);
            }
            Repeater1.DataSource = messages;
            Repeater1.DataBind();
        }

        private void BulkInsertAll(List<ETLJFQ_STG> jfqStgs)
        {
            using (ETLDB_STGDataContext context = new ETLDB_STGDataContext())
            {
                context.Log = new gbs.bao.etl.util.NLogTextWriter(logger);
                new StgFrequencyDAO() { context = context }.BulkInsert(jfqStgs);
            }
        }
        
        private static List<ETLJFQ_STG> InitJFQ_STG(Dictionary<string, object> prcs, IETLRepository bean)
        {
            // ETLJFQ_STG
            List<ETLJFQ_STG> jfqStgs = new List<ETLJFQ_STG>();
            if (bean.IETLJFQs != null)
            {
                jfqStgs.AddRange(bean.IETLJFQs.Select(x => StaticProxyHelper.proxyIt<ETLJFQ_STG>(x, ProxyMode.Property2Property, prcs, null)));
            }
            return jfqStgs;
        }

        private IETLRepository ReadFromXml()
        {
            string path = Encoding.Default.GetString(Convert.FromBase64String(Path.Value));
            IETLRepository bean = IOUtility.FromXml<IETLRepository>(path);
            return bean;
        }

        private Dictionary<string, object> InitInjectValues(string prcsId)
        {
            Dictionary<string, object> prcs = new Dictionary<string, object>();
            prcs.Add("PRJ_ID", this.Project_Id);
            prcs.Add("PRCS_ID", prcsId);
            prcs.Add("PRCS_INFO", string.Empty);
            prcs.Add("PRCS_ST", Const.DEPLOY_ST_I);
            prcs.Add("CMD", Const.DEPLOY_CMD_REFLESH);
            prcs.Add("TBL_UPD_TIM", DateTime.Now);
            prcs.Add("TBL_UPDATER", this.UserName);
            return prcs;
        }
    }
}