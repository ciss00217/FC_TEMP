﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.util;
using gbs.bao.etl.dao;
using gbs.bao.etl.entity.proxy;
using gbs.bao.etl.bo;
using gbs.bao.etl.entity;
using System.Xml;
using System.IO;
using System.Text;
using System.Xml.Serialization;
using gbs.bao.etl.entity.deploy;
using System.Drawing;

namespace ETLAdm.cfg
{


    public partial class FtpConfigSelect : EtlAdmPage
    {
        
        
        protected override void Page_Init(object sender, EventArgs e)
        {
            base.Page_Init(sender, e);
            ((SiteMaster)Page.Master).HideTop1 = true;
            ((SiteMaster)Page.Master).HideLeft1 = true;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GridView1_DataBind();
                if (GridView1.Rows.Count == 0)
                    btnOk.Visible = false;
            }
        }



        private void GridView1_DataBind()
        {
            var a = new ConfigDAO().selectFTPCfgByPrjId(this.Project_Id);
            List<FTPConfig> allFTPs = new List<FTPConfig>();

            ConfigBO bo = new ConfigBO();
            foreach(ETLCFG c in a)
            {
                allFTPs.Add(bo.selectFTPConfigSimple(c.AP_ID));
            }

            var result = from f in allFTPs
                         select new
                         {
                             ap_id=f.root.AP_ID,
                             ftpCfgName = f.root.VAR_NAME,
                             ftpServer = f.root.VAR_VALUE,
                             ftpRFilePath = f.cfgPath.VAR_VALUE,                             
                         };

            GridView1.DataSource = result;
            GridView1.DataBind();
        }







        protected void btnExport_Click(object sender, EventArgs e)
        {
            List<string> values = new List<string>();
            foreach (var key in Request.Form.AllKeys.Where(x => x.EndsWith("checkFTP_ApId")).Select(x => x))
            {
                values.Add(Request.Form[key]);
            }
            if (values.Count == 0)
            {
                setMessage(false, "請勾選FTP參數");
            }
            else
            {
                DeployBO bo = new DeployBO();
                ResultBean result = bo.ExportCfg(values.Select(x => int.Parse(x)).ToArray());
                Response.Clear();
                Response.ContentType = "text/xml";
                string filename = "ETLCFG_Deploy (FTP) " + DateTime.Now.ToString("yyyyMMddHHmm");
                Response.AddHeader("content-disposition", "attachment; filename=\"" + filename + ".xml\"");
                Response.Write(result.data.ToString());
                Response.Flush();
                Response.End();
            }
        }
       
    }
}