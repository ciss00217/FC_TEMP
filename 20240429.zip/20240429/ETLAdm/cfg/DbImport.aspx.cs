﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.util;
using gbs.bao.etl.dao;
using gbs.bao.etl.entity.proxy;
using gbs.bao.etl.bo;
using gbs.bao.etl.entity;
using System.Xml;
using System.IO;
using System.Text;
using System.Xml.Serialization;
using gbs.bao.etl.entity.deploy;
using System.Drawing;

namespace ETLAdm.setting
{
    public partial class DbImport : EtlAdmPage
    {
        ConfigBO bo = new ConfigBO();        

        protected override void Page_Init(object sender, EventArgs e)
        {
            base.Page_Init(sender, e);
            ((SiteMaster)Page.Master).HideTop1 = true;
            ((SiteMaster)Page.Master).HideLeft1 = true;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                
            }
        }

        protected void Wizard1_NextButtonClick(object sender, WizardNavigationEventArgs e)
        {
            int idx = e.CurrentStepIndex;
           
            switch (idx)
            {
                case 0:
                    if (FileUpload1.HasFile)
                    {
                        
                        string fileExt = System.IO.Path.GetExtension(FileUpload1.FileName);
                        if (".XML".Equals(fileExt, StringComparison.OrdinalIgnoreCase))
                        {
                            if (FileUpload1.FileName.IndexOf("DB") >= 0)
                            {
                                ResultBean result = IOUtility.Save(Server, FileUpload1);
                                if (result.success)
                                {
                                    GridView1_DataBind(result);
                                }
                                else
                                {
                                    setMessage(result);
                                    e.Cancel = true;
                                }
                            }
                            else
                            {
                                setMessage(new ResultBean() { message="檔案不正確!"});
                                e.Cancel = true;
                            }
                        }
                    }
                    break;
            }
            
        }

        private void GridView1_DataBind(ResultBean result)
        {
            string path = result.data.ToString();
            Path.Value = Convert.ToBase64String(Encoding.Default.GetBytes(path));
            IETLRepository bean = IOUtility.FromXml<IETLRepository>(path);
            List<DBConfig> allDBs = bo.getDBConfigSimpleByIETLCFGs(bean.IETLCFGs);

            var r = from d in allDBs
                         select new
                         {
                             ap_id = d.root.AP_ID,
                             dbCfgName = d.root.VAR_NAME,
                             dbName = d.root.VAR_VALUE,
                             dbType = d.cfgType.VAR_VALUE,
                             dbServer = d.cfgServer.VAR_VALUE
                         };


            GridView1.DataSource = r;
            GridView1.DataBind();
        }

        protected void Wizard1_FinishButtonClick(object sender, WizardNavigationEventArgs e)
        {
            List<string> messages = new List<string>();
            string currentStep = "";
            string prcsId = DateTime.Now.ToString("yyyyMMddHHmmss");
            Dictionary<string, object> prcs = InitInjectValues(prcsId);
            
            bo.UserName = UserName;
            try
            {   
                currentStep = "讀取匯入檔";
                messages.Add("1. 開始" + currentStep);
                IETLRepository bean = ReadFromXml();
                messages.Add("=>" + DateTime.Now.ToString("HH:mm:ss") + " 成功...");

                currentStep = "讀取DB參數";
                messages.Add("　1-1. 開始" + currentStep);
                List<ETLCFG_STG> cfgStgs = InitCFG_STG(prcs, bean);                                
                messages.Add("　=> " + DateTime.Now.ToString("HH:mm:ss") + " 成功...");

                currentStep = "寫入暫存區";
                messages.Add("2. 開始" + currentStep);
                BulkInsertAll(cfgStgs);
                messages.Add("=> " + DateTime.Now.ToString("HH:mm:ss") + " 成功...");

                using (ETLDB_STGDataContext context = new ETLDB_STGDataContext())
                {
                    context.Log = new gbs.bao.etl.util.NLogTextWriter(this.logger);
                    currentStep = "寫入DB參數";
                    messages.Add("3. 開始" + currentStep);
                    context.ps_MergeCfg(prcsId, this.UserName);
                    ResultBean rtnVal = new ResultBean();
                    rtnVal = bo.ReloadEP(this.Project_Id, rtnVal);
                    messages.Add("=> " + DateTime.Now.ToString("HH:mm:ss") + " 成功...");
                }
                ResultMessage.ForeColor = Color.Green;
                ResultMessage.Text = "◆ 匯入完成 ◆";
                this.logger.Info("◆ 匯入DB參數完成 ◆" + string.Join("\r\n", messages.ToArray()));
            }
            catch (Exception ex)
            {
                ResultMessage.ForeColor = Color.Red;
                ResultMessage.Text = "◇ 匯入失敗 ◇";
                messages.Add("=> " + DateTime.Now.ToString("HH:mm:ss") + " 失敗!!!");
                messages.Add("★" + ex.GetType().Name + "　" + ex.Message);
                this.logger.Error("◇ 匯入DB參數失敗 ◇" + string.Join("\r\n", messages.ToArray()), ex);
            }
            Repeater1.DataSource = messages;
            Repeater1.DataBind();
        }

        private void BulkInsertAll(List<ETLCFG_STG> cfgStgs)
        {
            using (ETLDB_STGDataContext context = new ETLDB_STGDataContext())
            {
                context.Log = new gbs.bao.etl.util.NLogTextWriter(logger);
                new StgConfigDAO() { context = context }.BulkInsert(cfgStgs);
            }
        }
        
        private static List<ETLCFG_STG> InitCFG_STG(Dictionary<string, object> prcs, IETLRepository bean)
        {
            // ETLCFG_STG
            List<ETLCFG_STG> cfgStgs = new List<ETLCFG_STG>();
            if (bean.IETLCFGs != null)
            {
                cfgStgs.AddRange(bean.IETLCFGs.Select(x => StaticProxyHelper.proxyIt<ETLCFG_STG>(x, ProxyMode.Property2Property, prcs, null)));
            }
            return cfgStgs;
        }

        private IETLRepository ReadFromXml()
        {
            string path = Encoding.Default.GetString(Convert.FromBase64String(Path.Value));
            IETLRepository bean = IOUtility.FromXml<IETLRepository>(path);
            return bean;
        }

        private Dictionary<string, object> InitInjectValues(string prcsId)
        {
            Dictionary<string, object> prcs = new Dictionary<string, object>();
            prcs.Add("PRJ_ID", this.Project_Id);
            prcs.Add("PRCS_ID", prcsId);
            prcs.Add("PRCS_INFO", string.Empty);
            prcs.Add("PRCS_ST", Const.DEPLOY_ST_I);
            prcs.Add("CMD", Const.DEPLOY_CMD_REFLESH);
            prcs.Add("TBL_UPD_TIM", DateTime.Now);
            prcs.Add("TBL_UPDATER", this.UserName);
            return prcs;
        }
    }
}