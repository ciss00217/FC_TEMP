﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.util;
using gbs.bao.etl.dao;
using gbs.bao.etl.entity.proxy;
using gbs.bao.etl.bo;
using gbs.bao.etl.entity;
using System.Xml;

namespace ETLAdm.setting
{
    public partial class FrequencySelect : EtlAdmPage
    {
        private string _TheSort;

        public string TheSort
        {
            get
            {
                _TheSort = ViewState["TheSort"] as string;
                return _TheSort;
            }
            set
            {
                _TheSort = value;
                ViewState["TheSort"] = _TheSort;
            }
        }
        private string defaultRunFreqId { get; set; }

        protected override void Page_Init(object sender, EventArgs e)
        {
            base.Page_Init(sender, e);
            ((SiteMaster)Page.Master).HideTop1 = true;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            defaultRunFreqId = "";
            if (!IsPostBack)
            {
                defaultRunFreqId = Request.QueryString["RUN_FREQ_ID"];
                TheSort = this.GridView1.ID + "&" + "RUN_FREQ_NAME" + "&" + SortDirection.Ascending.ToString();
                GridView_DataBind();
            }
        }
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            GridView_DataBind();
        }
        protected void btnExport_Click(object sender, EventArgs e)
        {
            List<string> values = new List<string>();
            foreach (var key in Request.Form.AllKeys.Where(x => x.EndsWith("$checkFreqId")).Select(x=>x))
            {
                values.Add(Request.Form[key]);
            }
            if (values.Count == 0)
            {
                setMessage(false, "請勾選執行週期");
            }
            else
            {
                DeployBO bo = new DeployBO();
                ResultBean result = bo.ExportFreq(this.Project_Id, values.Select(x => int.Parse(x)).ToArray());
                Response.Clear();
                Response.ContentType = "text/xml";
                string filename = "ETLJFQ_Deploy" + DateTime.Now.ToString("yyyyMMddHHmm") ;
                Response.AddHeader("content-disposition", "attachment; filename=\"" + filename + ".xml\"");
                Response.Write(result.data.ToString());
                Response.Flush();
                Response.End();
            }
        }
        protected void GridView_DataBind()
        {
            FrequencyDAO dao = new FrequencyDAO();

            string inName = freqName.Text.Trim();
            List<char> infileFreqs = runFreqs.Items.Cast<ListItem>()
                .Where(li => li.Selected)
                .Select(li => li.Value[0])
                .ToList();

            var v = dao.selectSome(this.Project_Id, inName, infileFreqs)
                .Where(x=>string.IsNullOrEmpty(defaultRunFreqId)|| x.RUN_FREQ_ID.Equals(defaultRunFreqId))
                .Select(_v => _v);
            
            string sortExpression = "";
            string sortDirection = "";

            if (!string.IsNullOrEmpty(TheSort))
            {
                string[] t = TheSort.Split("&".ToCharArray());
                sortExpression = t[1];
                sortDirection = t[2];
            }

            if (SortDirection.Ascending.ToString().Equals(sortDirection))
            {
                if ("RUN_FREQ_NAME".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.RUN_FREQ_NAME);
                }
                else if ("RUN_FREQ".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.RUN_FREQ);
                }
                else if ("EXE_TIME".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.EXE_TIME);
                }                
            }
            else
            {
                if ("RUN_FREQ_NAME".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.RUN_FREQ_NAME);
                }
                else if ("RUN_FREQ".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.RUN_FREQ);
                }
                else if ("EXE_TIME".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.EXE_TIME);
                } 
            }
            
            GridView1.DataSource = v;
            GridView1.Visible = true;
            GridView1.DataBind();
        }

        protected void GridView_Type_Sorting(object sender, GridViewSortEventArgs e)
        {
            GridView view = sender as GridView;
            if (string.IsNullOrEmpty(TheSort))
            {
                TheSort = view.ID + "&" + e.SortExpression + "&" + e.SortDirection;
            }
            else
            {
                string[] theSort = TheSort.Split("&".ToCharArray());
                if (view.ID.Equals(theSort[0]))
                {
                    if (e.SortExpression.Equals(theSort[1]))
                    {
                        if (SortDirection.Ascending.ToString().Equals(theSort[2]))
                        {
                            TheSort = view.ID + "&" + e.SortExpression + "&" + SortDirection.Descending;
                        }
                        else
                        {
                            TheSort = view.ID + "&" + e.SortExpression + "&" + SortDirection.Ascending;
                        }
                    }
                    else
                    {
                        TheSort = view.ID + "&" + e.SortExpression + "&" + e.SortDirection;
                    }
                }
                else
                {
                    TheSort = view.ID + "&" + e.SortExpression + "&" + e.SortDirection;
                }
            }
            GridView_DataBind();
        }
    }
}