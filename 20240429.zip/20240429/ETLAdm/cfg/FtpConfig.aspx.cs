﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.util;
using gbs.bao.etl.entity;
using gbs.bao.etl.bo;
using gbs.bao.etl.dao;

namespace ETLAdm.cfg
{
    public partial class FtpConfig : EtlAdmPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                addCfg_Click(addConfig, null);
                DataList1_DataBind();
            }
        }

        protected void addCfg_Click(object sender, EventArgs e)
        {
            DetailClear();
            btnOk.CommandName = Const.CMD_Add;
            btnRemove.Visible = false;
            this.var_name.Attributes.Remove("onkeydown");
            this.var_name.Attributes.Remove("style");
        }

        protected void lnkCfg_Click(object sender, EventArgs e)
        {
            LinkButton link = sender as LinkButton;
            int ap_id = Convert.ToInt32(link.CommandArgument);
            DetailBind(ap_id, false);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ap_id"></param>
        private string OverrideVarName(string str)
        {
            string[] varNames = str.Split('.');
            string result = varNames[0] + "(Copy)" + (varNames.Length > 1 ? "." + varNames[1] : "");
            return result;
        }

        protected void DetailBind(int ap_id, bool isCopy)
        {
            btnOk.CommandName = Const.CMD_Replace;
            btnOk.CommandArgument = ap_id + "";
            try
            {
                FTPConfig cfg = new ConfigBO().selectFTPConfig(ap_id);
                if (isCopy)
                {
                    cfg.root.VAR_NAME = OverrideVarName(cfg.root.VAR_NAME);
                    btnOk.CommandName = Const.CMD_Add;
                    DetailBind(cfg, false);
                }
                else
                {
                    btnRemove.CommandArgument = ap_id + "";
                    DetailBind(cfg, true);
                }
            }
            catch (Exception ex)
            {
                logger.ErrorException(ex.Message, ex);
                setMessage(false, ex.Message);
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private FTPConfig DetailDataSource(bool isAdd = false)
        {

            ETLCFG root = new ETLCFG()
            {
                PRJ_ID = Project_Id,
                VAR_NAME = isAdd ? this.var_name.Text.Trim() : this.var_name.Text,
                VAR_VALUE = this.ftp_name.Text,
                VAR_TYPE = Const.CFG_TYPE_FTP,
                ENABLE_FLAG = enable_flag.SelectedValue.ToCharArray()[0],
                ENCRYPT_FLAG = Const.ENABLE_N
            };

            ETLCFG cfgUser = new ETLCFG()
            {
                PRJ_ID = Project_Id,
                VAR_NAME = string.Format(Const.CFG_FTP_PTN_USERID, root.VAR_NAME),
                VAR_VALUE = this.user_id.Text,
                VAR_TYPE = Const.CFG_TYPE_FTP_STATIC,
                ENABLE_FLAG = enable_flag.SelectedValue.ToCharArray()[0],
                ENCRYPT_FLAG = this.usr_id_encrypt.SelectedValue[0]
            };

            ETLCFG cfgPwd = new ETLCFG()
            {
                PRJ_ID = Project_Id,
                VAR_NAME = string.Format(Const.CFG_FTP_PTN_PWD, root.VAR_NAME),
                VAR_VALUE = this.password.Text,
                VAR_TYPE = Const.CFG_TYPE_FTP_STATIC,
                ENABLE_FLAG = enable_flag.SelectedValue.ToCharArray()[0],
                ENCRYPT_FLAG = this.password_encrypt.SelectedValue[0]
            };


            ETLCFG cfgPath = new ETLCFG()
            {
                PRJ_ID = Project_Id,
                VAR_NAME = string.Format(Const.CFG_FTP_PTN_RFILEPATH, root.VAR_NAME),
                VAR_VALUE = this.path.Text,
                VAR_TYPE = Const.CFG_TYPE_FTP_STATIC,
                ENABLE_FLAG = enable_flag.SelectedValue.ToCharArray()[0],
                ENCRYPT_FLAG = Const.ENABLE_N
            };

            return new FTPConfig()
            {
                root = root,
                cfgUser = cfgUser,
                cfgPwd = cfgPwd,
                cfgPath = cfgPath
            };
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cfg"></param>
        /// <returns></returns>
        private FTPConfig DetailBind(FTPConfig cfg, bool isVarNameReadOnly)
        {
            this.var_name.ReadOnly = isVarNameReadOnly;
            if (isVarNameReadOnly)
            {
                this.var_name.Attributes.Add("onkeydown", "return false;");
                this.var_name.Attributes.Add("style", "background:silver");
                this.btnRemove.Visible = true;
                this.btnCopy.Visible = true;
            }
            else
            {
                this.var_name.Attributes.Remove("onkeydown");
                this.var_name.Attributes.Remove("style");
                this.btnRemove.Visible = false;
                this.btnCopy.Visible = false;
            }
            this.var_name.Text = cfg.root.VAR_NAME;
            this.ftp_name.Text = cfg.root.VAR_VALUE;
            this.user_id.Text = cfg.cfgUser.VAR_VALUE;
            this.usr_id_encrypt.SelectedValue = cfg.cfgUser.ENCRYPT_FLAG.ToString();
            this.password.Text = cfg.cfgPwd.VAR_VALUE;
            this.password.Attributes.Add("value", cfg.cfgPwd.VAR_VALUE);
            this.password_encrypt.SelectedValue = cfg.cfgPwd.ENCRYPT_FLAG.ToString();
            this.path.Text = cfg.cfgPath.VAR_VALUE;
            this.enable_flag.SelectedValue = cfg.root.ENABLE_FLAG + "";
            this.btnOk.CommandArgument = cfg.root.AP_ID + "";
            this.btnRemove.CommandArgument = cfg.root.AP_ID + "";
            this.btnCopy.CommandArgument = cfg.root.AP_ID + "";
            return cfg;
        }

        /// <summary>
        /// 
        /// </summary>
        private void DetailClear()
        {
            this.var_name.ReadOnly = false;
            this.var_name.Text = string.Empty;
            this.ftp_name.Text = string.Empty;
            this.user_id.Text = string.Empty;
            this.usr_id_encrypt.SelectedValue = Const.VALUE_N;
            this.password.Text = string.Empty;
            this.password.Attributes.Remove("value");
            this.password_encrypt.SelectedValue = Const.VALUE_Y;
            this.path.Text = string.Empty;
            this.enable_flag.SelectedValue = Const.VALUE_Y;
            this.btnCopy.Visible = false;
            this.btnRemove.Visible = false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnOk_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            ConfigBO bo = new ConfigBO();
            bo.UserName = UserName;
            ResultBean result = null;
            FTPConfig cfg = null;
            int ap_id = -1;
            switch (btn.CommandName)
            {
                case Const.CMD_Add:
                    cfg = DetailDataSource(true);
                    result = setMessage(bo.addFTPConfigAll(cfg));
                    break;
                case Const.CMD_Replace:
                    cfg = DetailDataSource();
                    result = setMessage(bo.replaceFTPConfigAll(cfg));
                    break;
                case Const.CMD_Remove:
                    if (btn.CommandArgument == string.Empty)
                    {
                        logger.Error(Const.MSG_Fail + ",參數為空白");
                        result = setMessage(false, Const.MSG_Fail);
                    }
                    else
                    {
                        ap_id = Convert.ToInt32(btn.CommandArgument);
                        result = setMessage(bo.removeConfigAll(ap_id));
                    }
                    break;
                case Const.CMD_Copy:
                    if (btn.CommandArgument == string.Empty)
                    {
                        logger.Error(Const.MSG_Fail + ",參數為空白");
                        result = setMessage(false, Const.MSG_Fail);
                    }
                    else
                    {
                        ap_id = Convert.ToInt32(btn.CommandArgument);
                        result = setMessage(new ResultBean()
                        {
                            success = true,
                            message = Const.MSG_Copy_SUCCESS
                        });
                    }
                    break;
            }
            if (result.success)
            {
                DataList1_DataBind();
                switch (btn.CommandName)
                {
                    case Const.CMD_Add:
                        addCfg_Click(addConfig, null);
                        break;
                    case Const.CMD_Replace:
                        DetailBind(cfg.root.AP_ID, false);
                        break;
                    case Const.CMD_Remove:
                        addCfg_Click(addConfig, null);
                        break;
                    case Const.CMD_Copy:
                        DetailBind(ap_id, true);
                        break;
                }
            }
        }

        protected void DataList1_DataBind()
        {
            ObjectDataSource1.SelectParameters[0].DefaultValue = this.Project_Id + "";
            DataList1.DataBind();
        }
    }
}
