﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ETLAdm.util
{
    public partial class StatusDiscription : System.Web.UI.UserControl
    {
        public string CssClass
        {
            get
            {
                return ViewState["CssClass"] as string;
            }
            set
            {
                ViewState["CssClass"] = value;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Page_PreRender(object sender, EventArgs e)
        {
            string cssClass = CssClass;
            if (cssClass != null)
            {
                this.statusDescription.Attributes.Add("class", CssClass);
            }
            else
            {
                this.statusDescription.Attributes.Remove("class");
            }
            
        }
    }
}