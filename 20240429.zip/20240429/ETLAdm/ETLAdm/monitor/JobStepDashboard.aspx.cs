﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.util;
using gbs.bao.etl.dao;
using gbs.bao.etl.entity;
using System.Web.Script.Serialization;
using gbs.bao.etl.bo.json;
using gbs.bao.etl.bo.json.entity;
using gbs.bao.etl.bo.json.core;

namespace ETLAdm.monitor
{
    public partial class JobStepDashboardSearch2 : EtlAdmPage
    {

        public bool IsETLEXE
        {
            get
            {
                return this.User.IsInRole("ETLEXE");
            }
        }

          
        protected void Page_Load(object sender, EventArgs e)
        {
            this.ClientScript.RegisterOnSubmitStatement(
                this.GetType(),                 
                "ClearData",
                "$('#log_detail').text('')");
            CurrentDateTime.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            String originalFlowID = null;

            if (IsPostBack)
            {
                originalFlowID = Request.Form["hdnOriginalFlowID"];
            }
            else
            {
                ObjectDataSource1.SelectParameters[0].DefaultValue = Project_Id.ToString();
                if (PreviousPage != null)
                {
                    originalFlowID = Request.Form["sel_job_flow"];
                    this.cbxAutoRefresh.Checked = PreviousPage.TheCbxAutoRefresh.Checked;
                    this.AutoRefreshMin.SelectedValue = PreviousPage.TheAutoRefreshMin.SelectedValue;
                    this.AutoRefreshSec.SelectedValue = PreviousPage.TheAutoRefreshSec.SelectedValue;
                    String originalJobID = PreviousPage.TheCommandArgument.Value;                    
                    ddlJobFlows.DataBind();
                    string jobFlowType = Request.QueryString["JobFlowType"];
                    string jobFlowSt = Request.QueryString["JobFlowSt"];
                    string beginDt = Server.UrlDecode(Request.QueryString["BeginDT"]);
                    string endDt = Server.UrlDecode(Request.QueryString["EndDT"]);
                    string freq = Server.UrlDecode(Request.QueryString["Freq"]);
                    string freqname = Server.UrlDecode(Request.QueryString["FreqName"]);
                    string href = string.Concat(
                            "~/monitor/Dashboard.aspx",
                            "?JobFlowType=", Server.UrlEncode(jobFlowType),
                            "&JobFlowSt=", Server.UrlEncode(jobFlowSt),
                            "&BeginDT=" + Server.UrlEncode(beginDt),
                            "&EndDT=" + Server.UrlEncode(endDt),
                            "&Freq=" + Server.UrlEncode(freq),
                            "&FreqName=" + Server.UrlEncode(freqname)
                        );
                    this.btnBack.PostBackUrl = href;

                    using (JobInstDAO dao = new JobInstDAO())
                    {
                        int jobApId = 0;
                        if (!int.TryParse(originalJobID, out jobApId))
                        {
                            logger.Error("Argument error[0]: " + originalJobID);
                        }
                        ETLJOB job = dao.selectJOBByApId(jobApId);
                        if (job != null)
                        {
                            ddlJobFlows.SelectedValue = job.JOB_FLOW_ID.ToString();

                            ddlJobFlows_SelectedIndexChanged(ddlJobFlows, new EventArgs());
                            ddlJob.SelectedValue = originalJobID;
                        }
                        if (ddlJob.SelectedIndex == 0)
                        {
                            logger.Error("Argument error[1]: " + originalJobID);
                        }
                        else
                        {
                            GridView_DataBind();
                        }
                    }
                }                
            }
            Page.ClientScript.RegisterStartupScript(this.GetType(), "fillOrginalFlowID", "$(function() { $('input#hdnOriginalFlowID').val('" + originalFlowID + "'); });", true);
        }

        protected void ddlJobFlows_SelectedIndexChanged(object sender, EventArgs e)
        {
            ObjectDataSource2.SelectParameters[0].DefaultValue = this.Project_Id.ToString();
            ObjectDataSource2.SelectParameters[1].DefaultValue = ddlJobFlows.SelectedValue;
            ddlJob.Items.Clear();
            ddlJob.Items.Add(new ListItem("---請選擇---", "---請選擇---"));
            ddlJob.DataBind();
        }

        protected void btnChange_Click(object sender, EventArgs e)
        {
            this.hdnShowLogStepApId.Value = "";
            GridView_DataBind();
        }

        private void GridView_DataBind() {
            int job_id = Convert.ToInt32(ddlJob.SelectedValue);
            List<TwoEntities<ETLJSP, ETLJSD>> datasource = new JobStepInstDAO().selectJobStepByJobId(job_id);
            GridView_Job_Steps.DataSource = from _v in datasource
                                            orderby _v.e2.RUN_SEQ
                                            select new
                                            {
                                                RUN_SEQ = _v.e2.RUN_SEQ,
                                                JOB_STEP_ID = _v.e2.JOB_STEP_ID,
                                                JOB_STEP_NAME = _v.e2.JOB_STEP_NAME,
                                                JOB_STEP_STATUS = _v.e1.JOB_STEP_STATUS,
                                                JOB_START_DT = _v.e1.JOB_START_DT,
                                                JOB_END_DT = _v.e1.JOB_END_DT,
                                                RUN_START_TIM = _v.e1.RUN_START_TIM,
                                                RUN_END_TIM = _v.e1.RUN_END_TIM,
                                                AP_ID = _v.e1.AP_ID
                                            };
            GridView_Job_Steps.DataBind();        
        }

        protected void btnExecutionSubmit_Click(object sender, EventArgs args)
        {
            if (!this.IsReFlesh)
            {
                RunJobBean entity = new JavaScriptSerializer().Deserialize<RunJobBean>(hdnCommandArgument.Value);
                ISignatureBo bo = JsonSvcBoFactory.Instance.CreateSignatureBo(JsonSvcConst.RunJob);
                bo.UserName = this.UserName;
                ResultBean bean = setMessage(((ITypeBo<RunJobBean>)bo).Execute(entity));
                RegistSessionKeyUpdate();
            }
            GridView_DataBind();
        }

        protected void btnCancelSubmit_Click(object sender, EventArgs args)
        {
            if (!this.IsReFlesh)
            {
                int ap_id = Int32.Parse(hdnCommandArgument.Value);
                JobDefineBean entity = new JobDefineBean() {
                    PRJ_ID = this.Project_Id,
                    JOB_STEP_AP_ID = ap_id 
                };

                ISignatureBo bo = JsonSvcBoFactory.Instance.CreateSignatureBo(JsonSvcConst.CancelJob);
                bo.UserName = this.UserName;
                ResultBean bean = setMessage(((ITypeBo<JobDefineBean>)bo).Execute(entity));
                RegistSessionKeyUpdate();
            }
            GridView_DataBind();
        }

        protected void btnReflash_Click(object sender, EventArgs args)
        {
            GridView_DataBind();
        }
    }
}
