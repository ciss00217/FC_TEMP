﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.util;
using gbs.bao.etl.net;
using gbs.bao.etl.entity;
using System.Threading;
using gbs.bao.etl.dao;

namespace ETLAdm.sys
{
    public partial class TurnCommand : EtlAdmPage
    {
        private string _TheSort;

        public string TheSort
        {
            get
            {
                _TheSort = ViewState["TheSort"] as string;
                return _TheSort;
            }
            set
            {
                _TheSort = value;
                ViewState["TheSort"] = _TheSort;
            }
        }
        
        protected void Page_Load(object sender, EventArgs e)
        {
            ClientScript.RegisterOnSubmitStatement(this.GetType(), "blockui", "$.blockUI();");
            // ask etl engine status
            if (!IsPostBack)
            {
                DoDataBind();
                GridView_DataBind();
            }
        }

        protected ResultBean DoDataBind()
        {
            //ResultBean bean = EtlEngineCommandTCPClient.Instance.QueryStatus();
            ResultBean bean = EtlEngineServiceTCPClient.Instance.QueryEngineStatus();
            ImageButton1.Visible = true;
            if (bean.success)
            {
                if (Const.EtlEngineResponseOK.Equals(bean.message))
                {
                    StatusLabel.Text = "ETL Engine 執行中";
                    ImageButton1.ImageUrl = "~/static/img/status_icon/" + Utilities.StatusImage(Const.JobFlowStatus_S);
                    btnClose.Enabled = true;
                    btnOk.Enabled = false;
                }
                else
                {
                    StatusLabel.Text = "ETL Engine 已中止";
                    ImageButton1.ImageUrl = "~/static/img/status_icon/" + Utilities.StatusImage(Const.JobFlowStatus_X);
                    btnClose.Enabled = false;
                    btnOk.Enabled = true;
                }
            }
            else
            {
                StatusLabel.Text = "系統異常,請確認ETL Engine Agent服務是否被中止. [" + bean.message + "]";
                ImageButton1.Visible = false;
                btnClose.Enabled = false;
                btnOk.Enabled = false;
            }
            return bean;
        }

        protected void btnOk_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            ResultBean bean = null;
            if ("Open".Equals(btn.CommandName))
            {
                bean = EtlEngineServiceTCPClient.Instance.StartETLServer();
            }
            else
            {
                bean = EtlEngineServiceTCPClient.Instance.StopETLServer();
            }

            if (bean.success)
            {
                Thread.Sleep(3000);
                DoDataBind();
            }
            else
            {
                setMessage(bean);
            }
        }



        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            DoDataBind();
        }

        private void GridView_DataBind()
        {


            List<SixEntities<ETLJSP, ETLJSD, ETLJBD, ETLJFW, ETLJFQ,ETLPRJ>> datasource = new JobStepInstDAO().selectJobStepRunning();
            var v = (from _v in datasource
                     orderby _v.e6.PRJ_NAME,_v.e4.JOB_FLOW_NAME, _v.e3.JOB_NAME, _v.e2.RUN_SEQ
                     select new
                     {
                         PRJ_NAME=_v.e6.PRJ_NAME,
                         RUN_SEQ = _v.e2.RUN_SEQ,
                         JOB_FLOW_NAME = _v.e4.JOB_FLOW_NAME,
                         JOB_NAME = _v.e3.JOB_NAME,
                         JOB_TYPE = _v.e3.JOB_TYPE,
                         JOB_STEP_ID = _v.e2.JOB_STEP_ID,
                         JOB_STEP_NAME = _v.e2.JOB_STEP_NAME,
                         JOB_STEP_STATUS = _v.e1.JOB_STEP_STATUS,
                         JOB_START_DT = _v.e1.JOB_START_DT,
                         JOB_END_DT = _v.e1.JOB_END_DT,
                         RUN_START_TIM = _v.e1.RUN_START_TIM,
                         RUN_END_TIM = _v.e1.RUN_END_TIM,
                         AP_ID = _v.e1.AP_ID,
                         RUN_FREQ = (_v.e5.RUN_FREQ.ToString().Equals("D") ? "每天-" + _v.e5.RUN_FREQ_NAME :
                                   _v.e5.RUN_FREQ.ToString().Equals("W") ? "每週-" + _v.e5.RUN_FREQ_NAME :
                                   _v.e5.RUN_FREQ.ToString().Equals("M") ? "每月-" + _v.e5.RUN_FREQ_NAME :
                                   _v.e5.RUN_FREQ.ToString().Equals("Y") ? "每年-" + _v.e5.RUN_FREQ_NAME :
                                   _v.e5.RUN_FREQ.ToString().Equals("F") ? "檔案-" + _v.e5.RUN_FREQ_NAME :
                                   _v.e5.RUN_FREQ.ToString().Equals("R") ? "重覆-" + _v.e5.RUN_FREQ_NAME :
                                   _v.e5.RUN_FREQ.ToString().Equals("I") ? "單次-" + _v.e5.RUN_FREQ_NAME :
                                   "")
                     });

            string sortExpression = "";
            string sortDirection = "";

            if (!string.IsNullOrEmpty(TheSort))
            {
                string[] t = TheSort.Split("&".ToCharArray());
                sortExpression = t[1];
                sortDirection = t[2];
            }

            if (SortDirection.Ascending.ToString().Equals(sortDirection))
            {
                if ("PRJ_NAME".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.PRJ_NAME);
                }
                if ("JOB_FLOW_NAME".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.JOB_FLOW_NAME);
                }
                else if ("JOB_NAME".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.JOB_NAME);
                }
                else if ("JOB_STEP_NAME".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.JOB_STEP_NAME);
                }
                else if ("JOB_STEP_STATUS".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.JOB_STEP_STATUS);
                }
                else if ("JOB_START_DT".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.JOB_START_DT);
                }
                else if ("JOB_END_DT".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.JOB_END_DT);
                }
                else if ("RUN_START_TIM".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.RUN_START_TIM);
                }
                else if ("RUN_END_TIM".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.RUN_END_TIM);
                }
                else if ("RUN_DUR".Equals(sortExpression))
                {
                    v = v.OrderBy(x => CalcUtilities.EvalDuring(x.RUN_START_TIM, x.RUN_END_TIM));
                }
                else if ("RUN_FREQ".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.RUN_FREQ);
                }
            }
            else
            {
                if ("PRJ_NAME".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.PRJ_NAME);
                }
                if ("JOB_FLOW_NAME".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.JOB_FLOW_NAME);
                }
                else if ("JOB_NAME".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.JOB_NAME);
                }
                else if ("JOB_STEP_NAME".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.JOB_STEP_NAME);
                }
                else if ("JOB_STEP_STATUS".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.JOB_STEP_STATUS);
                }
                else if ("JOB_START_DT".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.JOB_START_DT);
                }
                else if ("JOB_END_DT".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.JOB_END_DT);
                }
                else if ("RUN_START_TIM".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.RUN_START_TIM);
                }
                else if ("RUN_END_TIM".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.RUN_END_TIM);
                }
                else if ("RUN_DUR".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => CalcUtilities.EvalDuring(x.RUN_START_TIM, x.RUN_END_TIM));
                }
                else if ("RUN_FREQ".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.RUN_FREQ);
                }
            }

            GridView_Job_Steps.DataSource = v.ToList();
            GridView_Job_Steps.DataBind();

        }

        protected void GridView_Type_Sorting(object sender, GridViewSortEventArgs e)
        {
            GridView view = sender as GridView;
            if (string.IsNullOrEmpty(TheSort))
            {
                TheSort = view.ID + "&" + e.SortExpression + "&" + e.SortDirection;
            }
            else
            {
                string[] theSort = TheSort.Split("&".ToCharArray());
                if (view.ID.Equals(theSort[0]))
                {
                    if (e.SortExpression.Equals(theSort[1]))
                    {
                        if (SortDirection.Ascending.ToString().Equals(theSort[2]))
                        {
                            TheSort = view.ID + "&" + e.SortExpression + "&" + SortDirection.Descending;
                        }
                        else
                        {
                            TheSort = view.ID + "&" + e.SortExpression + "&" + SortDirection.Ascending;
                        }
                    }
                    else
                    {
                        TheSort = view.ID + "&" + e.SortExpression + "&" + e.SortDirection;
                    }
                }
                else
                {
                    TheSort = view.ID + "&" + e.SortExpression + "&" + e.SortDirection;
                }
            }
            GridView_Job_Steps.PageIndex = 0;
            GridView_DataBind();
        }

        protected void gvPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView_Job_Steps.PageIndex = e.NewPageIndex;
            GridView_DataBind();
        }
    }
}
