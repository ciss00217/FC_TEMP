﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.util;
using gbs.bao.etl.entity;
using gbs.bao.etl.bo;

namespace ETLAdm.sys
{
    public partial class ProjectPage : EtlAdmPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                MultiView1.ActiveViewIndex = Project_Id == 0 ? 0 : 1;
                DetailsView1.Visible = false;
                ObjectDataSource1.SelectParameters[0].DefaultValue = this.UserName;
                ObjectDataSource1.SelectParameters[1].DefaultValue = this.Project_Id + "";
                DataList1_DataBind();
            }
        }

        protected void lnkPrj_Click(object sender, EventArgs e)
        {
            LinkButton link = sender as LinkButton;

            DetailView_DataBind(link.CommandArgument);
        }

        protected void DetailView_DataBind(string prj_id)
        {
            DetailsView1.Visible = true;

            DetailsView1.ChangeMode(DetailsViewMode.Edit);
            DetailsView1.DefaultMode = DetailsViewMode.Edit;

            ObjectDataSource2.SelectParameters[0].DefaultValue = prj_id;
            DetailsView1.DataBind();
        }

        protected void addPrj_Click(object sender, EventArgs e)
        {
            DetailsView1.Visible = true;

            DetailsView1.ChangeMode(DetailsViewMode.Insert);
            DetailsView1.DefaultMode = DetailsViewMode.Insert;

            ObjectDataSource2.SelectParameters[0].DefaultValue = "-1";
            DetailsView1.DataBind();
        }

        protected void btnOk_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            ProjectBO bo = new ProjectBO();
            bo.UserName = UserName;
            
            ResultBean result = null;
            string prj_name = (ControlUtil.FindInTemplate(btn, "prj_name") as TextBox).Text;
            string prj_desc = (ControlUtil.FindInTemplate(btn, "prj_desc") as TextBox).Text;
            char enable_flag = (ControlUtil.FindInTemplate(btn, "enable_flag") as DropDownList).SelectedValue.ToCharArray()[0];
            int prj_id = -1;
            switch (btn.CommandName)
            {
                case Const.CMD_Add:                                        
                    result = setMessage(bo.addProject(prj_name, prj_desc, enable_flag));
                    prj_id = (int) result.data;
                    /*
                    GroupBO gbo = new GroupBO();
                    gbo.UserName = UserName;
                    gbo.addGroup(prj_id, UserName, Const.SYSADM, SeqBO.Instance); 
                     */
                    break;
                case Const.CMD_Replace:                    
                    prj_id = Convert.ToInt32(btn.CommandArgument);
                    result = setMessage(bo.replaceProject(prj_id, prj_name, prj_desc, enable_flag));
                    break;
                case Const.CMD_Remove:
                    prj_id = Convert.ToInt32(btn.CommandArgument);
                    result = setMessage(bo.removeProject(prj_id));
                    break;
            }
            if (result.success)
            {
                DataList1_DataBind();
                if (btn.CommandName == Const.CMD_Add)
                {
                    addPrj_Click(this.addProject, e);
                    
                }
                else if (btn.CommandName == Const.CMD_Replace)
                {
                    DetailView_DataBind(prj_id.ToString());
                }
                else
                {
                    DetailsView1.Visible = false;
                }
            }
        }
        protected void DataList1_DataBind()
        {
            DataList1.DataBind();
        }
    }
}
