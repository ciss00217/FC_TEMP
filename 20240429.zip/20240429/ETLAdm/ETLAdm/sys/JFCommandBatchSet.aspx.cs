﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.util;
using gbs.bao.etl.dao;
using gbs.bao.etl.entity.proxy;
using gbs.bao.etl.bo;
using gbs.bao.etl.entity;
using System.Xml;
using System.IO;
using System.Text;
using System.Xml.Serialization;
using gbs.bao.etl.entity.deploy;
using System.Drawing;

namespace ETLAdm.sys
{
    

    public partial class JFCommandBatchSet : EtlAdmPage
    {
        List<FlowNTFEntity> flowList;
        
        protected override void Page_Init(object sender, EventArgs e)
        {
            base.Page_Init(sender, e);
            ((SiteMaster)Page.Master).HideTop1 = true;
            ((SiteMaster)Page.Master).HideLeft1 = true;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GridView1_DataBind();
                if (GridView1.Rows.Count == 0)
                    btnOk.Visible = false;
            }
        }

        List<ETLJFQ> freqs = null;

        protected void RUN_FREQ_ID_DataBinding(object sender, EventArgs e)
        {
            HiddenField freq = (HiddenField)sender;
            DropDownList ddl = (DropDownList)freq.NamingContainer.FindControl("RUN_FREQ");
            if (freqs == null)
            {
                freqs = new FrequencyDAO().selectByPrjId(this.Project_Id);
                //freqs.Insert(0, new ETLJFQ() { RUN_FREQ_ID = -1, RUN_FREQ_NAME = "---請選擇---" });
            }
            if (ddl.Items.Count == 0)
            {
                ddl.DataSource = freqs;
                ddl.DataBind();
            }
            if (ddl.Items.FindByValue(freq.Value) != null)
            {
                ddl.SelectedValue = freq.Value;
            }
        }

        

        private void GridView1_DataBind()
        {
            //string path = result.data.ToString();
            //Path.Value = Convert.ToBase64String(Encoding.Default.GetBytes(path));
            //IETLRepository bean = IOUtility.FromXml<IETLRepository>(path);

            //var jobFlows = new JobFlowDAO().selectByPrjIdOrderByName(this.Project_Id);
            List<int> flows=new List<int>();
            if (Session["FlowIDs"]!=null)
                flows.AddRange((List<int>)Session["FlowIDs"]);
            var jobFlows = new JobFlowDAO().selectJFWAndNTFByApIds(flows).OrderBy(v=>v.JOB_FLOW_NAME);
            //Session.Remove("FlowIDs");
 

            GridView1.DataSource = jobFlows;
            GridView1.DataBind();
        }

        


        private FlowNTFEntity ReadFlowFromRow(GridViewRow row)
        {
            HiddenField hdnProjectId = row.FindControl("hdnProjectId") as HiddenField;
            HiddenField jobFlowId = row.FindControl("JOB_FLOW_ID") as HiddenField;
            string flowId = jobFlowId.Value;            

            DropDownList runFreq = row.FindControl("RUN_FREQ") as DropDownList;
            TextBox jobFlowStartDt = row.FindControl("JOB_FLOW_START_DT") as TextBox;
            TextBox jobFlowEndDt = row.FindControl("JOB_FLOW_END_DT") as TextBox;
            RadioButtonList jobFlowStatus = row.FindControl("JOB_FLOW_STATUS") as RadioButtonList;
            DropDownList notifyType = row.FindControl("ddlNtfType") as DropDownList;
            TextBox nofifyID = row.FindControl("txtNTF_ID") as TextBox;
            TextBox nofifyText = row.FindControl("txtNTF_TXT") as TextBox;
            Label oldFlowStatus = row.FindControl("OLD_JF_STATUS") as Label;            

            string runFreqVal = runFreq.SelectedValue;
            string runFreqName = runFreq.SelectedItem.Text;
            //string startDtVal = jobFlowStartDt.Text;
            //string endDtVal = jobFlowEndDt.Text;
            char status = jobFlowStatus.SelectedValue.ToCharArray().First();
            char oldStatus = oldFlowStatus.Text.ToCharArray().First();

            if (!status.Equals('X') && !oldStatus.Equals('X')) status = oldStatus; //若修改前後狀態皆為啟動, 則維持原狀態
                     
            int prjId = Convert.ToInt32(hdnProjectId.Value);

            DateTime _job_flow_start_dt;
            bool had_start_dt = DateTime.TryParse(jobFlowStartDt.Text, out _job_flow_start_dt);

            DateTime _job_flow_end_dt;
            bool had_end_dt = DateTime.TryParse(jobFlowEndDt.Text, out _job_flow_end_dt);
                        
            DateTime? NoDate = null;
            
            ETLNTF ntf = null;

            if (notifyType.SelectedIndex > 0)
            {
                int seq = new SeqBO().nextIntVal(typeof(ETLNTF));
                ntf = new ETLNTF()
                {
                    PRJ_ID = Convert.ToInt32(hdnProjectId.Value),
                    JOB_FLOW_ID = Convert.ToInt32(flowId),
                    NTF_ID = nofifyID.Text,
                    NTF_TYPE = notifyType.SelectedValue.ToCharArray()[0],
                    NTF_TXT = nofifyText.Text,
                    AP_ID = seq,
                    TBL_UPD_TIM = DateTime.Now,
                    TBL_UPDATER = UserName
                };
            }

            FlowNTFEntity entity = new FlowNTFEntity()
            {
                e1=Convert.ToInt32(flowId),
                e2 = had_start_dt ? _job_flow_start_dt : NoDate,
                e3=had_end_dt ? _job_flow_end_dt : NoDate,
                e4=status,
                e5=Convert.ToInt32(runFreqVal),
                e6=ntf
            
            };

            return entity;
            
            
            //ResultBean result = this.setMessage(
            //    bo.replace(
            //        Convert.ToInt32(flowId),
            //        had_start_dt ? _job_flow_start_dt : NoDate,
            //        had_end_dt ? _job_flow_end_dt : NoDate,
            //        status,
            //        Convert.ToInt32(runFreqVal),
            //        ntf));
            
        }

        private bool checkInput()
        {
            bool hasDate = true;
            bool dateCorrect = true;
            bool hasID = true;
            bool hasTxt = true;
            
            foreach (GridViewRow row in GridView1.Rows)
            { 
                
                                
                TextBox jobFlowStartDt = row.FindControl("JOB_FLOW_START_DT") as TextBox; 
                TextBox jobFlowEndDt = row.FindControl("JOB_FLOW_END_DT") as TextBox;                
                
                RadioButtonList jobFlowStatus = row.FindControl("JOB_FLOW_STATUS") as RadioButtonList;                

                DropDownList notifyType = row.FindControl("ddlNtfType") as DropDownList;
                TextBox nofifyID = row.FindControl("txtNTF_ID") as TextBox;
                TextBox nofifyText = row.FindControl("txtNTF_TXT") as TextBox;

                DateTime _job_flow_start_dt;
                bool had_start_dt = DateTime.TryParse(jobFlowStartDt.Text, out _job_flow_start_dt);
                DateTime _job_flow_end_dt;
                bool had_end_dt = DateTime.TryParse(jobFlowEndDt.Text, out _job_flow_end_dt);

                if(!had_start_dt && jobFlowStatus.SelectedValue.Equals("S"))
                {
                    hasDate = false;
                    jobFlowStartDt.BackColor = Color.Bisque;
                    
                }
                else
                {
                    jobFlowStartDt.BackColor = Color.White;
                }

                if (!had_end_dt && jobFlowStatus.SelectedValue.Equals("S"))
                {
                    hasDate = false;
                    jobFlowEndDt.BackColor = Color.Bisque;
                }
                else
                {
                    jobFlowEndDt.BackColor = Color.White;
                }

                if(had_end_dt && had_start_dt)
                {
                    if(_job_flow_end_dt<_job_flow_start_dt)
                    {
                        dateCorrect = false;
                        jobFlowStartDt.BackColor = Color.Bisque;
                        jobFlowEndDt.BackColor = Color.Bisque;
                    }
                    else
                    {
                        jobFlowStartDt.BackColor = Color.White;
                        jobFlowEndDt.BackColor = Color.White;
                    }
                }

                            
                //有選通知方式
                if (notifyType.SelectedIndex > 0)
                {
                    if (string.IsNullOrEmpty(nofifyID.Text.Trim()))
                    {
                        hasID = false;
                        nofifyID.BackColor = Color.Bisque;
                    }
                    else
                    {
                        nofifyID.BackColor = Color.White;
                    }

                    if (string.IsNullOrEmpty(nofifyText.Text.Trim()))
                    {
                        hasTxt = false;
                        nofifyText.BackColor = Color.Bisque;
                    }
                    else
                    {
                        nofifyText.BackColor = Color.White;
                    }
                }

            }

            if (hasDate && dateCorrect && hasID && hasTxt) return true;

            StringBuilder msgSB=new StringBuilder();
            msgSB.Append(hasDate ? "" : "- 請設定正確日期; \r\n");
            msgSB.Append(dateCorrect ? "" : "- 資料迄日不可大於資料起日; \r\n");
            msgSB.Append(hasID ? "" : "- 有選擇通知方式時, 通知對象不可為空白; \r\n");
            msgSB.Append(hasTxt ? "" : "- 有選擇通知方式時, 補充資訊不可為空白; ");

            setMessage(false, msgSB.ToString());
            return false;
        }
        

        protected void btnOk_Click(object sender, EventArgs e)
        {
            if (!checkInput()) return;
            
            flowList=new List<FlowNTFEntity>();

            foreach (GridViewRow row in GridView1.Rows)
            {
                if (row.RowType == DataControlRowType.DataRow)
                {
                    flowList.Add(ReadFlowFromRow(row));
                }
            }

            JobFlowBO bo = new JobFlowBO();
            bo.UserName = this.UserName;
            this.setMessage(bo.replaceAll(flowList));
            
            ClientScript.RegisterStartupScript(GetType(), "Load", "<script type='text/javascript'>window.parent.location.href = 'JFCommandBatch.aspx'; </script>");

        }
       
    }
}