﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;

using NLog;
using System.Security.Principal;
using System.Web.Script.Serialization;
using gbs.bao.etl.entity;
using gbs.bao.etl.aa;
using gbs.bao.etl.dao;
using gbs.bao.etl.util;
using System.Text.RegularExpressions;

namespace ETLAdm
{
    public class Global : System.Web.HttpApplication
    {
        private static Logger logger = LogManager.GetCurrentClassLogger();
        protected void Application_Start(object sender, EventArgs e)
        {            
            logger.Info("Starting application");
            try
            {
                UserDAO dao = new UserDAO();
                dao.selectUserByName(Const.ETLADM);
            }
            catch (Exception ex)
            {
                logger.ErrorException(ex.Message, ex);
            }
        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        static Regex regex = new Regex(@"(\.)(aspx|ashx|js|css)", RegexOptions.IgnoreCase);

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

            if (Request.IsAuthenticated && regex.IsMatch(Request.Path))
            {
                // 先取得該使用者的 FormsIdentity
                FormsIdentity id = (FormsIdentity)User.Identity;
                // 再取出使用者的 FormsAuthenticationTicket
                FormsAuthenticationTicket ticket = id.Ticket;
                // 將儲存在 FormsAuthenticationTicket 中的角色定義取出，並轉成字串陣列
                try
                {
                    string[] roles = new string[0];
                    int prjId = -1;
                    if (ticket != null && !string.IsNullOrEmpty(ticket.UserData))
                    {
                        TicketData data = new JavaScriptSerializer().Deserialize<TicketData>(ticket.UserData);
                        prjId = data.PrjId;
                        roles = data.Roles.Split(new char[] { ',' });
                    }
                    // 指派角色到目前這個 HttpContext 的 User 物件去
                    Context.User = new EtlAdmPrincipal(Context.User.Identity, roles, prjId);
                }
                catch (Exception) { }
            }
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            
            Exception ex = Server.GetLastError();
            string errorMessage = "Url:[{0}] IP:[{1}] User:[{2}] Message:[{3}]\r\n{4}";
            string message = string.Format(errorMessage, 
                Request.Path, 
                Request.UserHostAddress,
                Request.IsAuthenticated ? Context.User.Identity.Name : "guest",
                ex.Message, 
                ex.StackTrace +
                (ex.InnerException == null ? "" : "\r\n ========> " + ex.GetType().FullName + "\t" + ex.InnerException.Message + "\r\n" + ex.InnerException.StackTrace)
            );

            logger.ErrorException(message, ex);
        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {
            logger.Info("End application");
        }
    }
}