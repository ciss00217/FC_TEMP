﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.util;
using gbs.bao.etl.entity;
using gbs.bao.etl.bo;
using gbs.bao.etl.dao;
using System.Text;
using gbs.bao.etl.Properties;

namespace ETLAdm.setting
{
    /// <summary>
    /// The page maintains the ETLJBD (include ETLJOB) and ETLJSD (include ETLJSP), and ETLJDP if remove the ETLJBD.
    /// </summary>
    public partial class JobSetting : EtlAdmPage
    {
        /// <summary>
        /// The index of MultiView Control.
        /// Page View:
        ///     0 : ETLJBD && ETLJSD (Gridview) can 
        ///         1.add/replace/remove ETLJBD
        ///         2.copy ETLJBD (include ETLJSD).
        ///         3.redirect to Detailview for add or update ETLJSD.
        ///         4.copy ETLJSD (include ETLJSP).
        ///         5.remove ETLJSD (include ETLJSP).
        ///     1 : ETLJBD && ETLJSD (Detailview)
        ///         1.add/replace ETLJSD (include ETLJSP).
        ///         2.redirect to Gridview
        /// </summary>
        private int View_GridView_0 = 0;
        private int View_DetailView_1 = 1;
        private int View_Empty_2 = 2;

        /// <summary>
        /// Regist the job types to javascript.
        /// </summary>
        private void ReigisterAryJobTypes()
        {
            JobDAO dao = new JobDAO();

            StringBuilder types = new StringBuilder();
            foreach (var v in dao.selectJOB_TYPEByPrjId(this.Project_Id))
            {                
                types.Append("\"").Append(v).Append("\",");
            }
            if (types.Length == 0)
            {
                ClientScript.RegisterArrayDeclaration("AryJobTypes", "");
            }
            else
            {                
                ClientScript.RegisterArrayDeclaration("AryJobTypes", types.ToString(0, types.Length - 1));                
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            // initial ConfigDAO.selectCfgByPrjIdAndType
            ObjectDataSource5.SelectParameters[0].DefaultValue = this.Project_Id + "";
            ReigisterAryJobTypes();

            if (!IsPostBack)
            {
                addJBD_Click(newJBD, null);
                DeployPanel.Visible = Settings.Default.JobFlowDeployEnable;                
            }
        }

        protected void PGM_TYPE_PreRender(object sender, EventArgs e)
        {
            DropDownList ddl = (DropDownList)sender;
            ddl.Items.FindByValue("Metadata").Enabled = Settings.Default.MetadataFlg;
            ddl.Items.FindByValue("DQ").Enabled = Settings.Default.DQFlg;
        }

        /// <summary>
        /// ETLJBD Copy event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCopy_Click(object sender, EventArgs e)
        {
            if (!IsReFlesh)
            {
                Button btn = sender as Button;
                int ap_id = int.Parse(btn.CommandArgument);
                JobBO bo = new JobBO();
                bo.UserName = this.UserName;
                ResultBean bean = setMessage(bo.copy(ap_id));
                if (bean.success)
                {
                    Master_DataBind(bean.data.ToString());
                    RegistSessionKeyUpdate();
                }
            }
            else
            {                
                Panel1.Visible = false;
            }
        }

        /// <summary>
        /// ETLJSD Copy event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnStepCopy_Click(object sender, EventArgs e)
        {
            if (!IsReFlesh)
            {
                Button btnStepCopy = sender as Button;
                string apId = btnStepCopy.CommandArgument;
                int iApId = int.Parse(apId);
                JobStepBO bo = new JobStepBO();
                bo.UserName = this.UserName;

                ResultBean bean = setMessage(bo.copy(iApId, null));
                if (bean.success)
                {
                    ETLJSD jsd = bean.data as ETLJSD;
                    if (listRunSeq == null)
                        listRunSeq = new List<int>();
                    else
                        listRunSeq.Clear();
                    for (int i = 1; i <= jsd.RUN_SEQ; i++)
                    {
                        listRunSeq.Add(i);
                    }
                    GridView1_DataBind();
                    RegistSessionKeyUpdate();
                }
            }
            else
            {
                
                Panel1.Visible = false;
            }
        }

        protected void btnStepCopyTo_Click(object sender, EventArgs e)
        {
            if (!IsReFlesh)
            {
                Button btnStepCopyTo = sender as Button;
                string apId = btnStepCopyTo.CommandArgument;
                //TODO

                RegistSessionKeyUpdate();
            }
            else
            {
                
                Panel1.Visible = false;
            }
        }

        protected void lnkJBD_Click(object sender, EventArgs e)
        {
            //LinkButton link = sender as LinkButton;

            Master_DataBind(SelectedJobApID.Value);
        }

        /// <summary>
        /// Bind the ETLJBD by ap id.
        /// </summary>
        /// <param name="ap_id"></param>
        protected void Master_DataBind(string ap_id)
        {
            listRunSeq = null;
            SelectedJobApID.Value = ap_id;
            Panel1.Visible = true;

            DetailsView1.ChangeMode(DetailsViewMode.Edit);
            DetailsView1.DefaultMode = DetailsViewMode.Edit;

            ObjectDataSource2.SelectParameters[0].DefaultValue = ap_id;
            DetailsView1.DataBind();
            
            GridView1_DataBind();
        }

        protected void addJBD_Click(object sender, EventArgs e)
        {   
            Panel1.Visible = true;
            
            DetailsView1.ChangeMode(DetailsViewMode.Insert);
            DetailsView1.DefaultMode = DetailsViewMode.Insert;

            MultiView1.ActiveViewIndex = View_Empty_2;
            SelectedJobApID.Value = string.Empty;
        }

        /// <summary>
        /// Show add job step command
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAddStep_Click(object sender, EventArgs e)
        {
            JobStepModeChange(DetailsViewMode.Insert, null);
        }

        /// <summary>
        /// Job ma' command: Add, Replace, Remove
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnOk_Click(object sender, EventArgs e)
        {
            if (!IsReFlesh)
            {
                Button btn = sender as Button;
                JobBO bo = new JobBO();
                bo.UserName = UserName;

                ResultBean result = null;
                string JOB_NAME = (ControlUtil.FindInTemplate(btn, "JOB_NAME") as TextBox).Text;
                string JOB_DESC = (ControlUtil.FindInTemplate(btn, "JOB_DESC") as TextBox).Text;
                string JOB_TYPE = (ControlUtil.FindInTemplate(btn, "JOB_TYPE") as TextBox).Text;
                string JOB_ID = (ControlUtil.FindInTemplate(btn, "JOB_ID") as HiddenField).Value;

                ETLJBD _jbd = new ETLJBD() { 
                    PRJ_ID = Project_Id,
                    JOB_NAME = JOB_NAME,
                    JOB_DESC = JOB_DESC,
                    JOB_TYPE = JOB_TYPE
                };

                switch (btn.CommandName)
                {
                    case Const.CMD_Add:
                        result = setMessage(bo.add(_jbd));
                        break;
                    case Const.CMD_Replace:
                        int ap_id = Convert.ToInt32(btn.CommandArgument);
                        _jbd.AP_ID = ap_id;
                        _jbd.JOB_ID = int.Parse(JOB_ID);
                        result = setMessage(bo.replace(_jbd));
                        break;
                    case Const.CMD_Remove:
                        ap_id = Convert.ToInt32(btn.CommandArgument);
                        result = setMessage(bo.remove(ap_id));
                        break;
                }
                if (result.success)
                {
                    

                    if (btn.CommandName == Const.CMD_Add || btn.CommandName == Const.CMD_Replace)
                    {
                        ETLJBD jbd = result.data as ETLJBD;
                        Master_DataBind(jbd.AP_ID.ToString());
                    }
                    else
                    {
                        Panel1.Visible = false;
                    }
                    RegistSessionKeyUpdate();
                }
            }
            else
            {
                
                Panel1.Visible = false;
            }
        }
        
        /// <summary>
        /// Switch the main window when job step window mode change.
        /// </summary>
        /// <param name="mode"></param>
        /// <param name="jsd_id"></param>
        protected void JobStepModeChange(DetailsViewMode mode, string jsd_id)
        {
            DetailsView2.ChangeMode(mode);
            DetailsView2.DefaultMode = mode;
            if (mode == DetailsViewMode.Insert)
            {
                MultiView1.ActiveViewIndex = View_DetailView_1;
                ObjectDataSource4.SelectParameters[0].DefaultValue = "-1";
                DetailsView2.DataBind();                       
            }
            else if (mode == DetailsViewMode.Edit)
            {
                MultiView1.ActiveViewIndex = View_DetailView_1;
                ObjectDataSource4.SelectParameters[0].DefaultValue = jsd_id;
            }
            else
            {
                MultiView1.ActiveViewIndex = View_GridView_0;
            }
        }


        /// <summary>
        /// The job step list under the job profile in center window.
        /// </summary>
        /// <param name="ap_id"></param>
        protected void GridView1_DataBind()
        {
            string ap_id = this.SelectedJobApID.Value;
            MultiView1.ActiveViewIndex = 0;
            ObjectDataSource3.SelectParameters[0].DefaultValue = ap_id;
            GridView1.DataBind();
        }


        /// <summary>
        /// Click the modify button in Job step list(gridview).
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnModify_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            JobStepModeChange(DetailsViewMode.Edit, btn.CommandArgument);
        }

        /// <summary>
        /// Click the job step ok button in Job step detail(detailview2).
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnStepOk_Click(object sender, EventArgs e)
        {   
            if (!IsReFlesh)
            {
                Button btn = sender as Button;

                JobStepBO bo = new JobStepBO();
                bo.UserName = UserName;
                ControlBindHelper<ETLJSD> helper = new ControlBindHelper<ETLJSD>();
                ResultBean result = null;

                JobDAO dao = new JobDAO();
                int jobApId = Convert.ToInt32(this.SelectedJobApID.Value);
                ETLJBD jbd = dao.selectJBDByApId(jobApId);
                switch (btn.CommandName)
                {
                    case Const.CMD_Add:
                        ETLJSD jsd = resetJSDByFailFlag(helper.Bind(btn.NamingContainer));
                        jsd.PRJ_ID = this.Project_Id;
                        jsd.JOB_ID = jbd.JOB_ID;
                        if (jsd.CONN_NAME == "-1")
                        {
                            jsd.CONN_NAME = null;
                        }
                        result = setMessage(bo.add(jsd));
                        break;
                    case Const.CMD_Replace:
                        jsd = resetJSDByFailFlag(helper.Bind(btn.NamingContainer));
                        jsd.PRJ_ID = this.Project_Id;
                        jsd.JOB_ID = jbd.JOB_ID;
                        if (jsd.CONN_NAME == "-1")
                        {
                            jsd.CONN_NAME = null;
                        }
                        jsd.AP_ID = Convert.ToInt32(btn.CommandArgument);
                        result = setMessage(bo.replace(jsd));
                        break;
                    case Const.CMD_Remove:
                        int ap_id = Convert.ToInt32(btn.CommandArgument);
                        result = setMessage(bo.remove(ap_id));
                        break;
                }

                if (result.success)
                {
                    Master_DataBind(jobApId.ToString());
                    RegistSessionKeyUpdate();
                }
            }
            else
            {
                
                Panel1.Visible = false;                
            }
        }

        protected void FAIL_FLAG_Load(object sender, EventArgs e)
        {
            RadioButtonList radio = sender as RadioButtonList;
            string script = "fail_flag_changed(this);";
            radio.Attributes.Add("onclick", script);
        }

        protected ETLJSD resetJSDByFailFlag(ETLJSD jsd)
        {
            if (Const.FAIL_FLAG_R.Equals(jsd.FAIL_FLAG))
            {
                jsd.RETRY_CNT = jsd.RETRY_CNT == null ? Const.DEFAULT_RETRY_CNT : jsd.RETRY_CNT;
                jsd.RETRY_MINS = jsd.RETRY_MINS == null ? Const.DEFAULT_RETRY_MINS : jsd.RETRY_MINS;                
            }
            else
            {                
                jsd.RETRY_CNT = 0;
                jsd.RETRY_MINS = 1;                
            }
            if (jsd.PGM_TYPE != Const.PGM_TYPE_SQL)
            {
                jsd.DB_PARMS = string.Empty;
            }
            if (!(jsd.PGM_TYPE == Const.PGM_TYPE_EXE || jsd.PGM_TYPE == Const.PGM_TYPE_SH))
            {
                jsd.PRE_JOB_PARMS = string.Empty;
            }
            return jsd;
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            JobStepModeChange(DetailsViewMode.ReadOnly, null);
        }

        private List<int> listRunSeq;

        protected void RUN_SEQ_Binding(object sender, EventArgs e)
        {
            DropDownList ddl = sender as DropDownList;
            if(listRunSeq==null)
                listRunSeq = new JobStepBO().listRunSeq(Convert.ToInt32( this.SelectedJobApID.Value));
            if (ddl.Items.Count == 0)
            {
                for (int i = 0; i < listRunSeq.Count(); i++)
                {
                    ddl.Items.Add(listRunSeq[i].ToString());
                }
            }
        }



        protected void RUN_SEQ_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!IsReFlesh)
            {
                DropDownList ddl = sender as DropDownList;
                int jsd_id = Convert.ToInt32(ddl.ToolTip);
                short newSeq = Convert.ToInt16(ddl.SelectedValue);

                JobStepBO bo = new JobStepBO();
                bo.UserName = UserName;
                ResultBean bean = bo.ReOrder(this.Project_Id, Convert.ToInt32(this.SelectedJobApID.Value), jsd_id, newSeq);
                if (bean.success)
                {
                    
                    GridView1_DataBind();
                    RegistSessionKeyUpdate();
                }
                else
                {
                    GridView1_DataBind();
                    setMessage(bean);
                }
            }
            else
            {
                
                Panel1.Visible = false;
            }
        }

        protected void PGM_TYPE_SelectedIndexChanged(DropDownList PGM_TYPE, bool conn_bind)
        {
            bool hadConn = false;
            bool hadConnValidate = false;
            string type = string.Empty;
            switch (PGM_TYPE.SelectedValue)
            {
                case Const.PGM_TYPE_SQL:
                    hadConn = true;
                    hadConnValidate = true;
                    type = Const.CFG_TYPE_DB;
                    break;
                case Const.PGM_TYPE_WATCH:
                    hadConn = true;
                    hadConnValidate = false;
                    type = Const.CFG_TYPE_DB;
                    break;
                case Const.PGM_TYPE_FTPIN:
                case Const.PGM_TYPE_FTPOUT:
                    hadConn = true;
                    hadConnValidate = false;
                    type = Const.CFG_TYPE_FTP;                    
                    break;
                default:
                    break;
            }

            DropDownList CONN_NAME = ControlUtil.FindInTemplate(PGM_TYPE, "CONN_NAME") as DropDownList;
            RequiredFieldValidator RequiredFieldValidator5 = ControlUtil.FindInTemplate(PGM_TYPE, "RequiredFieldValidator5") as RequiredFieldValidator;
            CONN_NAME.Enabled = hadConn;
            RequiredFieldValidator5.Enabled = hadConnValidate;

            //selectCfgByPrjIdAndType
            CONN_NAME.Items.Clear();
            CONN_NAME.Items.Add(new ListItem("---請選擇---", "-1"));
            ObjectDataSource5.SelectParameters["type"].DefaultValue = type;
            CONN_NAME.DataSource = ObjectDataSource5.Select();
            if(conn_bind)
                CONN_NAME.DataBind();

            PARAM_Enabled(PGM_TYPE, PGM_TYPE.SelectedValue);
        }

        protected void PGM_TYPE_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList PGM_TYPE = sender as DropDownList;

            PGM_TYPE_SelectedIndexChanged(PGM_TYPE, true);

        }

        protected void PARAM_Enabled(Control ctrl, string pgm_type)
        {
            bool isDB_PARMS_Enabled = pgm_type == Const.PGM_TYPE_SQL || pgm_type == Const.PGM_TYPE_WATCH;
            bool isJS_PARMS_Enabled = true;
            bool isPRE_JOB_PARMS_Enabled = pgm_type == Const.PGM_TYPE_SH || pgm_type == Const.PGM_TYPE_EXE;

            TextBox DB_PARMS = ControlUtil.FindInTemplate(ctrl, "DB_PARMS") as TextBox;
            TextBox JS_PARMS = ControlUtil.FindInTemplate(ctrl, "JS_PARMS") as TextBox;
            TextBox PRE_JOB_PARMS = ControlUtil.FindInTemplate(ctrl, "PRE_JOB_PARMS") as TextBox;


            DB_PARMS.Enabled = isDB_PARMS_Enabled;
            DB_PARMS.CssClass = DB_PARMS.Enabled ? "" : "textbox_disabled";
            JS_PARMS.Enabled = isJS_PARMS_Enabled;
            JS_PARMS.CssClass = JS_PARMS.Enabled ? "" : "textbox_disabled";
            PRE_JOB_PARMS.Enabled = isPRE_JOB_PARMS_Enabled;
            PRE_JOB_PARMS.CssClass = PRE_JOB_PARMS.Enabled ? "" : "textbox_disabled";
        }

        protected void PGM_TYPE_DataBinding(object sender, EventArgs e)
        {
            DropDownList PGM_TYPE = sender as DropDownList;
            PGM_TYPE_SelectedIndexChanged(PGM_TYPE, false);
        }

        protected void PGM_TYPE_DataBound(object sender, EventArgs e)
        {
            DropDownList PGM_TYPE = sender as DropDownList;            
            HiddenField hdnCONN_NAME = ControlUtil.FindInTemplate(PGM_TYPE, "hdnCONN_NAME") as HiddenField;
            DropDownList CONN_NAME = ControlUtil.FindInTemplate(PGM_TYPE, "CONN_NAME") as DropDownList;
            CONN_NAME.SelectedValue = hdnCONN_NAME.Value;
        }

        protected string ClearAllScript(Control c)
        {
            return string.Format("$('table#{0}').clearAll(true); return false;", c.ClientID);
        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DropDownList ddl = e.Row.FindControl("RUN_SEQ") as DropDownList;
                if (ddl != null)
                {                    
                    this.RUN_SEQ_Binding(ddl, null);
                    ddl.SelectedValue = ddl.Attributes["RunSeqNumber"];
                }
            }
        }
    }
}
