﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using gbs.bao.etl.bo.json;
using System.Text;

namespace ETLAdm.setting
{
    /// <summary>
    ///JobFlowExport 的摘要描述
    /// </summary>
    public class JobFlowExport : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            string content = string.Empty;
            if (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["ExportData"]))
            {
                content = HttpContext.Current.Request.Form["ExportData"];
            }
            else
            {
                IBo bo = JsonSvcBoFactory.Instance.CreateBo(JsonSvcConst.GetJobFlow);
                content = bo.execute(InputParameters());
            }
            //TODO Get Jobs and conbine to content

            byte[] bytes = Encoding.UTF8.GetBytes(content);
            HttpContext.Current.Response.ClearHeaders();
            HttpContext.Current.Response.ClearContent();
            HttpContext.Current.Response.AppendHeader("Content-Length", bytes.Length.ToString());
            HttpContext.Current.Response.ContentType = "application/x-zip-compressed";
            HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment; filename=Export.json");
            HttpContext.Current.Response.BinaryWrite(bytes);
            HttpContext.Current.Response.End();
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        private string InputParameters()
        {
            HttpRequest request = HttpContext.Current.Request;
            
            var JOB_FLOW_ID = request.QueryString["JOB_FLOW_ID"];
            int ap_id = Convert.ToInt32(JOB_FLOW_ID);
            return string.Format("{{'JOB_FLOW_ID':{0}}}", ap_id);
        }
    }
}