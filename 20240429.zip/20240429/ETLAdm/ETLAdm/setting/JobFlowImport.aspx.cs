﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.util;
using gbs.bao.etl.dao;
using gbs.bao.etl.entity.proxy;
using gbs.bao.etl.bo;
using gbs.bao.etl.entity;
using System.Xml;
using System.IO;
using System.Text;
using System.Xml.Serialization;
using gbs.bao.etl.entity.deploy;
using System.Drawing;

namespace ETLAdm.setting
{
    public partial class JobFlowImport : EtlAdmPage
    {
        protected override void Page_Init(object sender, EventArgs e)
        {
            base.Page_Init(sender, e);
            ((SiteMaster)Page.Master).HideTop1 = true;
            ((SiteMaster)Page.Master).HideLeft1 = true;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                
            }
        }

        List<ETLJFQ> freqs = null;

        protected void RUN_FREQ_ID_DataBinding(object sender, EventArgs e)
        {
            HiddenField freq = (HiddenField)sender;
            DropDownList ddl = (DropDownList)freq.NamingContainer.FindControl("RUN_FREQ");
            if (freqs == null)
            {
                freqs = new FrequencyDAO().selectByPrjId(this.Project_Id);
                freqs.Insert(0, new ETLJFQ() { RUN_FREQ_ID = -1, RUN_FREQ_NAME = "---請選擇---" });
            }
            if (ddl.Items.Count == 0)
            {
                ddl.DataSource = freqs;
                ddl.DataBind();
            }
            if (ddl.Items.FindByValue(freq.Value) != null)
            {
                ddl.SelectedValue = freq.Value;
            }
        }

        protected void Wizard1_NextButtonClick(object sender, WizardNavigationEventArgs e)
        {
            int idx = e.CurrentStepIndex;
           
            switch (idx)
            {
                case 0:
                    if (FileUpload1.HasFile)
                    {
                        
                        string fileExt = System.IO.Path.GetExtension(FileUpload1.FileName);
                        if (".XML".Equals(fileExt, StringComparison.OrdinalIgnoreCase))
                        {
                            ResultBean result = IOUtility.Save(Server, FileUpload1);
                            if (result.success)
                            {
                                GridView1_DataBind(result);
                            }
                            else
                            {
                                setMessage(result);
                                e.Cancel = true;
                            }
                        }
                    }
                    break;
            }
            
        }

        private void GridView1_DataBind(ResultBean result)
        {
            string path = result.data.ToString();
            Path.Value = Convert.ToBase64String(Encoding.Default.GetBytes(path));
            IETLRepository bean = IOUtility.FromXml<IETLRepository>(path);

            var jobFlows = new JobFlowDAO().selectByPrjIdOrderByName(this.Project_Id);

            var v = from _f in bean.IETLJFWs
                    join _s in jobFlows on _f.JOB_FLOW_NAME equals _s.JOB_FLOW_NAME into _fs
                    from _s in _fs.DefaultIfEmpty()
                    select new IETLJFW() { 
                        PRJ_ID = this.Project_Id,
                        JOB_FLOW_ID = _f.JOB_FLOW_ID,
                        JOB_FLOW_NAME = _f.JOB_FLOW_NAME,
                        JOB_FLOW_DESC = _f.JOB_FLOW_DESC,
                        JOB_FLOW_TYPE = _f.JOB_FLOW_TYPE,
                        JF_PARMS = _f.JF_PARMS,
                        ARCHIVE_PATH = _f.ARCHIVE_PATH,
                        JOB_FLOW_START_DT = _s == null ? _f.JOB_FLOW_START_DT : _s.JOB_FLOW_START_DT, // db first then file 
                        JOB_FLOW_END_DT = _s == null ? _f.JOB_FLOW_END_DT : _s.JOB_FLOW_END_DT, // db first then file
                        RUN_FREQ_ID = _s == null ? -1 : _s.RUN_FREQ_ID // db only
                    };

            GridView1.DataSource = v;
            GridView1.DataBind();
        }

        protected void Wizard1_FinishButtonClick(object sender, WizardNavigationEventArgs e)
        {
            List<string> messages = new List<string>();
            string currentStep = "";
            string prcsId = DateTime.Now.ToString("yyyyMMddHHmmss");
            messages.Add("PROCESS ID:" + prcsId);
            logger.Info(">>>>>>>>>>>>>>>>>>>>>>>>> PROCESS ID:" + prcsId);
            Dictionary<string, object> prcs = InitInjectValues(prcsId);
            try
            {
                ETLPRJ prj = new ProjectDAO().selectProjectsById(this.Project_Id);
                if (prj == null)
                {
                    prj = new ETLPRJ();
                }
                currentStep = "讀取匯入檔";
                messages.Add("1. 開始" + currentStep);
                IETLRepository bean = ReadFromXml();
                messages.Add("=>" + DateTime.Now.ToString("HH:mm:ss") + " 成功...");

                currentStep = "讀取Job定義檔";
                messages.Add("　1-1. 開始" + currentStep);
                List<ETLJBD_STG> jbdStgs = InitJBD_STG(prcs, bean);
                messages.Add("　=> " + DateTime.Now.ToString("HH:mm:ss") + " 成功...");

                currentStep = "讀取Job Step定義檔";
                messages.Add("　1-2. 開始" + currentStep);
                List<ETLJSD_STG> jsdStgs = InitJSD_STG(prcs, bean);
                messages.Add("　=> " + DateTime.Now.ToString("HH:mm:ss") + " 成功...");

                currentStep = "讀取Job Flow設定檔";
                messages.Add("　1-3. 開始" + currentStep);
                List<ETLJFW_STG> jfwStgs = InitJFW_STG(prcs, bean);
                messages.Add("　=> " + DateTime.Now.ToString("HH:mm:ss") + " 成功...");

                currentStep = "讀取Job設定檔";
                messages.Add("　1-4. 開始" + currentStep);
                List<ETLJOB_STG> jobStgs = InitJobStg(prcs, bean);
                messages.Add("　=> " + DateTime.Now.ToString("HH:mm:ss") + " 成功...");

                currentStep = "讀取Job相依設定檔";
                messages.Add("　1-5. 開始" + currentStep);
                List<ETLJDP_STG> jdpStgs = InitJDP_STG(prcs, bean);
                messages.Add("　=> " + DateTime.Now.ToString("HH:mm:ss") + " 成功...");

                currentStep = "設定參數";
                messages.Add("2. 開始" + currentStep);
                ResetFlowAndJobByArgs(jfwStgs, jobStgs);
                messages.Add("=> " + DateTime.Now.ToString("HH:mm:ss") + " 成功...");

                currentStep = "寫入暫存區";
                messages.Add("3. 開始" + currentStep);
                BulkInsertAll(jbdStgs, jsdStgs, jfwStgs, jobStgs, jdpStgs);
                messages.Add("=> " + DateTime.Now.ToString("HH:mm:ss") + " 成功...");
                using (ETLDB_STGDataContext context = new ETLDB_STGDataContext())
                {
                    context.Log = new gbs.bao.etl.util.NLogTextWriter(this.logger);
                    currentStep = "寫入定義檔";
                    messages.Add("4. 開始" + currentStep);
                    context.ps_MergeJbd(prcsId,prj.PRJ_NAME, this.UserName);
                    messages.Add("=> " + DateTime.Now.ToString("HH:mm:ss") + " 成功...");

                    currentStep = "寫入設定檔";
                    messages.Add("5. 開始" + currentStep);
                    
                    context.ps_MergeJfwAndStage(prcsId,prj.PRJ_NAME, this.UserName);
                    messages.Add("=> " + DateTime.Now.ToString("HH:mm:ss") + " 成功...");
                }
                ResultMessage.ForeColor = Color.Green;
                ResultMessage.Text = "◆ 匯入Job Flow完成 ◆";
                this.logger.Info("◆ 匯入Job Flow完成 ◆" + string.Join("\r\n", messages.ToArray()));
            }
            catch (Exception ex)
            {                
                ResultMessage.ForeColor = Color.Red;
                ResultMessage.Text = "◇ 匯入失敗 ◇";
                messages.Add("=> " + DateTime.Now.ToString("HH:mm:ss") + " 失敗!!!");
                messages.Add("★" + ex.GetType().Name + "　" + ex.Message);
                this.logger.Error("◇ 匯入Job Flow失敗 ◇" + string.Join("\r\n", messages.ToArray()), ex);

                using (ETLDB_STGDataContext context = new ETLDB_STGDataContext())
                {

                    var stgJbd = new StgJobDAO()
                    {
                        context = context
                    }.SelectByPrcsId(prcsId).Where(x => !"S".Equals(x.PRCS_ST, StringComparison.OrdinalIgnoreCase))
.OrderBy(x => x.PRCS_ST);
                    if (stgJbd.Any())
                    {
                        gridJbd.Visible = true;
                        gridJbd.DataSource = stgJbd;
                        gridJbd.DataBind();
                    }
                    else
                    {
                        gridJbd.Visible = false;
                    }

                    var stgJsd = new StgJobStepDAO()
                    {
                        context = context
                    }.SelectByPrcsId(prcsId).Where(x => !"S".Equals(x.PRCS_ST, StringComparison.OrdinalIgnoreCase))
.OrderBy(x => x.PRCS_ST);
                    if (stgJsd.Any())
                    {
                        gridJsd.Visible = true;
                        gridJsd.DataSource = stgJsd;
                        gridJsd.DataBind();
                    }
                    else
                    {
                        gridJbd.Visible = false;
                    }


                    var stgJfw = new StgJobFlowDAO()
                    {
                        context = context
                    }.SelectByPrcsId(prcsId).Where(x=>!"S".Equals(x.PRCS_ST, StringComparison.OrdinalIgnoreCase))
                    .OrderBy(x=>x.PRCS_ST);
                    if (stgJfw.Any())
                    {
                        gridFlow.Visible = true;
                        gridFlow.DataSource = stgJfw;
                        gridFlow.DataBind();
                    }
                    else
                    {
                        gridFlow.Visible = false;
                    }


                    var stgJob = new StgJobInstDAO()
                    {
                        context = context
                    }.SelectByPrcsId(prcsId).Where(x => !"S".Equals(x.PRCS_ST, StringComparison.OrdinalIgnoreCase))
                    .OrderBy(x=>x.PRCS_ST);
                    if (stgJob.Any())
                    {
                        gridJob.Visible = true;
                        gridJob.DataSource = stgJob;
                        gridJob.DataBind();
                    }
                    else
                    {
                        gridJob.Visible = false;
                    }
                    var stgJdp = new StgJobRelationDAO()
                    {
                        context = context
                    }.SelectByPrcsId(prcsId).Where(x => !"S".Equals(x.PRCS_ST, StringComparison.OrdinalIgnoreCase))
                    .OrderBy(x=>x.PRCS_ST);
                    if (stgJdp.Any())
                    {
                        gridJdp.Visible = true;
                        gridJdp.DataSource = stgJdp;
                        gridJdp.DataBind();
                    }
                    else
                    {
                        gridJdp.Visible = false;
                    }

                }
            }
            Repeater1.DataSource = messages;
            Repeater1.DataBind();
        }

        private void ResetFlowAndJobByArgs(List<ETLJFW_STG> jfwStgs, List<ETLJOB_STG> jobStgs)
        {
            foreach (GridViewRow row in GridView1.Rows)
            {
                if (row.RowType == DataControlRowType.DataRow)
                {
                    ResetFlowAndJobByArgsInRow(jfwStgs, jobStgs, row);
                }
            }
        }

        private static void ResetFlowAndJobByArgsInRow(List<ETLJFW_STG> jfwStgs, List<ETLJOB_STG> jobStgs, GridViewRow row)
        {
            HiddenField jobFlowId = row.FindControl("JOB_FLOW_ID") as HiddenField;
            string flowId = jobFlowId.Value;
            ETLJFW_STG jfw = jfwStgs.First(x => flowId.Equals(x.JOB_FLOW_ID + ""));

            DropDownList runFreq = row.FindControl("RUN_FREQ") as DropDownList;
            TextBox jobFlowStartDt = row.FindControl("JOB_FLOW_START_DT") as TextBox;
            TextBox jobFlowEndDt = row.FindControl("JOB_FLOW_END_DT") as TextBox;
            string runFreqVal = runFreq.SelectedValue;
            string runFreqName = runFreq.SelectedItem.Text;
            string startDtVal = jobFlowStartDt.Text;
            string endDtVal = jobFlowEndDt.Text;

            ResetFlow(jfw, runFreqVal,runFreqName, startDtVal, endDtVal);
            ResetJobDt(jobStgs, flowId, jfw);
        }

        private void BulkInsertAll(List<ETLJBD_STG> jbdStgs, List<ETLJSD_STG> jsdStgs, List<ETLJFW_STG> jfwStgs, List<ETLJOB_STG> jobStgs, List<ETLJDP_STG> jdpStgs)
        {
            using (ETLDB_STGDataContext context = new ETLDB_STGDataContext())
            {
                context.Log = new gbs.bao.etl.util.NLogTextWriter(this.logger);
                new StgJobDAO() { context = context }.BulkInsert(jbdStgs);
                new StgJobStepDAO() { context = context }.BulkInsert(jsdStgs);
                new StgJobFlowDAO() { context = context }.BulkInsert(jfwStgs);
                new StgJobInstDAO() { context = context }.BulkInsert(jobStgs);
                new StgJobRelationDAO() { context = context }.BulkInsert(jdpStgs);
            }
        }
        
        private static void ResetFlow(ETLJFW_STG jfw, string runFreqVal,string runFreqName, string startDtVal, string endDtVal)
        {
            if (!"-1".Equals(runFreqVal))
            {
                jfw.RUN_FREQ_ID = int.Parse(runFreqVal);
                jfw.RUN_FREQ_NAME = runFreqName;
            }
            else
            {
                jfw.RUN_FREQ_ID = -1;
            }
            if (!string.IsNullOrEmpty(startDtVal))
            {
                jfw.JOB_FLOW_START_DT = DateTime.Parse(startDtVal);
            }
            if (!string.IsNullOrEmpty(endDtVal))
            {
                jfw.JOB_FLOW_END_DT = DateTime.Parse(endDtVal);
            }
        }

        private static void ResetJobDt(List<ETLJOB_STG> jobStgs, string flowId, ETLJFW_STG jfw)
        {
            foreach (var job in jobStgs.Where(x => flowId.Equals(x.JOB_FLOW_ID + "")))
            {
                job.JOB_START_DT = jfw.JOB_FLOW_START_DT;
                job.JOB_END_DT = jfw.JOB_FLOW_END_DT;
            }
        }

        private static List<ETLJDP_STG> InitJDP_STG(Dictionary<string, object> prcs, IETLRepository bean)
        {
            // ETLJDP_STG
            List<ETLJDP_STG> jdpStgs = new List<ETLJDP_STG>();
            if (bean.IETLJDPs != null)
            {
                jdpStgs.AddRange(bean.IETLJDPs.Select(x => StaticProxyHelper.proxyIt<ETLJDP_STG>(x, ProxyMode.Property2Property, prcs, null)));
            }
            return jdpStgs;
        }

        private static List<ETLJOB_STG> InitJobStg(Dictionary<string, object> prcs, IETLRepository bean)
        {
            // ETLJOB_STG
            List<ETLJOB_STG> jobStgs = new List<ETLJOB_STG>();
            if (bean.IETLJOBs != null)
            {
                jobStgs.AddRange(bean.IETLJOBs.Select(x => StaticProxyHelper.proxyIt<ETLJOB_STG>(x, ProxyMode.Property2Property, prcs, null)));
            }
            return jobStgs;
        }

        private static List<ETLJFW_STG> InitJFW_STG(Dictionary<string, object> prcs, IETLRepository bean)
        {
            // ETLJFW_STG
            List<ETLJFW_STG> jfwStgs = new List<ETLJFW_STG>();
            if (bean.IETLJFWs != null)
            {
                jfwStgs.AddRange(bean.IETLJFWs.Select(x => StaticProxyHelper.proxyIt<ETLJFW_STG>(x, ProxyMode.Property2Property, prcs, null)));
            }
            return jfwStgs;
        }

        private static List<ETLJSD_STG> InitJSD_STG(Dictionary<string, object> prcs, IETLRepository bean)
        {
            List<ETLJSD_STG> jsdStgs = new List<ETLJSD_STG>();
            // ETLJSD_STG
            if (bean.IETLJSDs != null)
            {
                jsdStgs.AddRange(bean.IETLJSDs.Select(x => StaticProxyHelper.proxyIt<ETLJSD_STG>(x, ProxyMode.Property2Property, prcs, null)));
            }
            return jsdStgs;
        }

        private static List<ETLJBD_STG> InitJBD_STG(Dictionary<string, object> prcs, IETLRepository bean)
        {
            // ETLJBD_STG
            List<ETLJBD_STG> jbdStgs = new List<ETLJBD_STG>();
            if (bean.IETLJBDs != null)
            {
                jbdStgs.AddRange(bean.IETLJBDs.Select(x => StaticProxyHelper.proxyIt<ETLJBD_STG>(x, ProxyMode.Property2Property, prcs, null)));
            }
            return jbdStgs;
        }

        private IETLRepository ReadFromXml()
        {
            string path = Encoding.Default.GetString(Convert.FromBase64String(Path.Value));
            IETLRepository bean = IOUtility.FromXml<IETLRepository>(path);
            return bean;
        }

        private Dictionary<string, object> InitInjectValues(string prcsId)
        {
            Dictionary<string, object> prcs = new Dictionary<string, object>();
            prcs.Add("PRJ_ID", this.Project_Id);
            prcs.Add("PRCS_ID", prcsId);
            prcs.Add("PRCS_INFO", string.Empty);
            prcs.Add("PRCS_ST", Const.DEPLOY_ST_I);
            prcs.Add("CMD", Const.DEPLOY_CMD_REFLESH);
            prcs.Add("TBL_UPD_TIM", DateTime.Now);
            prcs.Add("TBL_UPDATER", this.UserName);
            return prcs;
        }
    }
}