﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.util;
using gbs.bao.etl.dao;
using gbs.bao.etl.entity;
using System.Text;

namespace ETLAdm.monitor
{
    public partial class JobStepHistory : EtlAdmPage
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (PreviousPage != null)
                {
                    string job_flow_run_id = PreviousPage.TheHdnFlowRunID.Value;
                    string job_run_id = PreviousPage.TheHdnJobRunID.Value;
                    string job_flow_id = PreviousPage.TheHdnFlowID.Value;
                    string job_id = PreviousPage.TheHdnJobID.Value;

                    ObjectDataSource1.SelectParameters["prj_id"].DefaultValue = this.Project_Id + "";
                    ObjectDataSource1.SelectParameters["job_flow_run_id"].DefaultValue = job_flow_run_id;
                    ObjectDataSource1.SelectParameters["job_run_id"].DefaultValue = job_run_id;
                    ObjectDataSource1.SelectParameters["job_flow_id"].DefaultValue = job_flow_id;
                    ObjectDataSource1.SelectParameters["job_id"].DefaultValue = job_id;
                    GridView_Job_Steps.DataBind();
                }

            }
        }
        /// <summary>
        /// 組合 JavaScript 內容
        /// </summary>
        /// <param name="run_start_tim"></param>
        /// <param name="prj_id"></param>
        /// <param name="job_flow_id"></param>
        /// <param name="job_id"></param>
        /// <param name="job_step_id"></param>
        /// <param name="job_flow_run_id"></param>
        /// <param name="job_run_id"></param>
        /// <param name="job_step_run_id"></param>
        /// <param name="job_step_retry_id"></param>
        /// <returns></returns>
        protected string BtnShowLog_OnClientClick(object run_start_tim, object prj_id,
            object job_flow_id, object job_id, object job_step_id,
            object job_flow_run_id, object job_run_id, 
            object job_step_run_id, object job_step_retry_id)
        {
            StringBuilder buf = new StringBuilder();

            if (run_start_tim == null)
                return "return false;";

            string EXECUTION_DT = ((DateTime)run_start_tim).ToString("yyyy/MM/dd");

            buf.Append("ShowLog('{");
            buf.Append("EXECUTION_DT:\"").Append(EXECUTION_DT).Append("\",");
            buf.Append("PRJ_ID:").Append(prj_id).Append(",");
            buf.Append("JOB_FLOW_ID:").Append(job_flow_id).Append(",");
            buf.Append("JOB_ID:").Append(job_id).Append(",");
            buf.Append("JOB_STEP_ID:").Append(job_step_id).Append(",");
            buf.Append("JOB_FLOW_RUN_ID:\"").Append(job_flow_run_id).Append("\",");
            buf.Append("JOB_RUN_ID:").Append(job_run_id).Append(",");
            buf.Append("JOB_STEP_RUN_ID:").Append(job_step_run_id).Append(",");
            buf.Append("JOB_STEP_RETRY_ID:").Append(job_step_retry_id);

            buf.Append("}'); return false;");

            return buf.ToString();
        }

    }
}
