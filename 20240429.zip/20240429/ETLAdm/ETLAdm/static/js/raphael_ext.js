﻿/* depends on jquery.js, raphael.js */
var CommandMode_UpdateFlow = 'UpdateFlow';
var CommandMode_AddJob = 'AddJob';
var CommandMode_RemoveJob = 'RemoveJob';
var CommandMode_SwitchJob = 'SwitchJob';
var CommandMode_Connection = 'Connection';

var firstRectText;
var CurrentCommandMode;

var connections = [];
var rectTexts = [];

connections.lookup = function(line) {
    for (var j = this.length - 1; j > -1; j--) {
        var _conn = this[j];
        if (line == _conn.line) {
            return _conn;
        }
    }
    return null;
}

connections.remove = function(connection) {
    for (var i = this.length - 1; i > -1; i--) {
        var n = this[i];
        if (n == connection) {
            n.from.child.remove(n.to);
            n.to.parent.remove(n.from);
            n.line.remove();
            n.arrow.remove();
            this.splice(i, 1);
        }
    }
}

connections.removeByRectText = function(rectText) {
    for (var i = this.length - 1; i > -1; i--) {
        var n = this[i];
        if (rectText == n.from || rectText == n.to) {
            n.from.child.remove(n.to);
            n.to.parent.remove(n.from);
            n.line.remove();
            n.arrow.remove();
            this.splice(i, 1);
        }
    }
}

rectTexts.lookup = function(obj) {
    for (var j = this.length - 1; j > -1; j--) {
        var _rectText = this[j];
        if (obj.type == "text" && obj == _rectText.text) {
            return _rectText;
        } else if (obj.type == "rect" && obj == _rectText.rect) {
            return _rectText;
        } else if (obj == _rectText.id()) {
            return _rectText;
        }
    }
    return null;
}

rectTexts.inParent = function(rectText, parent) {
    var src = rectText;
    var parents = parent == undefined ? src.parent : parent;
    var rtnVal = jQuery.inArray(rectText, parents) != -1
    if (rtnVal) {
        return rtnVal;
    }

    if (parents.length > 0) {
        for (var i = 0; i < parents.length; i++) {
            rtnVal = this.inParent(src, parents[i].parent);
            if (rtnVal)
                return rtnVal;
        }
    }
    return rtnVal;
}

rectTexts.remove = function(rectText) {
    connections.removeByRectText(rectText);
    for (var i = this.length - 1; i > -1; i--) {
        var n = this[i];
        if (n == rectText) {
            rectText.st.clear();
            rectText.text.remove();
            rectText.rect.remove();
            rectText.child = null;
            rectText.parent = null;
            this.splice(i, 1);
        }
    };
}

var ColorMaker = (function() {
    var index = -1;
    var colors = [
  Raphael.getRGB('#153450').hex
, Raphael.getRGB('#E07628').hex
, Raphael.getRGB('#447294').hex
, Raphael.getRGB('#294052').hex
, Raphael.getRGB('#8FBCDB').hex
, Raphael.getRGB('#397249').hex
, Raphael.getRGB('#9CB770').hex
, Raphael.getRGB('#628B61').hex
, Raphael.getRGB('#C7E1BA').hex
, Raphael.getRGB('#AD7460').hex
, Raphael.getRGB('#A84A5C').hex
, Raphael.getRGB('#D6A354').hex
, Raphael.getRGB('#BF381A').hex
, Raphael.getRGB('#88382D').hex
, Raphael.getRGB('#E9AF32').hex

];
    var colorLength = colors.length;
    var getColor = function() {
        index++;

        if (index % colorLength == 0) {           
            index = 0;
        }
        return colors[index];
    };

    var reset = function() {
        index = -1;
    };

    return {
        'getColor': getColor,
        'reset': reset
    }
})();

var PositionXMaker = (function() {
    var width = 11;

    var setWidth = function(w) {
        width = w;
    }

    var indexSet = [];

    var getX = function(x) {
        var index = indexSet[x];
        if (index) {
            index++;
        } else {
            index = 1;
        }
        if (index % 8 == 0) {
            index = 1;
        }
        indexSet[x] = index;
        return index * width;
    };

    var reset = function() {
        for (var i = 0; i < indexSet.length; i++) {
            indexSet[i]=0;
        }
    };

    return {
        'getX': getX,
        'setWidth': setWidth,
        'reset': reset
    }
})();

var RectClickDialog = (function() {
    var x = 0;
    var y = 0;

    var dialog = function(func, attr) {
        var id;
        if (attr.dialogId) {
            id = '#' + attr.dialogId;
        } else {
            id = '#commandOption';
        }
        var $commandOption = $(id);

        if (func) {
            func($commandOption, attr);
        }
        x = event == undefined ? 0 : event.clientX - 15;
        y = event == undefined ? 0 : event.clientY - 10;
        return $commandOption.dialog('option', 'position', [x, y]).dialog('open');
    }

    return {
        x: x,
        y: y,
        dialog: dialog
    }
})();

(function(R, $) {
    R.fn.ruler = function(_paper, interval) {
        /*
        if (interval == undefined)
        interval = 50;
        var width = parseInt(default_width);
        var height = parseInt(default_height);

        var count = height / interval;
        for (var i = 1; i < count; i++) {
        var y = i * interval;
        var pathString = "M0," + y + " " + width + "," + y;
        var p = _paper.path(pathString);
        p.attr({ "opacity": 0.3, "stroke-width": "0.5px" });

            _paper.text(5, y, i);
        }

        count = width / interval;
        for (var i = 1; i < count; i++) {
        var x = i * interval;
        var pathString = "M" + x + ",0 " + x + "," + height;
        var p = _paper.path(pathString);
        p.attr({ "opacity": 0.3, "stroke-width": "0.5px" });

            _paper.text(x, 5, i);
        }
        */
    };

    R.fn.find = function(id) {
        for (var i = 0; i < rectTexts.length; i++) {
            var rectText = rectTexts[i];
            if (rectText.id() == id) {
                return rectText;
            }
        }
        return null;
    };

    R.fn.connection = function(obj1, obj2, line) {
        if (obj1.line && obj1.from && obj1.to) {
            line = obj1;
            obj1 = line.from;
            obj2 = line.to;
        }

        var pathData = this.direct(obj1, obj2);

        if (line && line.line) {
            line.line.attr({ path: pathData.path });
            line.arrow.attr({ path: pathData.arrow });
        } else {
            var color = typeof line == "string" ? line : obj1.attr.lineColor;
            var _path = this.path(pathData.path)
                .attr({ cursor: 'pointer',
                    stroke: color,
                    'stroke-width': 2,
                    'stroke-linecap': 'round',
                    'stroke-linejoin': 'round',
                    'opacity': 0.8
                });
            var thisObj = this;
            $(_path.node).mouseover(function() {
                _path.attr({ 'stroke-width': 5 });
                $.tooltip.open(obj1.data.jobName.name + " -> " + obj2.data.jobName.name);
            });
            $(_path.node).mouseout(function() {
                _path.attr({ 'stroke-width': 2 });
                $.tooltip.close();
            });
            return {
                line: _path,
                arrow: this.path(pathData.arrow).attr({ cursor: 'pointer', stroke: color, "stroke-width": 2 }),
                from: obj1,
                to: obj2
            };
        }
    };
    R.fn.direct =
		function(rect1, rect2) {
		    var bb1 = rect1.getBBox(),
				bb2 = rect2.getBBox(),
				xr1 = { b: bb1.x, e: bb1.x + bb1.width },
				xr2 = { b: bb2.x, e: bb2.x + bb1.width };

		    if ((xr2.b >= xr1.b && xr2.b <= xr1.e) || (xr2.e >= xr1.b && xr2.e <= xr1.e)) {
		        // top down
		        if (bb1.y > bb2.y) {
		            return this.direct_top(rect1, rect2);
		        } else {
		            return this.direct_down(rect1, rect2);
		        }
		    } else {
		        // right left
		        if (bb1.x > bb2.x) {
		            return this.direct_left(rect1, rect2);
		        } else {
		            return this.direct_right(rect1, rect2);
		        }
		    }
		};

    R.fn.direct_top =
		function(rect1, rect2) {
		    var bb1 = rect1.getBBox(),
				bb2 = rect2.getBBox()
		    p = [{ x: bb1.x + bb1.width / 2, y: bb1.y },
			     { x: bb2.x + bb2.width / 2, y: bb2.y + bb1.height}],
				al = 3,
				a = [{ x: p[1].x - al, y: p[1].y + al },
					 { x: p[1].x, y: p[1].y },
					 { x: p[1].x + al, y: p[1].y + al}];

		    var path = ["M", p[0].x, p[0].y, "L", p[1].x, p[1].y];
		    var arrow = ["M", a[0].x, a[0].y, "L", a[1].x, a[1].y, "L", a[2].x, a[2].y, "Z"];

		    return {
		        path: path,
		        arrow: arrow
		    };
		};

    R.fn.direct_down =
		function(rect1, rect2) {
		    var bb1 = rect1.getBBox(),
				bb2 = rect2.getBBox()
		    p = [{ x: bb1.x + bb1.width / 2, y: bb1.y + bb1.height },
				 { x: bb2.x + bb2.width / 2, y: bb2.y}],
				al = 3,
				a = [{ x: p[1].x + al, y: p[1].y - al },
					 { x: p[1].x, y: p[1].y },
					 { x: p[1].x - al, y: p[1].y - al}];

		    var path = ["M", p[0].x, p[0].y, "L", p[1].x, p[1].y];
		    var arrow = ["M", a[0].x, a[0].y, "L", a[1].x, a[1].y, "L", a[2].x, a[2].y, "Z"];

		    return {
		        path: path,
		        arrow: arrow
		    };
		};

    R.fn.direct_left =
		function(rect1, rect2) {
		    var altX = PositionXMaker.getX(rect2.attr.level);
		    var bb1 = rect1.getBBox(),
				bb2 = rect2.getBBox()
		    p = [{ x: bb1.x, y: bb1.y + bb1.height / 2 },
			     { x: bb1.x - altX, y: bb1.y + bb1.height / 2 },
				 { x: bb1.x - altX, y: bb2.y + bb2.height / 2 },
				 { x: bb2.x + bb1.width, y: bb2.y + bb2.height / 2}],
				al = 3,
				a = [{ x: p[3].x + al, y: p[3].y - al },
					 { x: p[3].x, y: p[3].y },
					 { x: p[3].x + al, y: p[3].y + al}];

		    var path = ["M", p[0].x, p[0].y, "L", p[1].x, p[1].y
							, "L", p[2].x, p[2].y, "L", p[3].x, p[3].y];
		    var arrow = ["M", a[0].x, a[0].y, "L", a[1].x, a[1].y, "L", a[2].x, a[2].y, "Z"];

		    return {
		        path: path,
		        arrow: arrow
		    };
		}

    R.fn.direct_right =
		function(rect1, rect2) {
		    var altX = PositionXMaker.getX(rect2.attr.level);
		    var bb1 = rect1.getBBox(),
				bb2 = rect2.getBBox()
		    p = [{ x: bb1.x + bb1.width, y: bb1.y + bb1.height / 2 },
					 { x: bb2.x - altX, y: bb1.y + bb1.height / 2 },
					 { x: bb2.x - altX, y: bb2.y + bb2.height / 2 },
					 { x: bb2.x, y: bb2.y + bb2.height / 2}],
				al = 3,
				a = [{ x: p[3].x - al, y: p[3].y - al },
					 { x: p[3].x, y: p[3].y },
					 { x: p[3].x - al, y: p[3].y + al}];

		    var path = ["M", p[0].x, p[0].y, "L", p[1].x, p[1].y
							, "L", p[2].x, p[2].y, "L", p[3].x, p[3].y];
		    var arrow = ["M", a[0].x, a[0].y, "L", a[1].x, a[1].y, "L", a[2].x, a[2].y, "Z"];

		    return {
		        path: path,
		        arrow: arrow
		    };
		};

    R.fn.outbound = function(paper, rect) {
        var rectBox = rect.getBBox();
        var $mainTable = $('#mainTable');
        var isIE6 = navigator.userAgent.indexOf("MSIE 6.0") > -1;
        var $holder = $('#holder');

        var hadModified = false;
        var holderWidth = parseInt($holder.css('width'));
        var paperWidth = parseInt(paper.width);
        var holderHeight = parseInt($holder.css('height'));
        var paperHeight = parseInt(paper.height);
        var modifiedWidth = holderWidth;
        var modifiedHeight = holderHeight;

        hadModified = holderWidth != paperWidth || holderHeight != paperHeight;
        if (hadModified) {
            paper.setSize(modifiedWidth, modifiedHeight);
        }
        paper.setSize(modifiedWidth, modifiedHeight);

        if (rectBox.x + rect.attr('width') > modifiedWidth) {
            hadModified = true;
            modifiedWidth += 300;
            $holder.css('width', modifiedWidth);
        }
        if (rectBox.y + rect.attr("height") > modifiedHeight) {
            hadModified = true;
            modifiedHeight += 100;
            $holder.css('height', modifiedHeight);
        }
        if (hadModified) {
            paper.setSize(modifiedWidth, modifiedHeight);
        }
    }

    R.fn.rectText = function(rect, str, stroke, background) {
        var paper = rect.paper;
        var draggable = false;
        var clickable = false;

        // var color = Raphael.getColor();
        var color = "blue";

        // initial Set
        var rectBB = rect.getBBox();

        //TODO format str, if the length too long.
        var jobName = JobName(str);
        var dispaly = jobName.has_flow ? '《' + (LimitTextLength(jobName.job_flow_name, 100) + '》' + '\n' + LimitTextLength(jobName.job_name, 100)) : LimitTextLength(jobName.job_name, 100);

        var text = paper.text(rectBB.x + rectBB.width / 2, rectBB.y + rectBB.height / 2, dispaly);
        var textBB = text.getBBox();
        text.mouseover(function() {
            $.tooltip.open(jobName.name);
        });
        text.mouseout(function() {
            $.tooltip.close();
        });

        var currentStroke = "#999999";
        var strokeWidth = 1;
        if (stroke) {
            if (typeof stroke == "string") {
                currentStroke = stroke;
            } else {
                currentStroke = stroke.stroke;
                strokeWidth = stroke.strokeWidth;
            }
        }
        var prevStroke = currentStroke;
        var prevStrokeWidth = strokeWidth;

        var currentBackground = background;
        if (!currentBackground) {
            currentBackground = "white";
        }
        var prevBackground = currentBackground;

        if(jobName.has_flow){
            text.attr({ cursor: "text", "font-size": "10px","fill": "#333333", "font-weight": "700"});
        }else{
            text.attr({ cursor: "text", "font-size": "11px", "fill": "#000000", "font-weight": "700" });
        }
        
        rect.attr({ cursor: "pointer", "stroke": currentStroke, "stroke-width": strokeWidth, "fill": currentBackground, "fill-opacity": 1 });
        //rect.attr({x:textBB.x - 5 , width:textBB.width + 10, fill: color, stroke: color, "fill-opacity": 0, cursor: "pointer"});
        //text.attr({ stroke: "#f1f1f1", "fill-opacity": 1, cursor: "text" });

        paper.outbound(paper, rect);

        var st = paper.set();
        st.push(rect, text);

        st.mouseover(function() {
            prevStroke = rect.attr("stroke");
            currentStroke = 'blue';
            rect.attr({ stroke: currentStroke, "stroke-width": 3 });
        }).mouseout(function() {
            currentStroke = prevStroke;
            rect.attr({ stroke: prevStroke, "stroke-width": prevStrokeWidth });
        });

        var parent = [];
        var child = [];
        var isOtherFlow = false;
        var flow_id;
        var status;
        var lineColor = ColorMaker.getColor();
        var attr = {
            'prevBackground': prevBackground,
            'currentBackground': currentBackground,
            'level': 0,
            'lineColor': lineColor
        };

        var statusChanged = function(_status) {
            attr.status = _status;
            if (_status == 'X') {
                attr.currentBackground = '#666666'; // silver
            } else {
                //attr.currentBackground = '#43cb43'; // green
                attr.currentBackground = '#CCCC99'; // green
            }
            attr.prevBackground = attr.currentBackground;
            rect.attr({ 'fill': attr.currentBackground });
        }

        return {
            id: function(id) {
                if (id != undefined)
                    rect.id = id;
                return rect.id;
            },
            data: {
                start_dt: '',
                end_dt: '',
                jobName: jobName
            },
            attr: attr,
            statusChanged: statusChanged,
            rect: rect,
            text: text,
            prevStroke: prevStroke,
            currentStroke: currentStroke,
            st: st,
            flow_id: flow_id,
            isOtherFlow: isOtherFlow,
            paper: paper,
            draggable: draggable,
            drag: function(move, dragger, up) {
                draggable = true;
                //                var color = Raphael.getColor();
                var att = { cursor: "move" };
                rect.attr(att);
                text.attr(att);

                rect.drag(move, dragger, up);
                text.drag(move, dragger, up);
            },
            undrag: function() {
                if (draggable) {

                    rect.events[0].unbind();
                    text.events[0].unbind();
                    //rect.undrag();
                    //text.undrag();
                    rect.attr({ cursor: "pointer" });
                    text.attr({ cursor: "pointer" });
                    draggable = false;
                }
            },
            dragger: function() {
                function d(el) {
                    el.ox = el.attr("x");
                    el.oy = el.attr("y");
                    el.animate({ "fill-opacity": .2 }, 500);
                }

                d(rect);
                d(text);
            },
            moveX: function(dx) {
                var rectBB = rect.getBBox();
                rect.attr({ x: dx });
                var tX = dx + rectBB.width / 2;
                text.attr({ x: tX });
                for (var i = connections.length; i--; ) {
                    paper.connection(connections[i]);
                }
                paper.outbound(paper, rect);
            },
            moveALL: function(dx, dy) {
                var rectBB = rect.getBBox();
                rect.attr({ x: dx, y: dy });
                var tX = dx + rectBB.width / 2;
                var ty = dy + rectBB.height / 2;
                text.attr({ x: tX, y: ty });
                for (var i = connections.length; i--; ) {
                    paper.connection(connections[i]);
                }
                paper.outbound(paper, rect);
            },
            move: function(dx, dy) {
                var att = { x: rect.ox + dx, y: rect.oy + dy };
                // if out of paper's bound, cancel move action.
                if (att.x < 0 || att.x + rect.attr("width") > parseInt(paper.width)) return;
                if (att.y < 0 || att.y + rect.attr("height") > parseInt(paper.height)) return;
                rect.attr(att);

                att = { x: text.ox + dx, y: text.oy + dy };
                text.attr(att);

                for (var i = connections.length; i--; ) {
                    paper.connection(connections[i]);
                }

                rect.paper.safari();
                paper.outbound(paper, rect);
            },
            up: function() {
                function u(el) {
                    el.animate({ "fill-opacity": 0 }, 500);
                }

                u(rect);
                u(text);
            },
            clickable: clickable,
            click: function(src, handler) {
                clickable = true;
                var clickFunction = function(el) {
                    if (CurrentCommandMode == CommandMode_RemoveJob) {
                        $.tooltip.close();
                        if (confirm("確定刪除Job [" + src.data.jobName.name.fulltrim() + "] ?")) {
                            var _rectText = rectTexts.lookup(this);
                            rectTexts.remove(_rectText);
                        }
                    } else if (CurrentCommandMode == CommandMode_AddJob) {

                    } else if (CurrentCommandMode == CommandMode_SwitchJob) {
                        if (handler != undefined && handler.switchFunc != undefined) {
                            RectClickDialog.dialog(handler.switchFunc, { rectText: src });
                        }
                    } else if (CurrentCommandMode == CommandMode_Connection) {
                        if (firstRectText == null) {
                            rect.attr({ "fill": "red" });
                            firstRectText = src;
                        } else {
                            if (firstRectText == src) {

                            } else {
                                var inChild = $.inArray(src, firstRectText.child) != -1;
                                if (inChild) {
                                    alert("[失敗] 連結已存在!");
                                    return;
                                }
                                var inParent = rectTexts.inParent(src, firstRectText.parent);
                                if (inParent) {
                                    alert("[失敗] 不可建立相互連結以避免無窮迴圈!");
                                    return;
                                }

                                if (firstRectText.isOtherFlow && src.isOtherFlow) {
                                    alert("[失敗] 不同Job Flow間的Job不可在此建立連結!");
                                    return;
                                }

                                var conn = paper.connection(firstRectText, src);
                                firstRectText.child.push(src);
                                src.parent.push(firstRectText);

                                conn.line.click(function() {
                                    if (CurrentCommandMode == CommandMode_RemoveJob) {
                                        var $this = $(this);
                                        var _conn = connections.lookup(this);
                                        if (confirm("確定刪除此連結[" + _conn.from.data.jobName.name.fulltrim() + "] -> [" + _conn.to.data.jobName.name.fulltrim() + "] ?")) {
                                            connections.remove(_conn);
                                        }
                                    }
                                });
                                connections.push(conn);
                            }
                            firstRectText.rect.attr({ fill: firstRectText.attr.prevBackground });
                            firstRectText = null;
                        }
                    }
                }

                rect.click(clickFunction);
                text.click(clickFunction);
            },
            unclick: function() {
                if (clickable) {
                    clickable = false;
                    rect.attr({ "fill-opacity": .0 });
                    //rect.unclick();
                    rect.events[0].unbind();
                    text.events[0].unbind();
                    firstRectText == null;
                }

            },
            getBBox: function() { return rect.getBBox() },
            parent: parent,
            child: child,
            connect: function(sub) {
                sub.parent.push(this);
                child.push(sub);
            },
            toString: function() {
                return "{'id':'" + rect.id + "'}";
            }
        };
    };
})(Raphael, jQuery);

(function($) {
    $.fn.paper = {};

    $.fn.paper.create = function($src) {
        if ($('div[id="tooltip"]').length == 0) {
            $.fx.speeds._default = 100;
            $.tooltip.div = ($(document.createElement('a')).appendTo('body')).hide().dialog({ autoOpen: false, dialogClass: 'gradient_backgroud tooltip', resizable: false, height: 20, width: 150, show: "fade" });
            $.tooltip.div.parent().removeClass('ui-widget ui-widget-content ui-draggable');
            $.tooltip.div.prev().remove();
        }
        var width = $src.css("width");
        var height = $src.css("height");
        return Raphael($src[0], width, height);
    }

    $.fn.paper.addStep = function(paper, str, x, y, width, height, r, background) {
        if (width == undefined)
            width = 200;
        if (height == undefined)
            height = 55;
        if (r == undefined)
            r = 0;
        var rect = paper.rect(x, y, width, height, r);
        var rectText = paper.rectText(rect, str, r == 0 ? '#D8D8D8' : { 'stroke': '#2E2E2E', 'strokeWidth': 2 }, background);
        rectTexts.push(rectText);
        return rectText;
    }
})(jQuery);