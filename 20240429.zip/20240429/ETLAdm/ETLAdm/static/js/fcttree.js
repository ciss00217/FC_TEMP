﻿// left-top .begin ========================
function flushFcts(PrjId, SrcCode, DefFileName) {
    var $Fcts = $('#Fcts');
    var dataFctJson = JSON.stringify({ 'PRJ_ID': PrjId, 'SRC_CODE': SrcCode });
    $.ajax({
        type: 'post',
        url: '/ETLAdm/svc/GetFctDataHandler.ashx',
        data: 'data=' + dataFctJson,
        success: function (response) {
            if (response.success) {
                var innerHtml = '';
                var srcGrp = response.data;
                var count = srcGrp.length;
                for (var i = 0; i < count; i++) {
                    var obj = srcGrp[i];
                    if (SrcCode != 'All') {
                        innerHtml += (
                                '<li    ><span><a id="' + obj.FILE_FREQ_Names + '">' + obj.FILE_FREQ_Names + '</a></span>' + SetTree_FCT(obj.Sub) + '</li>'
                            );
                    }
                    else {
                        innerHtml += (
                                '<li class="closed"><span><a id="' + obj.FILE_FREQ_Names + '">' + obj.FILE_FREQ_Names + '</a></span>' + SetTree_FCT(obj.Sub) + '</li>'
                            );
                    }
                }

                $Fcts.html(innerHtml);
                setTimeout(function () {
                    if (DefFileName) {
                        $('a[id="' + DefFileName + '"]').parents('li.closed').removeClass('closed');
                    }

                    $Fcts.treeview();
                }, 100);
            } else {
                alert("系統異常: " + response.message);
                $.unblockUI();
            }
        },
        error: function (response) {
            alert("系統異常: " + response.responseText);
            $.unblockUI();
        }
    });
}

function SetTree_FCT(FILES) {
    var innerHtml = '';
    if (FILES.length > 0) {
        innerHtml += '<ul class="file">';
        for (var i = 0; i < FILES.length; i++) {
            var obj = FILES[i];
            innerHtml += (
                            '<li class="closed"><span><a id="FILE_NAME|'
                                + obj.FILE_NAME + '" title="' + obj.FILE_NAME + '">'
                                    + LimitTextLength(obj.FILE_NAME, 100) + '</a></span>'
                                        + '</li>'
                        );
        }
        innerHtml += '</ul>';
    }
    return innerHtml;
}

function SetTree_JOBS(JOBS) {
    var innerHtml = '';
    if (JOBS.length > 0) {
        innerHtml += '<ul class="job">';
        for (var i = 0; i < JOBS.length; i++) {
            var obj = JOBS[i];
            innerHtml += (
                            '<li><span><a id="Job|' + obj.JOB_ID + '|' + obj.AP_ID + '" title="' + obj.JOB_NAME + '">' + LimitTextLength(obj.JOB_NAME, 100) + '</a></span></li>'
                        );
        }
        innerHtml += '</ul>';
    }
    return innerHtml;
}
// left - top .end ========================


