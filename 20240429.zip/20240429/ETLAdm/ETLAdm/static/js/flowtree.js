﻿// left-top .begin ========================
function flushFlows(IsFillJob, PrjId, FlowTypes, DefFlowApID) {
    var $Flows = $('#Flows');
    var isFillJob = IsFillJob == undefined ? true : IsFillJob;
    var dataJson = JSON.stringify({ 'PRJ_ID': PrjId, 'JOB_FLOW_TYPE': FlowTypes });
    $.ajax({
        type: 'post',
        url: '/ETLAdm/svc/GetFlowsHandler.ashx',
        data: 'data=' + dataJson,
        success: function(response) {
            if (response.success) {
                var innerHtml = '';
                var flowGrp = response.data.JOB_FLOW_GROUPS;
                var count = flowGrp.length;
                for (var i = 0; i < count; i++) {
                    var obj = flowGrp[i];
                    innerHtml += (
                            '<li class="closed"><span><a id="' + obj.RUN_FREQ + '">' + obj.RUN_FREQ + '</a></span>' + SetTree_JOB_FLOWS(obj.JOB_FLOWS, isFillJob) + '</li>'
                        );
                }

                $Flows.html(innerHtml);
                setTimeout(function() {
                    if (DefFlowApID) {
                        $('a[id="' + DefFlowApID + '"]').parents('li.closed').removeClass('closed');
                    }

                    $Flows.treeview();
                }, 100);
            } else {
                alert("系統異常: " + response.message);
                $.unblockUI();
            }
        },
        error: function(response) {
            alert("系統異常: " + response.responseText);
            $.unblockUI();
        }
    });
}

function SetTree_JOB_FLOWS(JOB_FLOWS, IsFillJob) {
    var innerHtml = '';
    if (JOB_FLOWS.length > 0) {
        innerHtml += '<ul class="flow">';
        for (var i = 0; i < JOB_FLOWS.length; i++) {
            var obj = JOB_FLOWS[i];
            innerHtml += (
                            '<li class="closed"><span><a id="Flow|'
                                + obj.AP_ID + '" title="' + obj.JOB_FLOW_NAME + '">'
                                    + LimitTextLength(obj.JOB_FLOW_NAME, 100) + '</a></span>' 
                                        + (IsFillJob ? SetTree_JOBS(obj.JOBS) : "") + '</li>'
                        );
        }
        innerHtml += '</ul>';
    }
    return innerHtml;
}

function SetTree_JOBS(JOBS) {
    var innerHtml = '';
    if (JOBS.length > 0) {
        innerHtml += '<ul class="job">';
        for (var i = 0; i < JOBS.length; i++) {
            var obj = JOBS[i];
            innerHtml += (
                            '<li><span><a id="Job|' + obj.JOB_ID + '|' + obj.AP_ID + '" title="' + obj.JOB_NAME + '">' + LimitTextLength(obj.JOB_NAME, 100) + '</a></span></li>'
                        );
        }
        innerHtml += '</ul>';
    }
    return innerHtml;
}
// left - top .end ========================


