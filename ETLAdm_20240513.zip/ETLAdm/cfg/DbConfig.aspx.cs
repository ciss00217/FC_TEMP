﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.util;
using gbs.bao.etl.entity;
using gbs.bao.etl.bo;
using gbs.bao.etl.dao;

namespace ETLAdm.cfg
{
    public partial class DbConfig : EtlAdmPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                FillOdbcDriver(DbTypes());
                addCfg_Click(addConfig, null);
                DataList1_DataBind();
            }
        }

        private IEnumerable<string> DbTypes()
        {
            List<string> keys = new List<string>();
            foreach (ListItem item in db_type.Items)
            {
                keys.Add(item.Text);
            }
            return keys;
        }

        private void FillOdbcDriver(IEnumerable<string> keys)
        {            
            odbc_driver.Items.Clear();
            odbc_driver.Items.Add(new ListItem() { Text = "---請選擇---", Value = "-1" });
            foreach (string odbc in OdbcUtil.GetOdbcDriverNames().OrderBy(x => x))
            {
                foreach (string key in keys)
                {
                    if (odbc.IndexOf(key, StringComparison.OrdinalIgnoreCase) > -1)
                    {
                        odbc_driver.Items.Add(new ListItem() { Text = odbc, Value = odbc });
                    }
                }
            }
        }

        protected void addCfg_Click(object sender, EventArgs e)
        {
            DetailClear();
            btnOk.CommandName = Const.CMD_Add;
            btnRemove.Visible = false;
            btnCopy.Visible = false;
            this.var_name.Attributes.Remove("onkeydown");
            this.var_name.Attributes.Remove("style");
        }

        protected void lnkCfg_Click(object sender, EventArgs e)
        {
            LinkButton link = sender as LinkButton;
            int ap_id = Convert.ToInt32(link.CommandArgument);            
            DetailBind(ap_id, false);
        }

        private string OverrideVarName(string str){
            string[] varNames = str.Split('.');
            string result = varNames[0] + "(Copy)" + ( varNames.Length > 1 ? "." + varNames[1] : "" );
            return result;
        }

        protected void DetailBind(int ap_id, bool isCopy)
        {
            btnOk.CommandName = Const.CMD_Replace;
            btnOk.CommandArgument = ap_id + "";
            try
            {
                DBConfig cfg = new ConfigBO().selectDBConfig(ap_id);
                if (isCopy)
                {
                    cfg.root.VAR_NAME = OverrideVarName(cfg.root.VAR_NAME);
                    btnOk.CommandName = Const.CMD_Add;
                    DetailBind(cfg, false);
                }
                else
                {
                    btnRemove.CommandArgument = ap_id + "";
                    DetailBind(cfg, true);
                }
            }
            catch (Exception ex)
            {
                logger.ErrorException(ex.Message, ex);
                setMessage(false, ex.Message);
            }
            
        }

        private DBConfig DetailDataSource(bool isAdd=false)
        {

            ETLCFG root = new ETLCFG()
                {
                    PRJ_ID = Project_Id,
                    VAR_NAME = isAdd ? this.var_name.Text.Trim() : this.var_name.Text,
                    VAR_VALUE = this.db_name.Text,
                    VAR_TYPE = Const.CFG_TYPE_DB,
                    ENABLE_FLAG = this.enable_flag.Text.ToCharArray()[0],
                    ENCRYPT_FLAG = Const.ENABLE_N
                };
            ETLCFG cfgType = new ETLCFG()
                {
                    PRJ_ID = Project_Id,
                    VAR_NAME = string.Format(Const.CFG_DB_PTN_TYPE, root.VAR_NAME),
                    VAR_VALUE = this.db_type.Text,
                    VAR_TYPE = Const.CFG_TYPE_DB_STATIC,
                    ENABLE_FLAG = this.enable_flag.Text.ToCharArray()[0],
                    ENCRYPT_FLAG = Const.ENABLE_N
                };


            ETLCFG cfgUser = new ETLCFG()
            {
                PRJ_ID = Project_Id,
                VAR_NAME = string.Format(Const.CFG_DB_PTN_USERID, root.VAR_NAME),
                VAR_VALUE = this.user_id.Text,
                VAR_TYPE = Const.CFG_TYPE_DB_STATIC,
                ENABLE_FLAG = this.enable_flag.Text.ToCharArray()[0],
                ENCRYPT_FLAG = this.usr_id_encrypt.SelectedValue[0]                                
            }; 
            
            ETLCFG cfgPwd = new ETLCFG()
            {
                PRJ_ID = Project_Id,
                VAR_NAME = string.Format(Const.CFG_DB_PTN_PWD, root.VAR_NAME),
                VAR_VALUE = this.password.Text,
                VAR_TYPE = Const.CFG_TYPE_DB_STATIC,
                ENABLE_FLAG = this.enable_flag.Text.ToCharArray()[0],
                ENCRYPT_FLAG = this.password_encrypt.SelectedValue[0]                                
            };

            ETLCFG cfgServer = new ETLCFG()
            {
                PRJ_ID = Project_Id,
                VAR_NAME = string.Format(Const.CFG_DB_PTN_SERVER, root.VAR_NAME),                
                VAR_VALUE = this.server.Text + ":" + this.port.Text,
                VAR_TYPE = Const.CFG_TYPE_DB_STATIC,
                ENABLE_FLAG = this.enable_flag.Text.ToCharArray()[0],
                ENCRYPT_FLAG = Const.ENABLE_N
            }; 

            ETLCFG cfgPath = new ETLCFG()
            {
                PRJ_ID = Project_Id,
                VAR_NAME = string.Format(Const.CFG_DB_PTN_PATH, root.VAR_NAME),
                VAR_VALUE = this.path.Text,
                VAR_TYPE = Const.CFG_TYPE_DB_STATIC,
                ENABLE_FLAG = this.enable_flag.Text.ToCharArray()[0],
                ENCRYPT_FLAG = Const.ENABLE_N
            };
 
            ETLCFG cfgHeartbeat = new ETLCFG()
            {
                PRJ_ID = Project_Id,
                VAR_NAME = string.Format(Const.CFG_DB_PTN_HEARTBEAT, root.VAR_NAME),
                VAR_VALUE = this.heartbeat.Text,
                VAR_TYPE = Const.CFG_TYPE_DB_STATIC,
                ENABLE_FLAG = this.enable_flag.Text.ToCharArray()[0],
                ENCRYPT_FLAG = Const.ENABLE_N
            };

            ETLCFG cfgOdbcDriver = new ETLCFG()
            {
                PRJ_ID = Project_Id,
                VAR_NAME = string.Format(Const.CFG_DB_PTN_ODBCDRIVER, root.VAR_NAME),
                VAR_VALUE = Const.DropDownList_DefaultValue.Equals(this.odbc_driver.SelectedValue) ? "" : this.odbc_driver.SelectedValue,
                VAR_TYPE = Const.CFG_TYPE_DB_STATIC,
                ENABLE_FLAG = this.enable_flag.Text.ToCharArray()[0],
                ENCRYPT_FLAG = Const.ENABLE_N
            };

            return new DBConfig()
            {
                root = root,
                cfgType = cfgType,
                cfgUser = cfgUser,
                cfgPwd = cfgPwd,
                cfgServer = cfgServer,
                cfgPath = cfgPath,
                cfgHeartbeat = cfgHeartbeat,
                cfgOdbcDriver = cfgOdbcDriver
            };
        }

        private DBConfig DetailBind(DBConfig cfg, bool isVarNameReadOnly)
        {
            this.var_name.ReadOnly = isVarNameReadOnly;
            if (isVarNameReadOnly)
            {
                this.var_name.Attributes.Add("onkeydown", "return false;");
                this.var_name.Attributes.Add("style", "background:silver");
                this.btnRemove.Visible = true;
                this.btnCopy.Visible = true;
            }
            else
            {
                this.var_name.Attributes.Remove("onkeydown");
                this.var_name.Attributes.Remove("style");
                this.btnRemove.Visible = false;
                this.btnCopy.Visible = false;
            }
            this.var_name.Text = cfg.root.VAR_NAME;
            this.db_name.Text = cfg.root.VAR_VALUE;
            this.db_type.SelectedValue = cfg.cfgType.VAR_VALUE;
            this.user_id.Text = cfg.cfgUser.VAR_VALUE;
            this.usr_id_encrypt.SelectedValue = cfg.cfgUser.ENCRYPT_FLAG.ToString();
            this.password.Text = cfg.cfgPwd.VAR_VALUE;
            this.password.Attributes.Add("value", cfg.cfgPwd.VAR_VALUE);
            this.password_encrypt.SelectedValue = cfg.cfgPwd.ENCRYPT_FLAG.ToString();
            string[] ip_port = cfg.cfgServer.VAR_VALUE.Split(':');
            this.server.Text = ip_port[0];
            this.port.Text = ip_port.Length > 1 ? ip_port[1] : "";
            this.path.Text = cfg.cfgPath.VAR_VALUE;
            this.enable_flag.SelectedValue = cfg.root.ENABLE_FLAG + "";
            this.Label_enable_flag_ori.Text = cfg.root.ENABLE_FLAG + "";
            this.btnOk.CommandArgument = cfg.root.AP_ID + "";
            this.btnCopy.CommandArgument = cfg.root.AP_ID + "";
            this.btnRemove.CommandArgument = cfg.root.AP_ID + "";
            this.heartbeat.Text = cfg.cfgHeartbeat.VAR_VALUE;
            this.odbc_driver.SelectedValue = string.IsNullOrEmpty(cfg.cfgOdbcDriver.VAR_VALUE) ? Const.DropDownList_DefaultValue : cfg.cfgOdbcDriver.VAR_VALUE;
            return cfg;
        }

        private void DetailClear()
        {
            this.var_name.ReadOnly = false;
            this.var_name.Text = string.Empty;
            this.db_name.Text = string.Empty;
            this.db_type.SelectedValue = Const.DropDownList_DefaultValue;
            this.user_id.Text = string.Empty;
            this.usr_id_encrypt.SelectedValue = Const.VALUE_N;
            this.password.Text = string.Empty;
            this.password.Attributes.Remove("value");
            this.password_encrypt.SelectedValue = Const.VALUE_Y ;
            this.enable_flag.SelectedValue = Const.VALUE_Y;
            this.server.Text = string.Empty;
            this.port.Text = string.Empty;
            this.path.Text = string.Empty;
            this.btnCopy.Visible = false;
            this.btnRemove.Visible = false;
            this.heartbeat.Text = string.Empty;
            this.odbc_driver.SelectedValue = Const.DropDownList_DefaultValue;
        }

        protected void btnOk_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            ConfigBO bo = new ConfigBO();
            bo.UserName = UserName;
            ResultBean result = null;
            DBConfig cfg = null;
            int ap_id = -1;
            switch (btn.CommandName)
            {
                case Const.CMD_Add:
                    cfg = DetailDataSource(true);
                    result = setMessage(bo.addDBConfigAll(cfg));
                    break;
                case Const.CMD_Replace:
                    cfg = DetailDataSource();                    
                    result = setMessage(bo.replaceDBConfigAll(cfg,this.Label_enable_flag_ori.Text));
                    break;
                case Const.CMD_Remove:
                    if (btn.CommandArgument == string.Empty)
                    {
                        logger.Error(Const.MSG_Fail + ",參數為空白");
                        result = setMessage(false, Const.MSG_Fail);
                    }
                    else
                    {
                        ap_id = Convert.ToInt32(btn.CommandArgument);
                        result = setMessage(bo.removeConfigAll(ap_id));
                    }
                    break;
                case Const.CMD_Copy:
                    if (btn.CommandArgument == string.Empty)
                    {
                        logger.Error(Const.MSG_Fail + ",參數為空白");
                        result = setMessage(false, Const.MSG_Fail);
                    }
                    else
                    {
                        ap_id = Convert.ToInt32(btn.CommandArgument);
                        result = setMessage(new ResultBean()
                        {
                            success = true,
                            message = Const.MSG_Copy_SUCCESS
                        });
                    }
                    break;
            }
            if (result.success)
            {
                DataList1_DataBind();
                switch (btn.CommandName)
                {
                    case Const.CMD_Add:
                        addCfg_Click(addConfig, null);
                        break;
                    case Const.CMD_Replace:
                        DetailBind(cfg.root.AP_ID, false);                        
                        break;
                    case Const.CMD_Remove:
                        addCfg_Click(addConfig, null);
                        break;
                    case Const.CMD_Copy:
                        DetailBind(ap_id, true);
                        break;
                }                
            }
        }

        protected void DataList1_DataBind()
        {
            ObjectDataSource1.SelectParameters[0].DefaultValue = this.Project_Id + "";
            DataList1.DataBind();
        }
    }
}
