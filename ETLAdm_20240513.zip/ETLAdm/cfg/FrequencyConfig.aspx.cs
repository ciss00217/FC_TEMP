﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using gbs.bao.etl.util;
using gbs.bao.etl.entity;
using gbs.bao.etl.bo;
using System.Drawing;
using System.Web.Script.Serialization;
using gbs.bao.etl.dao;
using gbs.bao.etl.entity.proxy;
using System.Text.RegularExpressions;

namespace ETLAdm.cfg
{
    public partial class FrequencyConfig : EtlAdmPage
    {
        JavaScriptSerializer js = new JavaScriptSerializer();
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            Initialize();
            if (!IsPostBack)
            {
                addFrequency_Click(addFrequency, null);                
            }
            else
            {
                
            }
        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void lnkFrequency_Click(object sender, EventArgs e)
        {
            LinkButton link = sender as LinkButton;            
            SearchAndEditFormDataBind(Int32.Parse(link.CommandArgument));
        }

        /// <summary>
        /// Show default edit form when add frequency button clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void addFrequency_Click(object sender, EventArgs e)
        {
            ETLJFQ etljfq = new ETLJFQ()
            {
                EXE_TIME = "00:00",
                RUN_FREQ_TYPE = Const.RUN_FREQ_F,
                RUN_FREQ = Const.RUN_FREQ_F,
                PRI_LEVEL = Const.PRI_LEVEL_N,
                PRJ_ID = this.Project_Id,
                AP_ID = 0,
                ADJ_DAYS = "",
                DAY_OF_WMY = "",
                RUN_FREQ_DESC = "",
                RUN_FREQ_ID = 0,
                RUN_FREQ_NAME = ""
            };
            EditFormDataBind(etljfq,false);
            TreeView1_DataBind();
        }

        private void Initialize()
        {
            Required1.CssClass = "hide";
            Required2.CssClass = "hide";
            Required3.CssClass = "hide";
            Required4.CssClass = "hide";
        }

        private ResultBean Validate(ETLJFQ etljfq)
        {
            Initialize();

            ResultBean bean = new ResultBean();
            bool success = true;
            string message = string.Empty;

            if (etljfq.RUN_FREQ_NAME == string.Empty)
            {
                Required1.CssClass = "error_tip";
                success = false;
                message += "- 週期名稱不可空白\r\n";
            }

            if (etljfq.RUN_FREQ == Const.RUN_FREQ_Y)
            {
                if (etljfq.DAY_OF_WMY == Const.DAY_OF_WMY_LastDay)
                {
                    if (etljfq.ADJ_DAYS == string.Empty)
                    {
                        Required4.CssClass = "error_tip";
                        success = false;
                        message += "- 每年(Y) 年底日前N日不可空白\r\n";
                    }
                }
                else if (etljfq.DAY_OF_WMY == string.Empty)
                {
                    Required3.CssClass = "error_tip";
                    success = false;
                    message += "- 每年(Y) 該年度第N日不可空白\r\n";
                }
            }

            if (etljfq.RUN_FREQ != Const.RUN_FREQ_F)
            {
                if (string.IsNullOrEmpty(etljfq.EXE_TIME))
                {
                    Required2.CssClass = "error_tip";
                    success = false;
                    message += "- 執行時間不可空白\r\n";
                }
                else
                {
                    if (!Regex.IsMatch(etljfq.EXE_TIME, @"^(?:0?[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$"))
                    {
                        Required2.CssClass = "error_tip";
                        success = false;
                        message += "- 執行時間格式有誤hh:mm\r\n";
                    }
                }
            }

            if (etljfq.RUN_FREQ == Const.RUN_FREQ_R)
            {
                if (Regex.IsMatch(etljfq.EXE_TIME, @"^0?[0]:0?[0]$"))
                {
                    Required2.CssClass = "error_tip";
                    success = false;
                    message += "- 重覆執行時間不可為00:00\r\n";
                }
            }
            
            bean.success = success;
            bean.message = message;
            return bean;
        }

        protected void btnCopy_Click(object sender, EventArgs e)
        {
            string jsonData = HiddenETLJFQ.Value;

            ETLJFQ etljfq = js.Deserialize<ETLJFQ>(jsonData);

            etljfq.AP_ID = 0;
            etljfq.RUN_FREQ_NAME = etljfq.RUN_FREQ_NAME + "(Copy)";

            EditFormDataBind(etljfq,false);
            TreeView1_DataBind();            

            setMessage(true, Const.MSG_Copy_SUCCESS);                
            
        }

        /// <summary>
        /// Save ETLJFQ data when Ok button clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnOk_Click(object sender, EventArgs e)
        {
            bool isAdd = false;
            string jsonData = HiddenETLJFQ.Value;
            
            ETLJFQ etljfq = js.Deserialize<ETLJFQ>(jsonData);
            if (etljfq==null)
            {
                setMessage(false, "未傳入周期資料");
                return;
            }            
            ResultBean bean = Validate(etljfq);
            etljfq.EXE_TIME = etljfq.EXE_TIME == null ? "00:00" : etljfq.EXE_TIME.Trim();
            if (bean.success)
            {
                etljfq.PRJ_ID = this.Project_Id;
                FrequencyBO bo = new FrequencyBO();
                bo.UserName = UserName;
                
                if (etljfq.AP_ID == 0)
                {
                    isAdd = true;
                    bean = setMessage(bo.addFrequency(etljfq));
                }
                else
                {
                    bean = setMessage(bo.replaceFrequency(etljfq));
                }
            }
            EditFormDataBind(etljfq);

            if (bean.success)
            {
                TreeView1_DataBind();
                if (isAdd)
                {
                    //addFrequency_Click(this.addFrequency, e);
                }
            }
            else
            {
                setMessage(bean);
            }
        }

        protected void btnRemove_Click(object sender, EventArgs e)
        {
            string jsonData = HiddenETLJFQ.Value;

            ETLJFQ etljfq = js.Deserialize<ETLJFQ>(jsonData);
            FrequencyBO bo = new FrequencyBO();
            ResultBean bean = setMessage(bo.removeFrequency(etljfq.AP_ID));
            if (bean.success)
            {
                addFrequency_Click(addFrequency, null);
            }
        }

        /// <summary>
        /// Bind a ETLJFQ data to Edit form in main. 
        /// </summary>
        /// <param name="etljfq"></param>
        private void EditFormDataBind(ETLJFQ etljfq,bool copyVisible=true)
        {            
            ETLJFQProxy proxy = StaticProxyHelper.proxyIt<ETLJFQProxy>(etljfq, ProxyMode.Property2Property);
            HiddenETLJFQ.Value = js.Serialize(proxy);
            TableRUN_FREQ_DETAIL_Visible(true);
            this.copyButton.Visible = copyVisible;
            this.removeButton.Visible = copyVisible;
        }

        /// <summary>
        /// Search the data from database by ap_id, 
        /// Bind a ETLJFQ data to Edit form in main. 
        /// </summary>
        /// <param name="apid"></param>         
        private void SearchAndEditFormDataBind(int apid)
        {
            FrequencyDAO dao = new FrequencyDAO();
            ETLJFQ etljfq = dao.selectByApId(apid);
            EditFormDataBind(etljfq);
        }

        protected void TreeView1_DataBind()
        {   
            ObjectDataSource1.SelectParameters[0].DefaultValue = this.Project_Id + "";
            foreach (TreeNode node in TreeView1.Nodes)
            {
                node.ChildNodes.Clear();
            }
            foreach(ETLJFQ jfq in ObjectDataSource1.Select())
            {
                foreach (TreeNode node in TreeView1.Nodes)
                {
                    if (jfq.RUN_FREQ.ToString().Equals(node.Value))
                    {
                        node.ChildNodes.Add(new TreeNode(jfq.RUN_FREQ_NAME, jfq.AP_ID + ""));
                    }
                }
            }
        }

        private void TableRUN_FREQ_DETAIL_Visible(bool visible)
        {
            string script = @"$(function(){{ 
                $('#RUN_FREQ_DETAIL').{0}('hide');
            }});";

            script = string.Format(script, visible ? "removeClass" : "addClass");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "TableRUN_FREQ_DETAIL_Visible", script, true);
        }

        public void TreeView1_SelectedNodeChanged(object sender, EventArgs e)
        {
            SearchAndEditFormDataBind(int.Parse(TreeView1.SelectedValue));
        }
    }
}
