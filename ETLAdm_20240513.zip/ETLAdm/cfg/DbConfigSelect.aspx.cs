﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.util;
using gbs.bao.etl.dao;
using gbs.bao.etl.entity.proxy;
using gbs.bao.etl.bo;
using gbs.bao.etl.entity;
using System.Xml;
using System.IO;
using System.Text;
using System.Xml.Serialization;
using gbs.bao.etl.entity.deploy;
using System.Drawing;

namespace ETLAdm.cfg
{


    public partial class DbConfigSelect : EtlAdmPage
    {
        
        
        protected override void Page_Init(object sender, EventArgs e)
        {
            base.Page_Init(sender, e);
            ((SiteMaster)Page.Master).HideTop1 = true;
            ((SiteMaster)Page.Master).HideLeft1 = true;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GridView1_DataBind();
                if (GridView1.Rows.Count == 0)
                    btnOk.Visible = false;
            }
        }


        private void GridView1_DataBind()
        {            
            var a = new ConfigDAO().selectDBCfgByPrjId(this.Project_Id);
            List<DBConfig> allDBs = new List<DBConfig>();

            ConfigBO bo = new ConfigBO();
            foreach(ETLCFG c in a)
            {
                allDBs.Add(bo.selectDBConfigSimple(c.AP_ID));
            }

            var result = from d in allDBs
                         select new
                         {
                             ap_id=d.root.AP_ID,
                             dbCfgName = d.root.VAR_NAME,
                             dbName = d.root.VAR_VALUE,
                             dbType = d.cfgType.VAR_VALUE,
                             dbServer = d.cfgServer.VAR_VALUE
                         };

            GridView1.DataSource = result;
            GridView1.DataBind();
        }







        protected void btnExport_Click(object sender, EventArgs e)
        {
            List<string> values = new List<string>();
            foreach (var key in Request.Form.AllKeys.Where(x => x.EndsWith("$checkDB_ApId")).Select(x => x))
            {
                values.Add(Request.Form[key]);
            }
            if (values.Count == 0)
            {
                setMessage(false, "請勾選DB參數");
            }
            else
            {
                DeployBO bo = new DeployBO();
                ResultBean result = bo.ExportCfg(values.Select(x => int.Parse(x)).ToArray());
                Response.Clear();
                Response.ContentType = "text/xml";
                string filename = "ETLCFG_Deploy (DB) " + DateTime.Now.ToString("yyyyMMddHHmm");
                Response.AddHeader("content-disposition", "attachment; filename=\"" + filename + ".xml\"");
                Response.Write(result.data.ToString());
                Response.Flush();
                Response.End();
            }
        }
       
    }
}