﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.util;
using gbs.bao.etl.bo;
using gbs.bao.etl.entity;

namespace ETLAdm.aa
{
    public partial class Acct : EtlAdmPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ObjectDataSource1.SelectParameters[0].DefaultValue = this.UserName;
                ObjectDataSource1.SelectParameters[1].DefaultValue = this.Project_Id.ToString();
                newUserPanel.Visible = Project_Id == 0;
                
            
                if (!newUserPanel.Visible) // non-etladm default show himself.
                {
                    DataList1.DataBind();
                    LinkButton btn = (DataList1.Controls[0].FindControl("userName") as LinkButton);
                    user_name_Click(btn, null);
                }
            }
            
        }
        protected void user_name_Click(object sender, EventArgs e)
        {
            DetailsView1.Visible = true;
            LinkButton link = sender as LinkButton;
            DetailsViewMode mode = DetailsViewMode.Insert;
            switch (link.CommandName)
            {
                case Const.CMD_Replace:
                    mode = DetailsViewMode.Edit;
                    break;
            }

            DetailsView1.ChangeMode(mode);
            DetailsView1.DefaultMode = mode;

            ObjectDataSource2.SelectParameters[0].DefaultValue = link.CommandArgument;
            DetailsView1.DataBind();
        }

        protected void DetailView_DataBind(string userName)
        {
            DetailsView1.Visible = true;    
            DetailsViewMode mode = DetailsViewMode.Edit;
            DetailsView1.ChangeMode(mode);
            DetailsView1.DefaultMode = mode;

            ObjectDataSource2.SelectParameters[0].DefaultValue = userName;
            DetailsView1.DataBind();
        }

        protected void newUser_Click(object sender, EventArgs e)
        {
            user_name_Click(sender, e);
        }

        protected void password_DataBinding(object sender, EventArgs e)
        {
            //TextBox password = sender as TextBox;
            //password.Attributes["value"] = password.Text;
            //TODO password.Text = "";  or not to do. you must change password every time.
        }

        protected void command_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            TextBox userName = ControlUtil.FindInTemplate(btn, "userName") as TextBox;
            TextBox userDesc = ControlUtil.FindInTemplate(btn, "userDesc") as TextBox;
            TextBox password = ControlUtil.FindInTemplate(btn, "password") as TextBox;
            UserBO bo = new UserBO();
            bo.UserName = UserName;
            ResultBean result = null;

            switch (btn.CommandName)
            {
                case Const.CMD_Add:
                    result=setMessage(bo.addUser(userName.Text, userDesc.Text, password.Text));
                    break;
                case Const.CMD_Replace:
                    result=setMessage(bo.updateUser(userName.Text, userDesc.Text, password.Text));
                    break;
                case Const.CMD_Remove:
                    result=setMessage(bo.deleteUser(userName.Text));
                    break;
            }
            if (result.success)
            {             
                DataList1.DataBind();
                if (btn.CommandName == Const.CMD_Add)
                {
                    newUser_Click(this.newUser, e);
                    
                }
                else if (btn.CommandName == Const.CMD_Replace)
                {
                    DetailView_DataBind(userName.Text);
                }
                else
                {
                    DetailsView1.Visible = false;
                }
            }

        }
    }
}
