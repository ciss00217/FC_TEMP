﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using gbs.bao.etl.bo.json;
using gbs.bao.etl.entity;
using System.Web.Script.Serialization;
using System.Web.SessionState;
using gbs.bao.etl.aa;
using System.IO;
using gbs.bao.etl.util;
using System.Security.Principal;

namespace ETLAdm.setting
{
    /// <summary>
    /// $codebehindclassname$ 的摘要描述
    /// </summary>
    public class DownloadLogHandler : EtlAdmHttpHandler_File
    {  

        protected override string ProcessAuthenticatedRequest(HttpContext context, GenericPrincipal principal)
        {
            HttpRequest request = context.Request;
            string history = request["history"];
            string data = request["data"];

            ISignatureBo bo = null;
            if (history == null || history == string.Empty)
            {
                bo = JsonSvcBoFactory.Instance.CreateSignatureBo(JsonSvcConst.ShowLog);
            }
            else
            {
                bo = JsonSvcBoFactory.Instance.CreateSignatureBo(JsonSvcConst.GetLog);
            }
            return bo.execute(data);
        }
    }
}
