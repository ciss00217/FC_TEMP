﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using gbs.bao.etl.bo.json;
using gbs.bao.etl.entity;
using System.Web.Script.Serialization;
using System.Web.SessionState;
using gbs.bao.etl.aa;
using gbs.bao.etl.util;

namespace ETLAdm.setting
{
    /// <summary>
    /// $codebehindclassname$ 的摘要描述
    /// </summary>
    public class GetJobStepShortDataHandler : EtlAdmHttpHandler_InputData_SignatureBo
    {

        protected override string BoName
        {
            get { return JsonSvcConst.GetJobStepShortData; }
        }

        protected override bool IsSignature
        {
            get { return false; }
        }
    }
}
