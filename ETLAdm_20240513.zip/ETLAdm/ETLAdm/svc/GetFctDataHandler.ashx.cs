﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using gbs.bao.etl.bo.json;
using gbs.bao.etl.entity;
using System.Web.Script.Serialization;
using System.Web.SessionState;
using gbs.bao.etl.aa;
using gbs.bao.etl.util;
using System.Security.Principal;

namespace ETLAdm.setting
{
    /// <summary>
    /// $codebehindclassname$ 的摘要描述
    /// </summary>
    public class GetFctDataHandler : EtlAdmHttpHandler_Input_Bo
    {

        protected override string BoName
        {
            get { return JsonSvcConst.GetFctData; }
        }

        protected override bool IsSignature
        {
            get { return false; }
        }

        protected override string GetInput(HttpContext context, GenericPrincipal principal)
        {
            return context.Request.Form["data"];
        }
    }
}
