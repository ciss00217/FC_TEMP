﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using gbs.bao.etl.bo.json;
using gbs.bao.etl.entity;
using System.Web.Script.Serialization;
using System.Web.SessionState;
using gbs.bao.etl.aa;
using NLog;
using gbs.bao.etl.util;

namespace ETLAdm.setting
{
    /// <summary>
    /// $codebehindclassname$ 的摘要描述
    /// </summary>
    public class AddJobsHandler : EtlAdmHttpHandler_InputData_SignatureBo
    {        
        protected override string BoName
        {
            get { return JsonSvcConst.AddJobsInJfw; }
        }

        protected override bool IsSignature
        {
            get { return true; }
        }
    }
}
