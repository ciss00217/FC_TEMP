﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Script.Services;
using gbs.bao.etl.bo.json;
using System.Web.Script.Serialization;
using gbs.bao.etl.aa;

namespace ETLAdm.setting
{
    /// <summary>
    /// SettingService 的摘要描述
    /// </summary>
    [WebService(Namespace = "http://gbs.bao.etl/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    [System.Web.Script.Services.ScriptService]
    public class SettingService : System.Web.Services.WebService
    {

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public void GetJobs()
        {
            HttpResponse response = Context.Response;

            EtlAdmPrincipal p = Context.User as EtlAdmPrincipal;
            int prj_id = p.PrjId;

            string input = string.Format("{{'Project_Id':{0}}}", prj_id);
            string output = JsonSvcBoFactory.Instance.CreateBo(JsonSvcConst.GetJobs).execute(input);
            response.ContentType = "application/json; charset=utf-8";
            response.Write(output);
        }
    }
}
