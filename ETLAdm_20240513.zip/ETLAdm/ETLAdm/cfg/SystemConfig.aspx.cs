﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.util;
using gbs.bao.etl.entity;
using gbs.bao.etl.bo;
using gbs.bao.etl.aa;
using System.Drawing;
using gbs.bao.etl.net;

namespace ETLAdm.cfg
{
    /// <summary>
    /// 頁面-系統參數設定
    /// </summary>
    public partial class SystemConfig : EtlAdmPage
    {
        /// <summary>
        /// prompt: 
        ///     1. 顯示左方資料集
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DataList1_DataBind();
            }
        }

        protected void lnkCfg_Click(object sender, EventArgs e)
        {
            LinkButton link = sender as LinkButton;
            DetailsView1_DataBind(link.CommandArgument);
        }

        protected void DetailsView1_DataBind(string ap_id)
        {
            DetailsView1.ChangeMode(DetailsViewMode.Edit);
            DetailsView1.DefaultMode = DetailsViewMode.Edit;

            ObjectDataSource2.SelectParameters[0].DefaultValue = ap_id;
            DetailsView1.DataBind();
        }

        protected void addCfg_Click(object sender, EventArgs e)
        {
            DetailsView1.ChangeMode(DetailsViewMode.Insert);
            DetailsView1.DefaultMode = DetailsViewMode.Insert;

            DetailsView1.DataBind();
        }

        protected void Copy_Click(Control sender, string ap_id)
        {            
            DetailsView1.ChangeMode(DetailsViewMode.Insert);
            DetailsView1.DefaultMode = DetailsViewMode.Insert;

            DetailsView1.DataBind();

            ObjectDataSource2.SelectParameters[0].DefaultValue = ap_id;
            foreach (ETLCFG cfg in ObjectDataSource2.Select())
            {
                TextBox box = ControlUtil.FindInTemplate(sender, "var_name") as TextBox;
                box.Text = cfg.VAR_NAME + "(Copy)";
                box = ControlUtil.FindInTemplate(sender, "var_desc") as TextBox;
                box.Text = cfg.VAR_DESC;
                box = ControlUtil.FindInTemplate(sender, "var_value") as TextBox;
                box.Text = cfg.VAR_VALUE;
                DropDownList ddl = ControlUtil.FindInTemplate(sender, "var_type") as DropDownList;
                ddl.SelectedValue = cfg.VAR_TYPE;
                box = ControlUtil.FindInTemplate(sender, "pgm_path") as TextBox;
                box.Text = cfg.PGM_PATH;
                ddl = ControlUtil.FindInTemplate(sender, "encrypt_flag") as DropDownList;
                ddl.SelectedValue = cfg.ENCRYPT_FLAG.ToString();
                ddl = ControlUtil.FindInTemplate(sender, "enable_flag") as DropDownList;
                ddl.SelectedValue = cfg.ENABLE_FLAG.ToString();
                
                break;
            }
            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="flag"></param>
        /// <param name="val"></param>
        /// <returns></returns>
        protected string DecryVal(object flag, object val)
        {
            ResultBean bean = null;
            string rtnVal = val as string;
            if (Const.ENABLE_Y.Equals(flag))
            {
                bean = EtlEngineCommandTCPClient.Instance.DecryptString((string)val);
                if (bean.success)
                {
                    rtnVal = bean.data as string;
                }
                else
                {
                    setMessage(false, bean.message);
                }
            }
            return rtnVal;
        }

        protected ETLCFG Adjust(ETLCFG cfg)
        {
            string[] enabled = { Const.CFG_TYPE_SQL, Const.CFG_TYPE_EXPGM };
            if (! enabled.Contains(cfg.VAR_TYPE))
            {
                cfg.PGM_PATH = string.Empty;
            }
            cfg.PRJ_ID = Project_Id;
            return cfg;
        }

        protected void btnOk_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            ConfigBO bo = new ConfigBO();
            bo.UserName = UserName;
            ControlBindHelper<ETLCFG> helper = new ControlBindHelper<ETLCFG>();
            ResultBean result = null;
            int ap_id = -1;
            switch (btn.CommandName)
            {
                case Const.CMD_Add:                    
                    ETLCFG cfg = Adjust(helper.Bind(btn.NamingContainer));                    
                    result = setMessage(bo.addConfig(cfg));
                    break;
                case Const.CMD_Replace:                    
                    cfg = Adjust(helper.Bind(btn.NamingContainer));
                    cfg.AP_ID = Convert.ToInt32(btn.CommandArgument);
                    result = setMessage(bo.replaceConfig(cfg));
                    break;
                case Const.CMD_Remove:
                    ap_id = Convert.ToInt32(btn.CommandArgument);
                    result = setMessage(bo.removeConfig(ap_id));
                    break;
                case Const.CMD_Copy:
                    ap_id = Convert.ToInt32(btn.CommandArgument);
                    result = setMessage(new ResultBean()
                    {
                        success = true,
                        message = Const.MSG_Copy_SUCCESS
                    });
                    break;
            }
            if (result.success)
            {
                DataList1_DataBind();
                switch (btn.CommandName)
                {
                    case Const.CMD_Add:
                        addCfg_Click(addCfg, e);
                        break;
                    case Const.CMD_Replace:
                        DetailsView1_DataBind(result.data.ToString());
                        break;
                    case Const.CMD_Remove:
                        addCfg_Click(addCfg, e);
                        break;
                    case Const.CMD_Copy:
                        Copy_Click(btn, ap_id + "");
                        break;
                }  

            }            
        }
        protected void DataList1_DataBind()
        {
            ObjectDataSource1.SelectParameters[0].DefaultValue = this.Project_Id + "";
            DataList1.DataBind();
        }
    }
}
