﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.entity;
using gbs.bao.etl.dao;
using gbs.bao.etl.util;
using gbs.bao.etl.aa;
using NLog;

namespace ETLAdm
{
    public interface SiteMaster {
        bool HideTop1 { get; set; }
        bool HideLeft1 { get; set; }
    }
    public partial class Site : System.Web.UI.MasterPage, SiteMaster
    {
        Logger logger = LogManager.GetCurrentClassLogger();
        private int PrjId = -1;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Response.Cache.SetCacheability(HttpCacheability.NoCache);
            /*
            if (Request.UserAgent.IndexOf("AppleWebKit") > 0)
            {
                EntertainmentMessage.Attributes.Remove("CssSelectorClass");
                EntertainmentMessage.Attributes.Add("CssSelectorClass", "AppleWebKitMenu");
            }
             * */

            ETLPRJ project = Session[Const.SES_Project] as ETLPRJ;

            if (!IsPostBack)
            {                
                if (project == null)
                {
                    EtlAdmPrincipal principal = Context.User as EtlAdmPrincipal;
                    if (principal == null)
                    {
                        logger.Warn("[0] [" + this.Request.Url + "] principal is null.");
                        Response.Redirect("~/LoginPage.aspx");                        
                        return;
                    }
                    int id = principal.PrjId;                    
                    using (ProjectDAO dao = new ProjectDAO())
                    {
                        project = dao.selectProjectsById(id);
                        Session.Add(Const.SES_Project, project);
                    }
                }
                if (project != null)
                {
                    PrjId = project.PRJ_ID;
                    ProjectName.Text = project.PRJ_NAME;
                    lblUserName.Text = Context.User.Identity.Name;
                }
            }

            if(project==null){
                logger.Warn("[1] [" + this.Request.Url + "] principal is null.");
                Response.Redirect("~/LoginPage.aspx");
            } else {
                string script = @"var projectId={0}; var userName='{1}'; ";
                script = string.Format(script, project.PRJ_ID, lblUserName.Text);
                ScriptManager.RegisterStartupScript(this, this.GetType(), "initial", script, true);
            }            
        }

        private bool ExcludePath(string dataPath)
        {
            string[] exclude = { 
                                   "/ETLAdm/history/JobStepHistory.aspx", 
                                   "/ETLAdm/monitor/JobStepDashboard.aspx"                                 
                               };

            //string[] exclude = {};

            var v = from _v in exclude
                    where _v.Equals(dataPath, StringComparison.OrdinalIgnoreCase)
                    select _v;
            return v.Count() > 0;
        }

        protected void EntertainmentMessage_MenuItemDataBound(object sender, MenuEventArgs e)
        {
            bool exclude = false;
            Menu menu = sender as Menu;

            // 排除ETLManager啟動/關閉予etladm以外的使用者
            if (e.Item.DataPath.Equals("/ETLAdm/sys/TurnCommand.aspx", StringComparison.OrdinalIgnoreCase))
            {
                exclude = PrjId != 0;                
            }
            else if (e.Item.DataPath.Equals("/ETLAdm/sys/JFCommand.aspx", StringComparison.OrdinalIgnoreCase))
            {
                exclude = PrjId == 0;
            }
            else
            {
                exclude = ExcludePath(e.Item.DataPath);
            }

            if (exclude)
            {
                e.Item.Parent.ChildItems.Remove(e.Item);
            }
        }

        protected void Page_PreRender(object sender, EventArgs e)
        {
            // Avoid CSRF 
            string token = AntiForgery.NewToken();
            AntiForgeryToken.Text = AntiForgery.GetHiddenFieldHtml(token);
            if (HideTop1)
            {
                top1.Visible = false;
                top2.Visible = false;
            }
            if (HideLeft1)
            {
                left1.Visible = false;
            }
        }

        public bool HideTop1
        {
            get;
            set;
        }

        public bool HideLeft1
        {
            get;
            set;
        }
    }
}
