﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.dao;
using gbs.bao.etl.util;
using gbs.bao.etl.entity;

namespace ETLAdm.history
{
    public partial class FctHistory : EtlAdmPage
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            //GridView1.Visible = false;
            ObjectDataSource1.SelectParameters["prjId"].DefaultValue = Project_Id.ToString();
            if (!IsPostBack)
            {
                bindDdlSrcCode();
            }
        }


        protected void btnSearch_Click(object sender, EventArgs e)
        {
            GridView1.Visible = true;
            GridView1.DataBind();
        }

        //SrcCode下拉選單
        protected void bindDdlSrcCode()
        {
            this.ddlSrcCode.Items.Clear();
            this.ddlSrcCode.Items.Add(new ListItem("全部", "All"));

            this.ddlSrcCode.DataSource = new FctDAO().selectDistinctSrcCode(Project_Id);
            //this.ddlSrcCode.DataTextField = "Text";
            //this.ddlSrcCode.DataValueField = "Value";
            this.ddlSrcCode.DataBind();
        }
    }
}
