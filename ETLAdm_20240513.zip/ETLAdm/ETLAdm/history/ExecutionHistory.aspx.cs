﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.dao;
using gbs.bao.etl.util;
using gbs.bao.etl.entity;

namespace ETLAdm.history
{
    public partial class ExecutionHistory : EtlAdmPage
    {
        public HiddenField TheHdnFlowRunID
        {
            get
            {
                return hdnJobFlowRunID;
            }
        }
        public HiddenField TheHdnJobRunID
        {
            get
            {
                return hdnJobRunID;
            }
        }
        public HiddenField TheHdnFlowID
        {
            get
            {
                return hdnJobFlowID;
            }
        }
        public HiddenField TheHdnJobID
        {
            get
            {
                return hdnJobID;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            //GridView1.Visible = false;
            if (!IsPostBack)
            {
                ddlFreq_SelectedIndexChanged(ddlFreq, null);
                GridView1.Visible = false;
            }
            else
            {
                GridView1.Visible = true;
            }
        }

        protected void ddlFreq_SelectedIndexChanged(object sender, EventArgs e)
        {
            bindDdlFreqName();
            bindDdlJobFlowType();

            ddl_Initialize(ddlJobFlow);
            bindDdlJobFlow();
        }

        private void ddl_Initialize(DropDownList ddl)
        {
            ListItem item = ddl.Items[0];
            ddl.Items.Clear();
            ddl.Items.Add(item);
        }

        protected void ddlJobFlow_SelectedIndexChanged(object sender, EventArgs e)
        {            
            ddl_Initialize(ddlJob);
            using (JobInstDAO dao = new JobInstDAO())
            {
                int ap_id = Convert.ToInt32(ddlJobFlow.SelectedValue);
                if (ddlJobFlow.SelectedIndex != 0)
                {
                    var v = dao.selectJobIdAndNameByJobFlowId(ap_id);
                    ddlJob.DataSource = v.Distinct().ToList().OrderBy(x=>x.t2);                    
                }
                else
                {
                    ddlJob.DataSource = null;
                }
                ddlJob.DataBind();
                ddlJob_SelectedIndexChanged(ddlJob, e);
            }
        }

        protected void ddlFreqName_SelectedIndexChanged(object sender, EventArgs e)
        {
            bindDdlJobFlowType();
            bindDdlJobFlow();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            string status="'DUMP'";
            if (cbStatusS.Checked) status += ",'S'";
            if (cbStatusF.Checked) status += ",'F'";
            if (cbStatusP.Checked) status += ",'P'";
            if (cbStatusC.Checked) status += ",'C'";
            if (cbStatusW.Checked) status += ",'W'";
            if (cbStatusX.Checked) status += ",'X'";

            
            ObjectDataSource1.SelectParameters["prj_id"].DefaultValue = this.Project_Id + "";
            ObjectDataSource1.SelectParameters["run_freq"].DefaultValue = ddlFreq.SelectedValue;
            ObjectDataSource1.SelectParameters["run_freq_name"].DefaultValue = ddlFreqName.SelectedValue;
            ObjectDataSource1.SelectParameters["job_flow_type"].DefaultValue = ddlJobFlowType.SelectedValue;

            ObjectDataSource1.SelectParameters["job_flow_id"].DefaultValue = ddlJobFlow.SelectedValue;
            ObjectDataSource1.SelectParameters["job_id"].DefaultValue = ddlJob.SelectedValue;
            ObjectDataSource1.SelectParameters["begin"].DefaultValue = tbxBeginDT.Text.Trim() == string.Empty ? null : tbxBeginDT.Text + " 00:00:00";
            ObjectDataSource1.SelectParameters["end"].DefaultValue = tbxEndDT.Text.Trim() == string.Empty ? null : tbxEndDT.Text + " 23:59:59";
            //ObjectDataSource1.SelectParameters["st"].DefaultValue = ddlStatus.SelectedIndex == 0 ? null : ddlStatus.SelectedValue;
            ObjectDataSource1.SelectParameters["st"].DefaultValue = status;
            ObjectDataSource1.SelectParameters["dataBegin"].DefaultValue = tbxBeginDataDT.Text.Trim() == string.Empty ? null : tbxBeginDataDT.Text + " 00:00:00";
            ObjectDataSource1.SelectParameters["dataEnd"].DefaultValue = tbxEndDataDT.Text.Trim() == string.Empty ? null : tbxEndDataDT.Text + " 23:59:59";

            GridView1.Visible = true;
            GridView1.DataBind();
        }

        protected void ddlJob_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnSearch_Click(btnSearch, e);
        }

        protected void cbStatus_CheckedChanged(object sender, EventArgs e)
        {
            btnSearch_Click(btnSearch, e);
        }

        protected void btnSelectAll_Click(object sender, EventArgs e)
        {
            
            cbStatusS.Checked = true;
            cbStatusF.Checked = true;
            cbStatusP.Checked = true;
            cbStatusC.Checked = true;
            cbStatusW.Checked = true;
            cbStatusX.Checked = true;
            
            btnSearch_Click(btnSearch, e);
        }

        protected void btnCancelAll_Click(object sender, EventArgs e)
        {

            cbStatusS.Checked = false;
            cbStatusF.Checked = false;
            cbStatusP.Checked = false;
            cbStatusC.Checked = false;
            cbStatusW.Checked = false;
            cbStatusX.Checked = false;

            btnSearch_Click(btnSearch, e);
        }

        protected void bindDdlFreqName()
        {
            string freq = ddlFreq.SelectedValue;
            this.ddlFreqName.Items.Clear();
            this.ddlFreqName.Items.Add(new ListItem("全部", "A"));
            this.ddlFreqName.DataSource = new FrequencyDAO().selectNames(Project_Id, freq);
            this.ddlFreqName.DataTextField = "Text";
            this.ddlFreqName.DataValueField = "Value";
            this.ddlFreqName.DataBind();

            
        }

        protected void bindDdlJobFlowType()
        {
            JobFlowDAO dao = new JobFlowDAO();
            var v2 = from _v in dao.selectJfwAndJfqByPrjId(this.Project_Id)
                     where ((_v.e2 != null && ddlFreq.SelectedValue.Equals(_v.e2.RUN_FREQ.ToString())) // 選擇 D,W,M,Y,B,F
                        || (ddlFreq.SelectedValue.Equals(Const.RUN_FREQ_Others) && _v.e2 == null) // 選擇Others
                        || (ddlFreq.SelectedValue.Equals("A") ))
                        && (ddlFreqName.SelectedValue.Equals("A") || ddlFreqName.SelectedValue.Equals(_v.e2.RUN_FREQ_NAME))
                     orderby _v.e1.JOB_FLOW_NAME
                     select _v.e1.JOB_FLOW_TYPE;
            ddlJobFlowType.Items.Clear();
            ddlJobFlowType.Items.Add(new ListItem("全部", "A"));
            ddlJobFlowType.DataSource = v2.Distinct().ToList();
            ddlJobFlowType.DataBind();
        }

        protected void bindDdlJobFlow()
        {
            using (JobFlowDAO dao = new JobFlowDAO())
            {
                //if (ddlFreq.SelectedIndex != 0)
                //{
                    var v = from _v in dao.selectJfwAndJfqByPrjId(this.Project_Id)
                            where ((_v.e2 != null && ddlFreq.SelectedValue.Equals(_v.e2.RUN_FREQ.ToString())) // 選擇 D,W,M,Y,B,F
                               || (ddlFreq.SelectedValue.Equals(Const.RUN_FREQ_Others) && _v.e2 == null) // 選擇Others
                               || (ddlFreq.SelectedValue.Equals("A") ))
                               && (ddlFreqName.SelectedValue.Equals("A") || ddlFreqName.SelectedValue.Equals(_v.e2.RUN_FREQ_NAME))
                               && (ddlJobFlowType.SelectedValue.Equals("A") || ddlJobFlowType.SelectedValue.Equals(_v.e1.JOB_FLOW_TYPE)) 
                            orderby _v.e1.JOB_FLOW_NAME
                            select new KeyValueEntities<int, string> { t1 = _v.e1.AP_ID, t2 = _v.e1.JOB_FLOW_NAME };


                    ddlJobFlow.DataSource = v.Distinct().ToList();
                    ddlJobFlow.Enabled = true;
                    ddlJob.Enabled = true;
                    btnSearch.Enabled = true;
                //}
                //else
                //{
                //    ddlJobFlow.DataSource = null;
                //}
                ddlJobFlow.Items.Clear();
                ddlJobFlow.Items.Add(new ListItem("全部", "-99"));
                
                ddlJobFlow.DataBind();
                ddlJobFlow_SelectedIndexChanged(ddlJobFlow, null);
            }
        }

        protected void ddlJobFlowType_SelectedIndexChanged(object sender, EventArgs e)
        {
            bindDdlJobFlow();

        }



    }
}
