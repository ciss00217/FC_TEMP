﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.util;
using gbs.bao.etl.dao;
using gbs.bao.etl.entity;
using System.Web.Script.Serialization;
using gbs.bao.etl.bo.json;
using gbs.bao.etl.bo.json.entity;
using gbs.bao.etl.bo.json.core;

namespace ETLAdm.history
{
    public partial class JobStepHistorySearch : EtlAdmPage
    {

        private string _TheSort;

        public string TheSort
        {
            get
            {
                _TheSort = ViewState["TheSort"] as string;
                return _TheSort;
            }
            set
            {
                _TheSort = value;
                ViewState["TheSort"] = _TheSort;
            }
        }


        public bool IsETLEXE
        {
            get
            {
                return this.User.IsInRole("ETLEXE");
            }
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            this.ClientScript.RegisterOnSubmitStatement(
                this.GetType(),
                "ClearData",
                "$('#log_detail').text('')");

            CurrentDateTime.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            String originalFlowID = null;



            if (IsPostBack)
            {
                originalFlowID = Request.Form["hdnOriginalFlowID"];
                if (string.IsNullOrEmpty(TheSort))
                    TheSort = this.GridView_Job_Steps.ID + "&" + "JOB_FLOW_NAME" + "&" + SortDirection.Ascending.ToString();
            }
            else
            {
                bindDdlFreqName();
                bindDdlJobFlowType();
                bindDdlJobFlow();
                bindDdlJob();

                if (PreviousPage != null)
                {
                    originalFlowID = Request.Form["sel_job_flow"];
                    String originalJobID = PreviousPage.TheCommandArgument.Value;
                    ddlJobFlows.DataBind();
                    string jobFlowType = Request.QueryString["JobFlowType"];
                    string jobFlowSt = Request.QueryString["JobFlowSt"];
                    string beginDt = Server.UrlDecode(Request.QueryString["BeginDT"]);
                    string endDt = Server.UrlDecode(Request.QueryString["EndDT"]);
                    string freq = Server.UrlDecode(Request.QueryString["Freq"]);
                    string freqname = Server.UrlDecode(Request.QueryString["FreqName"]);
                    string href = string.Concat(
                            "~/monitor/Dashboard.aspx",
                            "?JobFlowType=", Server.UrlEncode(jobFlowType),
                            "&JobFlowSt=", Server.UrlEncode(jobFlowSt),
                            "&BeginDT=" + Server.UrlEncode(beginDt),
                            "&EndDT=" + Server.UrlEncode(endDt),
                            "&Freq=" + Server.UrlEncode(freq),
                            "&FreqName=" + Server.UrlEncode(freqname)
                        );


                    using (JobInstDAO dao = new JobInstDAO())
                    {
                        int jobApId = 0;
                        if (!int.TryParse(originalJobID, out jobApId))
                        {
                            logger.Error("Argument error[0]: " + originalJobID);
                        }
                        ETLJOB job = dao.selectJOBByApId(jobApId);
                        if (job != null)
                        {
                            ddlJobFlows.SelectedValue = job.JOB_FLOW_ID.ToString();

                            ddlJobFlows_SelectedIndexChanged(ddlJobFlows, new EventArgs());
                            ddlJob.SelectedValue = originalJobID;
                        }
                        if (ddlJob.SelectedIndex == 0)
                        {
                            logger.Error("Argument error[1]: " + originalJobID);
                        }
                        else
                        {
                            GridView_DataBind();
                        }
                    }
                }
            }
            Page.ClientScript.RegisterStartupScript(this.GetType(), "fillOrginalFlowID", "$(function() { $('input#hdnOriginalFlowID').val('" + originalFlowID + "'); });", true);
        }

        protected void ddlJobFlows_SelectedIndexChanged(object sender, EventArgs e)
        {
            bindDdlJob();
            GridView_Job_Steps.PageIndex = 0;
            GridView_DataBind();
        }

        protected void jobStepNameFilter(object sender, EventArgs e)
        {
            GridView_Job_Steps.PageIndex = 0;
            GridView_DataBind();
        }

        protected void btnChange_Click(object sender, EventArgs e)
        {
            this.hdnShowLogStepApId.Value = "";
            GridView_DataBind();
        }

        private void GridView_DataBind()
        {
            int prjID = this.Project_Id;
            string jobFlowName = ddlJobFlows.SelectedIndex == 0 ? "" : ddlJobFlows.SelectedItem.Text;
            string jobName = ddlJob.SelectedIndex == 0 ? "" : ddlJob.SelectedItem.Text;
            string jobFlowType = ddlJobFlowType.SelectedIndex == 0 ? "" : ddlJobFlowType.SelectedValue;
            string jobStepName = this.tbFilterJobStepName.Text;
            string status = (this.cbStatusS.Checked ? "S" : "") +
                            (this.cbStatusF.Checked ? "F" : "") +
                            (this.cbStatusP.Checked ? "P" : "") +
                            (this.cbStatusC.Checked ? "C" : "") +
                            (this.cbStatusW.Checked ? "W" : "") +
                            (this.cbStatusX.Checked ? "X" : "");
            string freq = ddlFreq.SelectedIndex == 0 ? "" : ddlFreq.SelectedValue;
            string freqName = ddlFreqName.SelectedIndex == 0 ? "" : ddlFreqName.SelectedValue;
            DateTime? beginDate = String.IsNullOrEmpty(tbxBeginDT.Text) ? (DateTime?)null : Convert.ToDateTime(tbxBeginDT.Text + " 00:00:00");
            DateTime? endDate = String.IsNullOrEmpty(tbxEndDT.Text) ? (DateTime?)null : Convert.ToDateTime(tbxEndDT.Text + " 23:59:59");
            DateTime? dataStartDate = String.IsNullOrEmpty(tbxBeginDataDT.Text) ? (DateTime?)null : Convert.ToDateTime(tbxBeginDataDT.Text + " 00:00:00");
            DateTime? dateEndDate = String.IsNullOrEmpty(tbxEndDataDT.Text) ? (DateTime?)null : Convert.ToDateTime(tbxEndDataDT.Text + " 23:59:59");

            List<FiveEntities<ETLJSP_HIS, ETLJSD, ETLJBD, ETLJFW, ETLJFQ>> datasource = new JobStepHistoryDAO().selectJobStepHis(prjID, jobFlowType, jobFlowName, jobName, jobStepName, status, freq, freqName, beginDate, endDate, dataStartDate, dateEndDate);
            var v = (from _v in datasource                     
                     orderby _v.e4.JOB_FLOW_NAME, _v.e3.JOB_NAME, _v.e2.RUN_SEQ
                     select new
                     {
                         RUN_SEQ = _v.e2.RUN_SEQ,
                         JOB_FLOW_NAME = _v.e4.JOB_FLOW_NAME,
                         JOB_NAME = _v.e3.JOB_NAME,
                         JOB_TYPE = _v.e3.JOB_TYPE,
                         JOB_STEP_ID = _v.e2.JOB_STEP_ID,
                         JOB_STEP_NAME = _v.e2.JOB_STEP_NAME,
                         JOB_STEP_STATUS = _v.e1.JOB_STEP_STATUS,
                         JOB_START_DT = _v.e1.JOB_START_DT,
                         JOB_END_DT = _v.e1.JOB_END_DT,
                         RUN_START_TIM = _v.e1.RUN_START_TIM,
                         RUN_END_TIM = _v.e1.RUN_END_TIM,
                         AP_ID = _v.e1.AP_ID,
                         RUN_FREQ = (_v.e5.RUN_FREQ.ToString().Equals("D") ? "每天-" + _v.e5.RUN_FREQ_NAME :
                                   _v.e5.RUN_FREQ.ToString().Equals("W") ? "每週-" + _v.e5.RUN_FREQ_NAME :
                                   _v.e5.RUN_FREQ.ToString().Equals("M") ? "每月-" + _v.e5.RUN_FREQ_NAME :
                                   _v.e5.RUN_FREQ.ToString().Equals("Y") ? "每年-" + _v.e5.RUN_FREQ_NAME :
                                   _v.e5.RUN_FREQ.ToString().Equals("F") ? "檔案-" + _v.e5.RUN_FREQ_NAME :
                                   _v.e5.RUN_FREQ.ToString().Equals("R") ? "重覆-" + _v.e5.RUN_FREQ_NAME :
                                   _v.e5.RUN_FREQ.ToString().Equals("I") ? "單次-" + _v.e5.RUN_FREQ_NAME :
                                   "")
                     });

            string sortExpression = "";
            string sortDirection = "";

            if (!string.IsNullOrEmpty(TheSort))
            {
                string[] t = TheSort.Split("&".ToCharArray());
                sortExpression = t[1];
                sortDirection = t[2];
            }

            if (SortDirection.Ascending.ToString().Equals(sortDirection))
            {
                if ("JOB_FLOW_NAME".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.JOB_FLOW_NAME);
                }
                else if ("JOB_NAME".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.JOB_NAME);
                }
                else if ("JOB_STEP_NAME".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.JOB_STEP_NAME);
                }
                else if ("JOB_STEP_STATUS".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.JOB_STEP_STATUS);
                }
                else if ("JOB_START_DT".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.JOB_START_DT);
                }
                else if ("JOB_END_DT".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.JOB_END_DT);
                }
                else if ("RUN_START_TIM".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.RUN_START_TIM);
                }
                else if ("RUN_END_TIM".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.RUN_END_TIM);
                }
                else if ("RUN_DUR".Equals(sortExpression))
                {
                    v = v.OrderBy(x => CalcUtilities.EvalDuring(x.RUN_START_TIM, x.RUN_END_TIM));
                }
                else if ("RUN_FREQ".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.RUN_FREQ);
                }
            }
            else
            {
                if ("JOB_FLOW_NAME".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.JOB_FLOW_NAME);
                }
                else if ("JOB_NAME".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.JOB_NAME);
                }
                else if ("JOB_STEP_NAME".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.JOB_STEP_NAME);
                }
                else if ("JOB_STEP_STATUS".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.JOB_STEP_STATUS);
                }
                else if ("JOB_START_DT".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.JOB_START_DT);
                }
                else if ("JOB_END_DT".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.JOB_END_DT);
                }
                else if ("RUN_START_TIM".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.RUN_START_TIM);
                }
                else if ("RUN_END_TIM".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.RUN_END_TIM);
                }
                else if ("RUN_DUR".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => CalcUtilities.EvalDuring(x.RUN_START_TIM, x.RUN_END_TIM));
                }
                else if ("RUN_FREQ".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.RUN_FREQ);
                }
            }

            GridView_Job_Steps.DataSource = v.ToList();
            GridView_Job_Steps.DataBind();

        }

        protected void btnExecutionSubmit_Click(object sender, EventArgs args)
        {
            if (!this.IsReFlesh)
            {
                RunJobBean entity = new JavaScriptSerializer().Deserialize<RunJobBean>(hdnCommandArgument.Value);
                ISignatureBo bo = JsonSvcBoFactory.Instance.CreateSignatureBo(JsonSvcConst.RunJob);
                bo.UserName = this.UserName;
                ResultBean bean = setMessage(((ITypeBo<RunJobBean>)bo).Execute(entity));
                RegistSessionKeyUpdate();
            }
            GridView_DataBind();
        }

        protected void btnCancelSubmit_Click(object sender, EventArgs args)
        {
            if (!this.IsReFlesh)
            {
                int ap_id = Int32.Parse(hdnCommandArgument.Value);
                JobDefineBean entity = new JobDefineBean()
                {
                    PRJ_ID = this.Project_Id,
                    JOB_STEP_AP_ID = ap_id
                };

                ISignatureBo bo = JsonSvcBoFactory.Instance.CreateSignatureBo(JsonSvcConst.CancelJob);
                bo.UserName = this.UserName;
                ResultBean bean = setMessage(((ITypeBo<JobDefineBean>)bo).Execute(entity));
                RegistSessionKeyUpdate();
            }
            GridView_DataBind();
        }

        protected void btnReflash_Click(object sender, EventArgs args)
        {
            GridView_DataBind();
        }

        protected void btnSelectAll_Click(object sender, EventArgs e)
        {

            cbStatusS.Checked = true;
            cbStatusF.Checked = true;
            cbStatusP.Checked = true;
            cbStatusC.Checked = true;
            cbStatusW.Checked = true;
            cbStatusX.Checked = true;

            GridView_Job_Steps.PageIndex = 0;
            GridView_DataBind();

        }

        protected void btnCancelAll_Click(object sender, EventArgs e)
        {

            cbStatusS.Checked = false;
            cbStatusF.Checked = false;
            cbStatusP.Checked = false;
            cbStatusC.Checked = false;
            cbStatusW.Checked = false;
            cbStatusX.Checked = false;

            GridView_Job_Steps.PageIndex = 0;
            GridView_DataBind();

        }

        protected void cbStatus_CheckedChanged(object sender, EventArgs e)
        {
            GridView_Job_Steps.PageIndex = 0;
            GridView_DataBind();
        }

        protected void gvPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView_Job_Steps.PageIndex = e.NewPageIndex;
            GridView_DataBind();
        }



        protected void GridView_Type_Sorting(object sender, GridViewSortEventArgs e)
        {
            GridView view = sender as GridView;
            if (string.IsNullOrEmpty(TheSort))
            {
                TheSort = view.ID + "&" + e.SortExpression + "&" + e.SortDirection;
            }
            else
            {
                string[] theSort = TheSort.Split("&".ToCharArray());
                if (view.ID.Equals(theSort[0]))
                {
                    if (e.SortExpression.Equals(theSort[1]))
                    {
                        if (SortDirection.Ascending.ToString().Equals(theSort[2]))
                        {
                            TheSort = view.ID + "&" + e.SortExpression + "&" + SortDirection.Descending;
                        }
                        else
                        {
                            TheSort = view.ID + "&" + e.SortExpression + "&" + SortDirection.Ascending;
                        }
                    }
                    else
                    {
                        TheSort = view.ID + "&" + e.SortExpression + "&" + e.SortDirection;
                    }
                }
                else
                {
                    TheSort = view.ID + "&" + e.SortExpression + "&" + e.SortDirection;
                }
            }
            GridView_Job_Steps.PageIndex = 0;
            GridView_DataBind();
        }

        protected void ddlJobFlowType_SelectedIndexChanged(object sender, EventArgs e)
        {
            bindDdlJobFlow();
            ddlJobFlows.SelectedIndex = 0;
            bindDdlJob();
            ddlJob.SelectedIndex = 0;
            GridView_Job_Steps.PageIndex = 0;
            GridView_DataBind();
        }

        protected void ddlFreq_SelectedIndexChanged(object sender, EventArgs e)
        {
            bindDdlFreqName();
            bindDdlJobFlowType();
            bindDdlJobFlow();
            ddlFreqName.SelectedIndex = 0;
            GridView_Job_Steps.PageIndex = 0;
            GridView_DataBind();
        }

        protected void ddlFreqName_SelectedIndexChanged(object sender, EventArgs e)
        {
            bindDdlJobFlowType();
            bindDdlJobFlow();
            GridView_Job_Steps.PageIndex = 0;
            GridView_DataBind();
        }

        protected void bindDdlJobFlow()
        {
            ObjectDataSource1.SelectParameters[0].DefaultValue = Project_Id.ToString();
            ObjectDataSource1.SelectParameters[1].DefaultValue = ddlJobFlowType.SelectedIndex == 0 ? "" : ddlJobFlowType.SelectedValue;
            ObjectDataSource1.SelectParameters[2].DefaultValue = ddlFreq.SelectedIndex == 0 ? "" : this.ddlFreq.SelectedValue;
            ObjectDataSource1.SelectParameters[3].DefaultValue = ddlFreqName.SelectedIndex == 0 ? "" : this.ddlFreqName.SelectedValue;
            ddlJobFlows.Items.Clear();
            ddlJobFlows.Items.Add(new ListItem("---請選擇---", "---請選擇---"));
            ddlJobFlows.DataBind();

        }

        protected void bindDdlFreqName()
        {
            string freq = ddlFreq.SelectedValue;
            this.ddlFreqName.Items.Clear();
            this.ddlFreqName.Items.Add(new ListItem("全部", "All"));
            this.ddlFreqName.DataSource = new FrequencyDAO().selectNames(Project_Id, freq);
            this.ddlFreqName.DataTextField = "Text";
            this.ddlFreqName.DataValueField = "Value";
            this.ddlFreqName.DataBind();
        }

        protected void bindDdlJobFlowType()
        {
            this.ddlJobFlowType.Items.Clear();
            this.ddlJobFlowType.Items.Add(new ListItem("---請選擇---", "---請選擇---"));

            JobFlowDAO dao = new JobFlowDAO();
            var v2 = from _v in dao.selectJfwAndJfqByPrjId(this.Project_Id)
                     where ((_v.e2 != null && ddlFreq.SelectedValue.Equals(_v.e2.RUN_FREQ.ToString())) // 選擇 D,W,M,Y,B,F
                        || (ddlFreq.SelectedValue.Equals(Const.RUN_FREQ_Others) && _v.e2 == null) // 選擇Others
                        || (ddlFreq.SelectedValue.Equals("All")))
                        && (ddlFreqName.SelectedValue.Equals("All") || ddlFreqName.SelectedValue.Equals(_v.e2.RUN_FREQ_NAME))
                     orderby _v.e1.JOB_FLOW_NAME
                     select _v.e1.JOB_FLOW_TYPE;


            this.ddlJobFlowType.DataSource = v2.Distinct().ToList(); //new JobFlowDAO().selectDistinctTypes(Project_Id);
            this.ddlJobFlowType.DataBind();
        }

        protected void bindDdlJob()
        {
            ObjectDataSource2.SelectParameters[0].DefaultValue = this.Project_Id.ToString();
            ObjectDataSource2.SelectParameters[1].DefaultValue = ddlJobFlows.SelectedIndex == 0 ? "-1" : ddlJobFlows.SelectedValue;
            ddlJob.Items.Clear();
            ddlJob.Items.Add(new ListItem("---請選擇---", "---請選擇---"));
            ddlJob.DataBind();
        }

        protected void ddlJob_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridView_Job_Steps.PageIndex = 0;
            GridView_DataBind();
        }

    }
}
