﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.util;
using gbs.bao.etl.dao;
using gbs.bao.etl.entity;
using gbs.bao.etl.bo.json;
using gbs.bao.etl.bo.json.entity;
using System.Web.Script.Serialization;
using gbs.bao.etl.bo.json.core;
using gbs.bao.etl.entity.proxy;
using System.Collections;

namespace ETLAdm.monitor
{
    /// <summary>
    /// CommandName - Control by show detail button
    ///     ''  : initial (Job flow dashboard)
    ///     '0' : Job flow dependence.  
    ///     '1' : Job dependence in the job flow.
    /// 
    /// CommandArgument - Control by browser to execute command and response from server will modify again for show.
    /// 
    /// </summary>
    public partial class Dashboard : EtlAdmPage
    {

        private string _TheSort;

        public string TheSort
        {
            get
            {
                _TheSort = ViewState["TheSort"] as string;
                return _TheSort;
            }
            set
            {
                _TheSort = value;
                ViewState["TheSort"] = _TheSort;
            }
        }

        public HiddenField TheCommandArgument { get { return hdnCommandArgument; } }

        public DropDownList TheAutoRefreshMin { get { return AutoRefreshMin; } }

        public DropDownList TheAutoRefreshSec { get { return AutoRefreshSec; } }

        public CheckBox TheCbxAutoRefresh { get { return cbxAutoRefresh; } }

        public bool IsETLEXE
        {
            get
            {
                return this.User.IsInRole("ETLEXE");
            }
        }
        public readonly char[] runFreqs = Const.RUN_FREQs.Where(x => Const.RUN_FREQ_Others != x).Select(x => x).ToArray();

        protected void Page_Load(object sender, EventArgs e)
        {
            CurrentDateTime.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");

            if (!IsPostBack)
            {
                if (PreviousPage == null)
                {
                    this.ddlJobFlowType.DataSource = new JobFlowDAO().selectDistinctTypes(Project_Id);
                    this.ddlJobFlowType.DataBind();

                    this.ddlFreqName.DataSource = new FrequencyDAO().selectNames(Project_Id,null);
                    this.ddlFreqName.DataTextField = "Text";
                    this.ddlFreqName.DataValueField = "Value";
                    this.ddlFreqName.DataBind();

                    bindFromQueryString();
                    this.hdnCommandName.Value = string.Empty;
                    this.hdnCommandArgument.Value = string.Empty;
                    GridView_DataBind();
                }
                else
                {
                    this.hdnCommandName.Value = "1";
                    this.hdnCommandArgument.Value = Request.Form["hdnOriginalFlowID"];
                    bindFromQueryString();                    
                }                                

            }

            this.hdnJobFlowSt.Value = "";
            if (this.cbStatusS.Checked == true) this.hdnJobFlowSt.Value += "S";
            if (this.cbStatusF.Checked == true) this.hdnJobFlowSt.Value += "F";
            if (this.cbStatusP.Checked == true) this.hdnJobFlowSt.Value += "P";
            if (this.cbStatusC.Checked == true) this.hdnJobFlowSt.Value += "C";
            if (this.cbStatusW.Checked == true) this.hdnJobFlowSt.Value += "W";
            if (this.cbStatusX.Checked == true) this.hdnJobFlowSt.Value += "X";

            string href = string.Concat(
                    "~/monitor/JobStepDashboard.aspx",
                    "?JobFlowType=" , this.ddlJobFlowType.SelectedValue,
                    "&JobFlowSt=", this.hdnJobFlowSt.Value,//this.ddlJobFlowSt.SelectedValue,
                    "&BeginDT=" + Server.UrlEncode(this.tbxBeginDT.Text),
                    "&EndDT=" + Server.UrlEncode(this.tbxEndDT.Text),
                    "&Freq=" + Server.UrlEncode(this.ddlFreq.SelectedValue),
                    "&FreqName=" + Server.UrlEncode(this.ddlFreqName.SelectedValue)
                );
            this.btnSubmitToJobStep.PostBackUrl =  href ;                    
        }

        private void bindFromQueryString()
        {
            string jobFlowType = Request.QueryString["JobFlowType"];
            string jobFlowSt = Request.QueryString["JobFlowSt"];
            string beginDt = Server.UrlDecode(Request.QueryString["BeginDT"]);
            string endDt = Server.UrlDecode(Request.QueryString["EndDT"]);
            string freq = Server.UrlDecode(Request.QueryString["Freq"]);
            string freqName = Server.UrlDecode(Request.QueryString["FreqName"]);

            if (ddlJobFlowType.Items.Count == 1)
            {
                this.ddlJobFlowType.DataSource = new JobFlowDAO().selectDistinctTypes(Project_Id);
                this.ddlJobFlowType.DataBind();
            }
            
            if (!string.IsNullOrEmpty(jobFlowType))
            {
                ListItem item = this.ddlJobFlowType.Items.FindByValue(jobFlowType);
                if (item != null)
                {
                    item.Selected = true;
                }
            }

            if (!string.IsNullOrEmpty(jobFlowSt))
            {
                this.cbStatusS.Checked = jobFlowSt.Contains("S");
                this.cbStatusF.Checked = jobFlowSt.Contains("F");
                this.cbStatusP.Checked = jobFlowSt.Contains("P");
                this.cbStatusC.Checked = jobFlowSt.Contains("C");
                this.cbStatusW.Checked = jobFlowSt.Contains("W");
                this.cbStatusX.Checked = jobFlowSt.Contains("X");


                //ListItem item = this.ddlJobFlowSt.Items.FindByValue(jobFlowSt);
                //if (item != null)
                //{
                //    item.Selected = true;
                //}
            }
            this.tbxBeginDT.Text = beginDt;
            this.tbxEndDT.Text = endDt;
            if(!string.IsNullOrEmpty(freq)){
                ListItem item = this.ddlFreq.Items.FindByValue(freq);
                if (item != null)
                {
                    item.Selected = true;

                    this.ddlFreqName.Items.Clear();
                    this.ddlFreqName.Items.Add(new ListItem("全部", "All"));

                    this.ddlFreqName.DataSource = new FrequencyDAO().selectNames(Project_Id, this.ddlFreq.SelectedIndex == 0 ? null : this.ddlFreq.SelectedValue);
                    this.ddlFreqName.DataTextField = "Text";
                    this.ddlFreqName.DataValueField = "Value";
                    this.ddlFreqName.DataBind();

                }
            }

            if (!string.IsNullOrEmpty(freqName))
            {
                ListItem item = this.ddlFreqName.Items.FindByValue(freqName);
                if (item != null)
                {
                    item.Selected = true;
                }
            }
            
        }        

        
        
        protected void GridView_DataBind()
        {
            JobFlowDAO dao = new JobFlowDAO();
            var st = dao.selectJfwAndJfqByPrjId(this.Project_Id)
                .Where(x =>
                    (this.ddlJobFlowType.SelectedIndex == 0 || this.ddlJobFlowType.SelectedValue.Equals(x.e1.JOB_FLOW_TYPE))
                    && (    (this.cbStatusS.Checked && x.e1.JOB_FLOW_STATUS.ToString().Equals("S")) || 
                            (this.cbStatusF.Checked && x.e1.JOB_FLOW_STATUS.ToString().Equals("F")) || 
                            (this.cbStatusP.Checked && x.e1.JOB_FLOW_STATUS.ToString().Equals("P")) || 
                            (this.cbStatusC.Checked && x.e1.JOB_FLOW_STATUS.ToString().Equals("C")) || 
                            (this.cbStatusW.Checked && x.e1.JOB_FLOW_STATUS.ToString().Equals("W")) || 
                            (this.cbStatusX.Checked && x.e1.JOB_FLOW_STATUS.ToString().Equals("X")) )  
                    && (x.e2==null || this.ddlFreqName.SelectedIndex == 0 || this.ddlFreqName.SelectedValue.Equals(x.e2.RUN_FREQ_NAME.ToString()))                            
                    && (string.IsNullOrEmpty(this.tbxBeginDT.Text) || (x.e1 == null || x.e1.JOB_FLOW_START_DT == null ? false : x.e1.JOB_FLOW_START_DT.Value.CompareTo(DateTime.Parse(this.tbxBeginDT.Text)) >= 0))
                    && (string.IsNullOrEmpty(this.tbxEndDT.Text) || (x.e1 == null || x.e1.JOB_FLOW_END_DT == null ? false : x.e1.JOB_FLOW_END_DT.Value.CompareTo(DateTime.Parse(this.tbxEndDT.Text)) <= 0))); // datasource


            Control control = lblTitle_D.NamingContainer;

            foreach (char freqType in runFreqs)
            {
                GridView view = control.FindControl("GridView_Type_" + freqType) as GridView;

                bool isTheView = false;
                string sortExpression = "";
                string sortDirection = "";

                if (!string.IsNullOrEmpty(TheSort))                
                {
                    string[] t = TheSort.Split("&".ToCharArray());
                    isTheView = view.ID.Equals(t[0]);
                    sortExpression = t[1];
                    sortDirection = t[2];
                }
                IEnumerable<ETLJFW_JFQProxy> v = null;
                if(!isTheView)    
                {
                    v = from _v in st
                            where _v.e2 != null && freqType.Equals(_v.e2.RUN_FREQ.HasValue ? _v.e2.RUN_FREQ : null)
                            orderby _v.e1.JOB_FLOW_NAME
                            select ETLJFW_JFQProxy.proxy(_v.e1, _v.e2);
                }
                else
                {   
                    v = (from _v in st
                            where _v.e2 != null && freqType.Equals(_v.e2.RUN_FREQ.HasValue ? _v.e2.RUN_FREQ : null)                            
                            select ETLJFW_JFQProxy.proxy(_v.e1, _v.e2));
                    if (SortDirection.Ascending.ToString().Equals(sortDirection))
                    {
                        if ("JOB_FLOW_NAME".Equals(sortExpression))
                        {
                            v = v.OrderBy(x => x.JOB_FLOW_NAME);
                        }
                        else if ("JOB_FLOW_STATUS".Equals(sortExpression))
                        {
                            v = v.OrderBy(x => x.JOB_FLOW_STATUS);
                        }
                        else if ("JOB_FLOW_START_DT".Equals(sortExpression))
                        {
                            v = v.OrderBy(x => x.JOB_FLOW_START_DT);
                        }
                        else if ("JOB_FLOW_END_DT".Equals(sortExpression))
                        {
                            v = v.OrderBy(x => x.JOB_FLOW_END_DT);
                        }
                            
                        else if ("RUN_START_TIM".Equals(sortExpression))
                        {
                            v = v.OrderBy(x => x.RUN_START_TIM);
                        }
                        else if ("RUN_END_TIM".Equals(sortExpression))
                        {
                            v = v.OrderBy(x => x.RUN_END_TIM);
                        }
                        else if ("Duration".Equals(sortExpression))
                        {
                            v = v.OrderBy(x => CalcUtilities.EvalDuring(x.RUN_START_TIM, x.RUN_END_TIM));
                        }
                        else if ("EXE_TIME".Equals(sortExpression))
                        {
                            v = v.OrderBy(x => x.EXE_TIME);
                        }
                    }
                    else
                    {
                        if ("JOB_FLOW_NAME".Equals(sortExpression))
                        {
                            v = v.OrderByDescending(x => x.JOB_FLOW_NAME);
                        }
                        else if ("JOB_FLOW_STATUS".Equals(sortExpression))
                        {
                            v = v.OrderByDescending(x => x.JOB_FLOW_STATUS);
                        }
                        else if ("JOB_FLOW_START_DT".Equals(sortExpression))
                        {
                            v = v.OrderByDescending(x => x.JOB_FLOW_START_DT);
                        }
                        else if ("JOB_FLOW_END_DT".Equals(sortExpression))
                        {
                            v = v.OrderByDescending(x => x.JOB_FLOW_END_DT);
                        }
                        else if ("RUN_START_TIM".Equals(sortExpression))
                        {
                            v = v.OrderByDescending(x => x.RUN_START_TIM);
                        }
                        else if ("RUN_END_TIM".Equals(sortExpression))
                        {
                            v = v.OrderByDescending(x => x.RUN_END_TIM);
                        }
                        else if ("Duration".Equals(sortExpression))
                        {
                            v = v.OrderByDescending(x => CalcUtilities.EvalDuring(x.RUN_START_TIM, x.RUN_END_TIM));
                        }
                        else if ("EXE_TIME".Equals(sortExpression))
                        {
                            v = v.OrderByDescending(x => x.EXE_TIME);
                        }
                    }
                }
                if (view == null)
                {
                    logger.Warn("Can't found GridView name - " + "GridView_Type_" + freqType);
                }
                else
                {
                    view.DataSource = v;
                    view.DataBind();
                }
            }

            //var other = from _v in st
            //            where _v.e2 == null || (!runFreqs.Contains(_v.e2.RUN_FREQ.Value))
            //            orderby _v.e1
            //            .JOB_FLOW_NAME
            //            select _v.e1;
            //GridView_Type_Others.DataSource = other;
            //GridView_Type_Others.DataBind();  
            ddlFreqHandler();
        }
        protected void btnReflash_Click(object sender, EventArgs args)
        {
            GridView_DataBind();
        }

        protected void btnSubmit_Click(object sender, EventArgs args)
        {
            //string commandName = this.hdnCommandName.Value;
            //string commandArgument = this.hdnCommandArgument.Value;
        }

        protected void btnExecutionSubmit_Click(object sender, EventArgs args)
        {
            if (IsReFlesh)
            {
                switch (hdnCommandName.Value)
                {
                    case "":
                        GridView_DataBind();
                        break;
                    default:
                        hdnCommandArgument.Value = Request.Form["sel_job_flow"]; // reset argument to job flow id for select option rebind data.
                        break;
                }                
                return;
            }
            RunJobBean entity = new JavaScriptSerializer().Deserialize<RunJobBean>(hdnCommandArgument.Value);

            switch (hdnCommandName.Value)
            {
                case "":
                    break;
                case "0":                    
                    break;
                case "1":                    
                    break;
                default:
//                    setMessage(false, "Unknow command name: " + hdnCommandName.Value);
                    Response.Redirect("Dashboard.aspx");
                    break;
            }
            if (entity != null)
            {
                ISignatureBo bo = JsonSvcBoFactory.Instance.CreateSignatureBo(JsonSvcConst.RunJob);
                bo.UserName = this.UserName;
                ResultBean bean = setMessage(((ITypeBo<RunJobBean>)bo).Execute(entity));
                if (hdnCommandName.Value == string.Empty)
                {
                    GridView_DataBind(); 
                }
                RegistSessionKeyUpdate();
            }
            if (Request.Form["sel_job_flow"] != null)
            {
                hdnCommandArgument.Value = Request.Form["sel_job_flow"]; // reset argument to job flow id for select option rebind data.
            }
        }

        protected void btnCancelSubmit_Click(object sender, EventArgs args)
        {
            if (IsReFlesh)
            {
                switch (hdnCommandName.Value) { 
                    case "":
                    case "0":
                        GridView_DataBind();
                        break;
                    default:
                        hdnCommandArgument.Value = Request.Form["sel_job_flow"]; // reset argument to job flow id for select option rebind data.
                        break;
                }
                
                return;
            }
            JobDefineBean entity = null;
            int ap_id = Int32.Parse(hdnCommandArgument.Value);
            
            switch (hdnCommandName.Value)
            {
                case "":
                case "0":
                    entity = new JobDefineBean()
                    {
                        PRJ_ID = this.Project_Id,
                        JOB_FLOW_ID = ap_id
                    };
                    break;
                case "1":
                    entity = new JobDefineBean()
                    {
                        PRJ_ID = this.Project_Id,
                        AP_ID = ap_id
                    };
                    hdnCommandArgument.Value = Request.Form["sel_job_flow"]; // reset argument to job flow id for select option rebind data.
                    break;
                default:
//                    setMessage(false, "Unknow command name: " + hdnCommandName.Value);
                    Response.Redirect("Dashboard.aspx");
                    break;
            }
            if (entity != null)
            {
                ISignatureBo bo = JsonSvcBoFactory.Instance.CreateSignatureBo(JsonSvcConst.CancelJob);
                bo.UserName = this.UserName;
                ResultBean bean = setMessage(((ITypeBo<JobDefineBean>)bo).Execute(entity));
                if (hdnCommandName.Value == string.Empty)
                {
                    GridView_DataBind();
                }
                RegistSessionKeyUpdate();
            }
        }

        protected void GridView_Type_Sorting(object sender, GridViewSortEventArgs e)
        {
            GridView view = sender as GridView;
            if (string.IsNullOrEmpty(TheSort))
            {
                TheSort = view.ID + "&" + e.SortExpression + "&" + e.SortDirection;
            }
            else
            {
                string[] theSort = TheSort.Split("&".ToCharArray());
                if (view.ID.Equals(theSort[0]))
                {
                    if (e.SortExpression.Equals(theSort[1]))
                    {
                        if (SortDirection.Ascending.ToString().Equals(theSort[2]))
                        {
                            TheSort = view.ID + "&" + e.SortExpression + "&" + SortDirection.Descending;
                        }
                        else
                        {
                            TheSort = view.ID + "&" + e.SortExpression + "&" + SortDirection.Ascending;
                        }
                    }
                    else
                    {
                        TheSort = view.ID + "&" + e.SortExpression + "&" + e.SortDirection;
                    }
                }
                else
                {
                    TheSort = view.ID + "&" + e.SortExpression + "&" + e.SortDirection;
                }
            }
            GridView_DataBind();            
        }

        protected void ddlJobFlowType_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridView_DataBind();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlFreq_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.ddlFreqName.Items.Clear();
            this.ddlFreqName.Items.Add(new ListItem("全部", "All"));

            this.ddlFreqName.DataSource = new FrequencyDAO().selectNames(Project_Id, this.ddlFreq.SelectedIndex == 0 ? null : this.ddlFreq.SelectedValue);
            this.ddlFreqName.DataTextField = "Text";
            this.ddlFreqName.DataValueField = "Value";           
            this.ddlFreqName.DataBind();

            GridView_DataBind();            
        }

        private void ddlFreqHandler()
        {
            Control control = lblTitle_D.NamingContainer;
            if (ddlFreq.SelectedIndex == 0)
            {
                foreach (char freqType in runFreqs)
                {
                    GridView view = control.FindControl("GridView_Type_" + freqType) as GridView;
                    view.Visible = true;
                }
            }
            else
            {
                foreach (char freqType in runFreqs)
                {
                    GridView view = control.FindControl("GridView_Type_" + freqType) as GridView;
                    view.Visible = freqType.ToString().Equals(ddlFreq.SelectedValue);
                }
            }
        }

        protected void ddlFreqName_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridView_DataBind();    
        }
        
        protected void cbStatus_CheckedChanged(object sender, EventArgs e)
        {
            GridView_DataBind();          
        }

        protected void btnSelectAll_Click(object sender, EventArgs e)
        {

            cbStatusS.Checked = true;
            cbStatusF.Checked = true;
            cbStatusP.Checked = true;
            cbStatusC.Checked = true;
            cbStatusW.Checked = true;
            cbStatusX.Checked = true;

            GridView_DataBind();          

        }

        protected void btnCancelAll_Click(object sender, EventArgs e)
        {

            cbStatusS.Checked = false;
            cbStatusF.Checked = false;
            cbStatusP.Checked = false;
            cbStatusC.Checked = false;
            cbStatusW.Checked = false;
            cbStatusX.Checked = false;

            GridView_DataBind();          

        }

    }

    
}
