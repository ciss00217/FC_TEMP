﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.util;
using gbs.bao.etl.bo;
using gbs.bao.etl.entity;
using gbs.bao.etl.dao;

namespace ETLAdm.setting
{
    public partial class FctSetting : EtlAdmPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ObjectDataSource3.SelectParameters["prjId"].DefaultValue = this.Project_Id.ToString();
                bindDdlSrcCode();                
                addFct_Click(sender, e);
            }
        }

        //SrcCode下拉選單
        protected void bindDdlSrcCode()
        {
            this.ddlSrcCode.Items.Clear();
            this.ddlSrcCode.Items.Add(new ListItem("全部", "All"));

            this.ddlSrcCode.DataSource = new FctDAO().selectDistinctSrcCode(Project_Id);
            //this.ddlSrcCode.DataTextField = "Text";
            //this.ddlSrcCode.DataValueField = "Value";
            this.ddlSrcCode.DataBind();
        }

        protected void addFct_Click(object sender, EventArgs e)
        {
            Panel1.Visible = true;            
            DetailsView1.ChangeMode(DetailsViewMode.Insert);
            isBindDetailViewInsertMode = true;
            this.hdnFileName.Value = "";
        }


        
        protected void btnModify_Click(object sender, EventArgs e)
        {
            //Button btn = (Button)sender;
            Panel1.Visible = true;
            DetailsView1.ChangeMode(DetailsViewMode.Edit);
            ObjectDataSource2.SelectParameters["prjId"].DefaultValue = this.Project_Id.ToString();
            ObjectDataSource2.SelectParameters["fileName"].DefaultValue = this.hdnFileName.Value.Replace("FILE_NAME|", ""); ;
            ObjectDataSource2.SelectParameters["srcCode"].DefaultValue = this.ddlSrcCode.SelectedValue;
            DetailsView1.DataBind();
            
            
        }

        protected void btnCopy_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            Panel1.Visible = true;
            DetailsView1.ChangeMode(DetailsViewMode.Insert);
            isBindDetailViewInsertMode = true;
            fileName = this.hdnFileName.Value.Replace("FILE_NAME|", "");
            newFileName = fileName + "(Copy)";
            isCopyMode = true;
        }

        bool isBindDetailViewInsertMode = true;
        bool isCopyMode = false;
        bool isJustCreate = false;
        string fileName;
        string newFileName;

        private void bindDetailViewInsertMode(string newFileName, ETLFCT fct)
        {
            if (!(DetailsView1.FindControl("FileName") is Label))
            {
                TextBox FileName = (TextBox)DetailsView1.FindControl("FileName");
                FileName.Text = isCopyMode ? fct.FILE_NAME + "(Copy)" : fct.FILE_NAME;//newFileName;
                TextBox SrcCode = (TextBox)DetailsView1.FindControl("SrcCode");
                SrcCode.Text = fct.SRC_CODE;
                TextBox StageName = (TextBox)DetailsView1.FindControl("StageName");
                StageName.Text = fct.STAGE_NAME;
                TextBox OdsName = (TextBox)DetailsView1.FindControl("OdsName");
                OdsName.Text = fct.ODS_NAME;
                TextBox FileDesc = (TextBox)DetailsView1.FindControl("FileDesc");
                FileDesc.Text = fct.FILE_DESC;
                DropDownList FileFreq = (DropDownList)DetailsView1.FindControl("FileFreq");
                FileFreq.SelectedValue = "" + fct.FILE_FREQ;
                TextBox TrgRate = (TextBox)DetailsView1.FindControl("TrgRate");
                TrgRate.Text = fct.TRG_RATE == null ? "100.00" : fct.TRG_RATE.ToString();
            }
        }

        protected void btnRemove_Click(object sender, EventArgs e)
        {
            string currentDdlSrcCode = this.ddlSrcCode.SelectedValue;
            ResultBean result = null;
            //Button btn = (Button) sender;
            
            FctBO fctBO = new FctBO() { UserName = this.UserName };
            result = setMessage(fctBO.remove(new ETLFCT() { PRJ_ID = Project_Id, 
                FILE_NAME = this.hdnFileName.Value.Replace("FILE_NAME|", ""), 
                SRC_CODE=currentDdlSrcCode}));

            if (result.success)
            {

                addFct_Click(sender, e);
                bindDdlSrcCode();
                if (this.ddlSrcCode.Items.FindByValue(currentDdlSrcCode)!=null)
                    this.ddlSrcCode.SelectedValue = currentDdlSrcCode;
            }
        }

        protected void btnOk_Click(object sender, EventArgs e)
        {
            isJustCreate = true;
            Button btn = (Button)sender;
            ResultBean result = null;

            string currentDdlSrcCode = this.ddlSrcCode.SelectedValue;

            TextBox FileNameTextBox = (ControlUtil.FindInTemplate(btn, "FileName") as TextBox);
            string FileName = FileNameTextBox == null ? (ControlUtil.FindInTemplate(btn, "FileName") as Label).Text : FileNameTextBox.Text;
            string SrcCode = (ControlUtil.FindInTemplate(btn, "SrcCode") as TextBox).Text;
            string StageName = (ControlUtil.FindInTemplate(btn, "StageName") as TextBox).Text;
            string OdsName = (ControlUtil.FindInTemplate(btn, "OdsName") as TextBox).Text;
            string FileDesc = (ControlUtil.FindInTemplate(btn, "FileDesc") as TextBox).Text;
            string FileFreqT = (ControlUtil.FindInTemplate(btn, "FileFreq") as DropDownList).SelectedValue;
            string TrgRateT = (ControlUtil.FindInTemplate(btn, "TrgRate") as TextBox).Text;

            ETLFCT fct = new ETLFCT()
                {
                    PRJ_ID = this.Project_Id,
                    FILE_NAME = FileName,
                    SRC_CODE = SrcCode,
                    STAGE_NAME = StageName,
                    ODS_NAME = OdsName,
                    FILE_DESC = FileDesc,
                };

            if (string.IsNullOrEmpty(FileFreqT))
            {
                fct.FILE_FREQ = null;
            }
            else
            {
                fct.FILE_FREQ = FileFreqT.ToCharArray()[0];
            }

            if (string.IsNullOrEmpty(TrgRateT))
            {
                fct.TRG_RATE = null;
            }
            else
            {
                decimal TrgRate = -1;
                if (decimal.TryParse(TrgRateT, out TrgRate))
                {
                    fct.TRG_RATE = TrgRate;
                }
                else
                {
                    fct.TRG_RATE = null;
                }
            }

            FctBO fctBO = new FctBO() { UserName = this.UserName };
            if (Const.CMD_Add.Equals(btn.CommandName))
            {
                fct.FILE_NAME = fct.FILE_NAME.Trim();
                fct.SRC_CODE = fct.SRC_CODE.Trim();
                result = setMessage(fctBO.add(fct));
                if (result.success)
                {
                    Panel1.Visible = false;
                }
            }
            else if (Const.CMD_Replace.Equals(btn.CommandName))
            {
                result = setMessage(fctBO.replace(fct));
            }
            if (result.success)
            {
                GridView1.DataBind();
            }
            this.hdnFileName.Value = "FILE_NAME|" + fct.FILE_NAME;
            bindDdlSrcCode();
            this.ddlSrcCode.SelectedValue = currentDdlSrcCode;
            lnkFCT_Click(sender, e); 
        }

        protected void btnDispose_Click(object sender, EventArgs e)
        {
            //Panel1.Visible = false;
            isBindDetailViewInsertMode = false;
            lnkFCT_Click(sender, e);
            
        }

        protected void FileFreqCondition_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridView1.DataBind();
        }

        protected void DetailsView1_PreRender(object sender, EventArgs e)
        {
            try
            {
                if (isBindDetailViewInsertMode)
                {
                    FctBO bo = new FctBO();

                    ETLFCT fct = null;
                    if (fileName != null && this.ddlSrcCode.SelectedValue != null)
                    {
                        fct = bo.get(this.Project_Id, fileName, this.ddlSrcCode.SelectedValue);
                    }
                    if (fct == null)
                        fct = new ETLFCT();
                    this.bindDetailViewInsertMode(newFileName, fct);
                }
            }
            catch(InvalidOperationException ex)
            {
                isJustCreate = false;
                setMessage(false, ex.Message);
            }
            catch (NullReferenceException)
            {
                isJustCreate = false;
            }
        }

        public void ObjectDataSource_OnSelected(object sender, ObjectDataSourceStatusEventArgs e)
        {
            if (e.Exception != null)
            {
                if (!(e.Exception.InnerException is InvalidOperationException)) return;

                e.ExceptionHandled = true;
            }
        }

        protected void lnkFCT_Click(object sender, EventArgs e)
        {
            //TreeView1_SelectedNodeChanged(null, null);

            //Button btn = (Button)sender;

            try
            {
                if (!isJustCreate)
                {
                    FctBO bo = new FctBO();
                    bo.get(this.Project_Id, this.hdnFileName.Value.Replace("FILE_NAME|", ""), this.ddlSrcCode.SelectedValue);
                }
                Panel1.Visible = true;
                DetailsView1.ChangeMode(DetailsViewMode.Edit);
                ObjectDataSource2.SelectParameters["prjId"].DefaultValue = this.Project_Id.ToString();
                ObjectDataSource2.SelectParameters["fileName"].DefaultValue = this.hdnFileName.Value.Replace("FILE_NAME|", "");
                ObjectDataSource2.SelectParameters["srcCode"].DefaultValue = this.ddlSrcCode.SelectedValue;

                DetailsView1.DataBind();
            }
            catch (InvalidOperationException ex)
            {
                isJustCreate = false;
                setMessage(false, ex.Message);
            }
        }
    }
}