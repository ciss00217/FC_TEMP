﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.util;
using gbs.bao.etl.entity;
using gbs.bao.etl.bo;
using gbs.bao.etl.Properties;

namespace ETLAdm.setting
{
    public partial class JobFlowSetting : EtlAdmPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DeployPanel.Visible = Settings.Default.JobFlowDeployEnable;
            }
        }
    }
}
