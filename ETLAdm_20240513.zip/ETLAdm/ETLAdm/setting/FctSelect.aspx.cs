﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.util;
using gbs.bao.etl.dao;
using gbs.bao.etl.entity.proxy;
using gbs.bao.etl.bo;
using gbs.bao.etl.entity;
using System.Xml;

namespace ETLAdm.setting
{
    public partial class FctSelect : EtlAdmPage
    {
        private string _TheSort;

        public string TheSort
        {
            get
            {
                _TheSort = ViewState["TheSort"] as string;
                return _TheSort;
            }
            set
            {
                _TheSort = value;
                ViewState["TheSort"] = _TheSort;
            }
        }
        private string defaultFileName { get; set; }

        protected override void Page_Init(object sender, EventArgs e)
        {
            base.Page_Init(sender, e);
            ((SiteMaster)Page.Master).HideTop1 = true;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            defaultFileName = "";
            if (!IsPostBack)
            {
                defaultFileName = Request.QueryString["FILE_NAME"];
                TheSort = this.GridView1.ID + "&" + "FILE_NAME" + "&" + SortDirection.Ascending.ToString();
                GridView_DataBind();

                srcCode.DataSource = new FctDAO().selectDistinctSrcCode(this.Project_Id);
                srcCode.DataBind();
            }
        }
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            GridView_DataBind();
        }
        protected void btnExport_Click(object sender, EventArgs e)
        {
            List<string> values = new List<string>();
            foreach (var key in Request.Form.AllKeys.Where(x => x.EndsWith("$checkFctName")).Select(x => x))
            {
                values.Add(Request.Form[key]);
            }
            if (values.Count == 0)
            {
                setMessage(false, "請勾選控制檔");
            }
            else
            {
                DeployBO bo = new DeployBO();
                ResultBean result = bo.ExportFct(this.Project_Id, values.ToArray());
                Response.Clear();
                Response.ContentType = "text/xml";
                string filename = "ETLFCT_Deploy" + DateTime.Now.ToString("yyyyMMddHHmm") ;
                Response.AddHeader("content-disposition", "attachment; filename=\"" + filename + ".xml\"");
                Response.Write(result.data.ToString());
                Response.Flush();
                Response.End();
            }
        }
        protected void GridView_DataBind()
        {
            FctDAO dao = new FctDAO();

            string inName = fctName.Text.Trim();
            List<string> insrcCode = srcCode.Items.Cast<ListItem>()
                                            .Where(li => li.Selected)
                                            .Select(li => li.Value)
                                            .ToList();
            List<char> infileFreqs = fileFreqs.Items.Cast<ListItem>()
                .Where(li => li.Selected)
                .Select(li => li.Value[0])
                .ToList();

            var v = dao.selectSome(this.Project_Id, inName, insrcCode, infileFreqs)
                .Where(x=>string.IsNullOrEmpty(defaultFileName)|| x.FILE_NAME.Equals(defaultFileName))
                .Select(_v => _v);
            
            string sortExpression = "";
            string sortDirection = "";

            if (!string.IsNullOrEmpty(TheSort))
            {
                string[] t = TheSort.Split("&".ToCharArray());
                sortExpression = t[1];
                sortDirection = t[2];
            }

            if (SortDirection.Ascending.ToString().Equals(sortDirection))
            {
                if ("FILE_NAME".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.FILE_NAME);
                }
                else if ("SRC_CODE".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.SRC_CODE);
                }
                else if ("FILE_FREQ".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.FILE_FREQ);
                }                
            }
            else
            {
                if ("FILE_NAME".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.FILE_NAME);
                }
                else if ("SRC_CODE".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.SRC_CODE);
                }
                else if ("FILE_FREQ".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.FILE_FREQ);
                } 
            }
            
            GridView1.DataSource = v;
            GridView1.Visible = true;
            GridView1.DataBind();
        }

        protected void GridView_Type_Sorting(object sender, GridViewSortEventArgs e)
        {
            GridView view = sender as GridView;
            if (string.IsNullOrEmpty(TheSort))
            {
                TheSort = view.ID + "&" + e.SortExpression + "&" + e.SortDirection;
            }
            else
            {
                string[] theSort = TheSort.Split("&".ToCharArray());
                if (view.ID.Equals(theSort[0]))
                {
                    if (e.SortExpression.Equals(theSort[1]))
                    {
                        if (SortDirection.Ascending.ToString().Equals(theSort[2]))
                        {
                            TheSort = view.ID + "&" + e.SortExpression + "&" + SortDirection.Descending;
                        }
                        else
                        {
                            TheSort = view.ID + "&" + e.SortExpression + "&" + SortDirection.Ascending;
                        }
                    }
                    else
                    {
                        TheSort = view.ID + "&" + e.SortExpression + "&" + e.SortDirection;
                    }
                }
                else
                {
                    TheSort = view.ID + "&" + e.SortExpression + "&" + e.SortDirection;
                }
            }
            GridView_DataBind();
        }
    }
}