﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.util;
using gbs.bao.etl.dao;
using gbs.bao.etl.entity.proxy;
using gbs.bao.etl.bo;
using gbs.bao.etl.entity;
using System.Xml;

namespace ETLAdm.setting
{
    public partial class JobFlowSelect : EtlAdmPage
    {
        private string _TheSort;

        public string TheSort
        {
            get
            {
                _TheSort = ViewState["TheSort"] as string;
                return _TheSort;
            }
            set
            {
                _TheSort = value;
                ViewState["TheSort"] = _TheSort;
            }
        }
        private int defaultFlowId { get; set; }

        protected override void Page_Init(object sender, EventArgs e)
        {
            base.Page_Init(sender, e);
            ((SiteMaster)Page.Master).HideTop1 = true;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            defaultFlowId = -1;
            if (!IsPostBack)
            {
                int d = -1;
                if (int.TryParse(Request.QueryString["JOB_FLOW_ID"], out d))
                {
                    defaultFlowId = d;
                }
                TheSort = this.GridView1.ID + "&" + "RUN_FREQ" + "&" + SortDirection.Ascending.ToString();
                GridView_DataBind();

                jobFlowType.DataSource = new JobFlowDAO().selectDistinctTypes(this.Project_Id);
                jobFlowType.DataBind();
            }
        }
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            GridView_DataBind();
        }
        protected void btnExport_Click(object sender, EventArgs e)
        {
            List<string> values = new List<string>();
            foreach (var key in Request.Form.AllKeys.Where(x => x.EndsWith("$checkJobFlowId")).Select(x=>x))
            {
                values.Add(Request.Form[key]);
            }
            if (values.Count == 0)
            {
                setMessage(false, "請勾選Job Flow");
            }
            else
            {
                DeployBO bo = new DeployBO();
                ResultBean result = bo.ExportJobFlow(this.Project_Id, values.Select(x=>int.Parse(x)).ToArray());
                Response.Clear();
                Response.ContentType = "text/xml";
                string filename = "ETLJFW_Deploy" + DateTime.Now.ToString("yyyyMMddHHmm") ;
                Response.AddHeader("content-disposition", "attachment; filename=\"" + filename + ".xml\"");
                Response.Write(result.data.ToString());
                Response.Flush();
                Response.End();
            }
        }
        protected void GridView_DataBind()
        {
            JobFlowDAO dao = new JobFlowDAO();

            string inName = jobFlowName.Text.Trim();
            List<string> inFlowType = jobFlowType.Items.Cast<ListItem>()
                                            .Where(li => li.Selected)
                                            .Select(li => li.Value)
                                            .ToList();

            List<string> inRunFreq = runFreqTypes.Items.Cast<ListItem>()
                                            .Where(li => li.Selected)
                                            .Select(li => li.Value)
                                            .ToList();

            var v = dao.selectSome(this.Project_Id, inName, inFlowType, inRunFreq)
                .Where(x=>defaultFlowId == -1 || x.e1.JOB_FLOW_ID==defaultFlowId)
                .Select(_v => ETLJFW_JFQProxy.proxy(_v.e1, _v.e2));
            
            string sortExpression = "";
            string sortDirection = "";

            if (!string.IsNullOrEmpty(TheSort))
            {
                string[] t = TheSort.Split("&".ToCharArray());
                sortExpression = t[1];
                sortDirection = t[2];
            }

            if (SortDirection.Ascending.ToString().Equals(sortDirection))
            {
                if ("JOB_FLOW_NAME".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.JOB_FLOW_NAME);
                }                
                else if ("JOB_FLOW_START_DT".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.JOB_FLOW_START_DT);
                }
                else if ("JOB_FLOW_END_DT".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.JOB_FLOW_END_DT);
                }
                else if ("RUN_START_TIM".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.RUN_START_TIM);
                }
                else if ("RUN_END_TIM".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.RUN_END_TIM);
                }
                else if ("RUN_FREQ".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.RUN_FREQ);
                }
            }
            else
            {
                if ("JOB_FLOW_NAME".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.JOB_FLOW_NAME);
                }                
                else if ("JOB_FLOW_START_DT".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.JOB_FLOW_START_DT);
                }
                else if ("JOB_FLOW_END_DT".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.JOB_FLOW_END_DT);
                }
                else if ("RUN_START_TIM".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.RUN_START_TIM);
                }
                else if ("RUN_END_TIM".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.RUN_END_TIM);
                }                
                else if ("RUN_FREQ".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.RUN_FREQ);
                }
            }
            
            GridView1.DataSource = v;
            GridView1.Visible = true;
            GridView1.DataBind();
        }

        protected void GridView_Type_Sorting(object sender, GridViewSortEventArgs e)
        {
            GridView view = sender as GridView;
            if (string.IsNullOrEmpty(TheSort))
            {
                TheSort = view.ID + "&" + e.SortExpression + "&" + e.SortDirection;
            }
            else
            {
                string[] theSort = TheSort.Split("&".ToCharArray());
                if (view.ID.Equals(theSort[0]))
                {
                    if (e.SortExpression.Equals(theSort[1]))
                    {
                        if (SortDirection.Ascending.ToString().Equals(theSort[2]))
                        {
                            TheSort = view.ID + "&" + e.SortExpression + "&" + SortDirection.Descending;
                        }
                        else
                        {
                            TheSort = view.ID + "&" + e.SortExpression + "&" + SortDirection.Ascending;
                        }
                    }
                    else
                    {
                        TheSort = view.ID + "&" + e.SortExpression + "&" + e.SortDirection;
                    }
                }
                else
                {
                    TheSort = view.ID + "&" + e.SortExpression + "&" + e.SortDirection;
                }
            }
            GridView_DataBind();
        }
    }
}