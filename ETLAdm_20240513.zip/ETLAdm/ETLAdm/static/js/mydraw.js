﻿function DrawIt_Job(response, args) {
    block();
    if (!args) {
        args = {'':''};
    }
    var monitor = /monitor/.test(window.location.href);
    var pre_level = 0;
    var pre_HasOtherFlowParent = false;
    var OtherFlowCount = 0;
    var interval_x = 120;
    var interval_y = 100;
    var adjust = 40;
    var boxWidth = 200;
    for (var i = 0, j = 0; i < response.data.JobsInFlow.length; i++, j++) { // draw job
        var JobsInFlow = response.data.JobsInFlow[i];
        var level = JobsInFlow.ORDER_KEY_X;        
        if (JobsInFlow.parent.length == 0) {
            paper_x = initial_x;
        } else if (pre_level != level) {
            paper_x += (boxWidth + interval_x);
            paper_y = initial_y + (adjust * level);
            j = 0;            
        } else {
            if (level == 1 && OtherFlowCount > 0) {
                if (pre_HasOtherFlowParent && !JobsInFlow.HAS_OTHERFLOW_PARENT) {
                    var bottom_y = (OtherFlowCount * interval_y) ;
                    paper_y = paper_y < bottom_y ? bottom_y : paper_y;
                }
            }
        }

        var r = 0;
        var width = undefined;
        var height = undefined;
        var flow_id;
        var isOtherFlow = response.data.JOB_FLOW_ID != JobsInFlow.JOB_FLOW_ID;
        if (isOtherFlow) {
            r = 14;
            flow_id = JobsInFlow.JOB_FLOW_ID;
            OtherFlowCount++;
        } else {
            flow_id = response.data.JOB_FLOW_ID;
        }

        var rectText = $().paper.addStep(
            paper,
            htmlDecode(JobsInFlow.JOB_NAME) + '\n' + (JobsInFlow.JOB_END_DT == '' ? '' : ('(' + JobsInFlow.JOB_END_DT + ')') ),
            paper_x,
            paper_y,
            width,
            height, 
            r);
        var $id = JobsInFlow.id;
        rectText.flow_id = flow_id;
        rectText.isOtherFlow = isOtherFlow;
        rectText.id($id);
        rectText.data.start_dt = JobsInFlow.JOB_START_DT;
        rectText.data.end_dt = JobsInFlow.JOB_END_DT;
        var status = JobsInFlow.JOB_STATUS;
        rectText.status = status;
        rectText.attr.level = level;
        if (monitor) {
            var fill = statusHandler.color(status);
            rectText.rect.attr({ "fill": fill, "fill-opacity": 1 });
            dialogFuncions.switchFunc = dialogFuncions.drawJSDFunc; //override            
        } else {
            rectText.statusChanged(JobsInFlow.JOB_STATUS);
        }
         
        rectText.click(rectText, dialogFuncions);

        paper_y += interval_y;

        pre_level = level;
        pre_HasOtherFlowParent = JobsInFlow.HAS_OTHERFLOW_PARENT;
    }

    for (var i = 0; i < response.data.JobsInFlow.length; i++) { // draw connection
        var JobsInFlow = response.data.JobsInFlow[i];
        var firstRectText = paper.find(JobsInFlow.id);
        var x;
        for (var j = 0; j < JobsInFlow.child.length; j++) {
            var child = JobsInFlow.child[j];
            var src = paper.find(child.id);
            var conn = paper.connection(firstRectText, src);
            firstRectText.child.push(src);
            src.parent.push(firstRectText);

            if (!monitor) {
                conn.line.click(function() {
                    if (CurrentCommandMode == CommandMode_RemoveJob) {
                        var _conn = connections.lookup(this);
                        if (confirm("確定刪除此連結[" + _conn.from.data.jobName.name.fulltrim() + "] -> [" + _conn.to.data.jobName.name.fulltrim() + "] ?")) {                            
                            connections.remove(_conn);
                        }
                    }
                });
            }
            connections.push(conn);
        }
    }
    unblock();
}
