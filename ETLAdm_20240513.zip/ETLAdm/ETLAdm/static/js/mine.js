﻿function block() {
    $.blockUI({
        overlayCSS: { backgroundColor: '#446DB2' },
        message: 'Please wait ...',
        css: {
            border: 'none',
            padding: '15px',
            backgroundColor: 'rgb(7,25,67)',
            '-webkit-border-radius': '10px',
            '-moz-border-radius': '10px',
            opacity: .5,
            color: '#fff'
        }
    });
}

function unblock() {
    setTimeout($.unblockUI, 500);  
}

function htmlEncode(value) {
    return $('<div/>').text(value).html();
}

function htmlDecode(value) {
    return $('<div/>').html(value).text();
}

function getSeqById(id){
	var pos = id.lastIndexOf("_") + 1;
	return parseInt(id.substring(pos));	
}

function menusToggleClass(list, target){
	var hasChange = false;
	var $list = (list.children == undefined) ? $(list) : list;
	var $target = (target.id == undefined ? $(target) : target );
	
	$list.children().each(function(){
		$thisEl = $(this);		
		if($thisEl.attr('id')==$target.attr('id')){
			if(!$thisEl.hasClass('highlight')){
				$thisEl.toggleClass('highlight');
				hasChange = true;
			}
		}else{
			if($thisEl.hasClass('highlight')){
				$thisEl.toggleClass('highlight');
				hasChange = true;
			}
		}
	});			
	return hasChange;
}

function elementFromEvent(e){
	e = window.event || e; 
	var srcElement = e.srcElement || e.target; 
	return srcElement;
}

function clearText() {
    $('input[type="text"]').each(function() {
        this.value = '';
    });
}
function setMessageBar(str, isadd) {
    if (str != undefined) {
        var bar = $('#messagebarText');
        if (isadd != undefined) {
            str += ("<br />" + bar.html());
        } 
        bar.html(str);
    }
}

var CumulativeOffset = function(obj) {
    var left, top;
    left = top = 0;
    if (obj.offsetParent) {
        do {
            left += obj.offsetLeft;
            top += obj.offsetTop;
        } while (obj = obj.offsetParent);
    }
    return {
        x: left,
        y: top
    };
};

function toggleHighlight($this) {
    if ($this.hasClass('highlight')) {
        $this.toggleClass('highlight');
    } else {
        $this.find('.highlight').toggleClass('highlight');
    }
}


// Array Remove - By John Resig (MIT Licensed)
//Array.prototype.remove = function(from, to) {
//    var rest = this.slice((to || from) + 1 || this.length);
//    this.length = from < 0 ? this.length + from : from;
//    return this.push.apply(this, rest);
//};

Array.prototype.remove = function(obj) {
    for (var i = this.length - 1; i > -1; i--) {
        if (obj == this[i])
            this.splice(i, 1);
    }
};

Array.prototype.clear = function() {
    this.splice(0, this.length);
};


var ajaxHandler = (function ($) {
    var execute = function (url, data, successHandler, failHandler, _block) {

        if (_block)
            block();

        $.ajax({
            type: 'post',
            url: url,
            data: data,
            success: function (response, textStatus, jqXHR) {
                if (response.success) {
                    if (successHandler)
                        successHandler(response);
                    else
                        alert(response.message);
                } else {
                    if ((!response.message) && response.indexOf('LoginBody') > -1) {
                        window.location.href = '/ETLAdm/static/Logout.aspx';
                    } else {
                        if (failHandler)
                            failHandler(response);
                        else
                            alert("異常: " + response.message);
                    }
                }
                if (block)
                    setTimeout($.unblockUI, 500);
            },
            error: function (response, exception) {
                if (response.status == 0) {
                    //undo
                }
                else if (response.status == 500) {
                    alert("系統異常: " + response.responseText);
                } else {
                    alert("系統異常: [" + response.status + "]" + exception);
                }
                if (_block)
                    unblock();
            }
        });
    }
    return {
        execute: execute
    };
})(jQuery);
(function ($) {
    $.tooltip = {
        div: '',
        init: function(){
            if ($('div[id="tooltip"]').length == 0) {
                $.fx.speeds._default = 100;
                $.tooltip.div = ($(document.createElement('a')).appendTo('body')).hide().dialog({ autoOpen: false, dialogClass: 'gradient_backgroud tooltip', resizable: false, height: 20, width: 150, show: "fade" });
                $.tooltip.div.parent().removeClass('ui-widget ui-widget-content ui-draggable');
                $.tooltip.div.prev().remove();
            }
        },
        open: function (str) {
            var x = event == undefined ? 0 : event.clientX;
            var y = event == undefined ? 0 : event.clientY + 10;
            var len = str.length;
            var width = (len + 1) * 8;
            this.div.text(str);
            this.div.dialog('option', 'position', [x, y]).dialog('option', 'width', width).dialog('open');
        },
        close: function () { this.div.dialog('close'); }
    };
})(jQuery);

var statusHandler = (function() {
    var color = function(st) {
        if(st=='X'){
            return '#3d3d3d'; // silver
        }else if (st=='S'){
            return '#43cb43'; // green
        }else if (st=='P'){
            return '#3737ff'; // blue
        }else if (st=='F'){
            return '#ff3737'; // red
        }else if (st=='C' || st=='N'){
            return '#a96639'; // brown
        }else if (st=='W'){
            return '#ffd326'; // yellow
        }
        return 'white';
    }
    return {
        color: color
    };
})();

function JobId(id) {
    var ids = id.split('|');
    return {
        id: id,
        obj: $('#' + id),
        jbd_ap_id: ids[1],
        job_ap_id: ids[2]
    };
}

function JobName(name) {
    var names = name.split(/\./);
    var has_flow = names.length > 1;
    var job_flow_name = has_flow ? names[0] : '';
    var job_name = has_flow ? names[1] : names[0];
    return {
        name : name,
        job_flow_name : job_flow_name,
        job_name : job_name,
        has_flow : has_flow
    };
}


function LimitTextLength(str, len) {
    if (!str) {
        return '';
    }
    var text = str;
    if (str.length > len) {
        text = text.substring(0, len);
    }
    
    var adjust = byteLength(text) - text.length;
    if (adjust > 0) {
        text = text.substring(0, len - (adjust - len) / 2);
    }

    if (str!=text) {
        text += "...";
    }
    return text;
}

function byteLength(str) {
    var escapedStr = encodeURI(str);
    if (escapedStr.indexOf("%") != -1) {
        var count = escapedStr.split("%").length - 1;
        if (count == 0) count++; //perverse case; can't happen with real UTF-8
        var tmp = escapedStr.length - (count * 3);
        count = count + tmp;
    } else {
        count = escapedStr.length;
    }
    return count;
}



(function($) {
    $.fn.clearAll = function(c) {
        var $this = $(this);
        var v = $('input,textarea,select', $this);
        if (c) v = v.filter('[disabled!="true"][readonly!="readonly"]:not(.textbox_disabled)');

        v.filter(function() { return this.type.match(/(text|password)/); }).val('');
        v.filter(':checked').attr('checked', false);
        v.filter('select').children('option:selected').removeAttr('selected');
        v.filter('select').children(':first-child').attr('selected', true);        
    }

})(jQuery);


String.prototype.right = function(n) {
    if (n > this.length) {
        return this;
    } else {
        return this.substring(this.length - n, this.length);
    }
}

String.prototype.fulltrim = function(){
    return this.replace(/(?:(?:^|\n)\s+|\s+(?:$|\n))/g, '').replace(/\s+/g, ' ');
};

function trimNull(obj, val) {
    if (obj == null || obj == "null") {
        return val == null ? "" : val;
    }
    return obj;
}

jQuery.showModalDialog = function (options) {
    var defaultOptns = {
        url: null,
        dialogArguments: null,
        height: 'auto',
        width: 'auto',
        position: 'center',
        resizable: true,
        scrollable: true,
        onClose: function () { },
        returnValue: null
    };

    var fns = {
        close: function () {
            opts.returnValue = $dialog.returnValue;
            $dialog = null;
            opts.onClose();
        },
        adjustWidth: function () { $frame.css("width", "100%"); }
    };

    // build main options before element iteration

    var opts = $.extend({}, defaultOptns, options);

    var $frame = $('<iframe id="iframeDialog" />');

    if (opts.scrollable)
        $frame.css('overflow', 'auto');

    $frame.css({
        'padding': 0,
        'margin': 0,
        'padding-bottom': 10
    });

    var $dialogWindow = $frame.dialog({
        autoOpen: true,
        modal: true,
        width: opts.width,
        height: opts.height,
        resizable: opts.resizable,
        position: opts.position,
        overlay: {
            opacity: 0.5,
            background: "black"
        },
        close: fns.close,
        resizeStop: fns.adjustWidth
    });

    $frame.attr('src', opts.url);
    fns.adjustWidth();

    $frame.load(function () {
        if ($dialogWindow) {
            if ($(this).contents().find("title").length > 0) {
                var maxTitleLength = 50;
                var title = $(this).contents().find("title").html();

                if (title.length > maxTitleLength) {
                    title = title.substring(0, maxTitleLength) + '...';
                }
                $dialogWindow.dialog('option', 'title', title);
            }
        }
    });

    $dialog = new Object();
    $dialog.dialogArguments = opts.dialogArguments;
    $dialog.dialogWindow = $dialogWindow;
    $dialog.returnValue = null;
}