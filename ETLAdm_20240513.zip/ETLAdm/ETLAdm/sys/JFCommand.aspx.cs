﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.entity;
using gbs.bao.etl.bo;
using gbs.bao.etl.util;
using gbs.bao.etl.dao;

namespace ETLAdm.sys
{
    public partial class JFCommand : EtlAdmPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DetailsView1.Visible = false;
                ddlJobFlowType_DataBind();
            }
            else
            {
                
            }
            
        }

        public void TreeView1_SelectedNodeChanged(object sender, EventArgs e)
        {
            DetailsView1.Visible = true;
            ObjectDataSource2.SelectParameters[0].DefaultValue = this.hdnFlowApID.Value.Replace("Flow|","");
            ObjectDataSource3.SelectParameters[0].DefaultValue = this.Project_Id + "";
            DetailsView1.DataBind();
        }

        protected void btnOk_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            int jfwId = Int32.Parse(btn.CommandArgument);
            HiddenField hdnProjectId = ControlUtil.FindInTemplate(btn, "hdnProjectId") as HiddenField;

            TextBox job_flow_start_dt = ControlUtil.FindInTemplate(btn, "job_flow_start_dt") as TextBox;
            TextBox job_flow_end_dt = ControlUtil.FindInTemplate(btn, "job_flow_end_dt") as TextBox;
            TextBox exe_time = ControlUtil.FindInTemplate(btn, "exe_time") as TextBox;
            RadioButtonList job_flow_status = ControlUtil.FindInTemplate(btn, "job_flow_status") as RadioButtonList;
            DropDownList run_freq_id = ControlUtil.FindInTemplate(btn, "run_freq_id") as DropDownList;
            
            DropDownList ddlNtfType = ControlUtil.FindInTemplate(btn, "ddlNtfType") as DropDownList;
            TextBox txtNTF_ID = ControlUtil.FindInTemplate(btn, "txtNTF_ID") as TextBox;
            TextBox tbxNTF_TXT = ControlUtil.FindInTemplate(btn, "NTF_TXT") as TextBox;

            DateTime _job_flow_start_dt;
            bool had_start_dt = DateTime.TryParse(job_flow_start_dt.Text, out _job_flow_start_dt);                
            
            DateTime _job_flow_end_dt;
            bool had_end_dt = DateTime.TryParse(job_flow_end_dt.Text, out _job_flow_end_dt);
            
            char _job_flow_status = job_flow_status.SelectedValue.ToCharArray()[0];
            int _run_freq_id = Int32.Parse(run_freq_id.SelectedValue);

            DateTime? NoDate = null;
            JobFlowBO bo = new JobFlowBO();
            bo.UserName = this.UserName;
            ETLNTF ntf = null;
            if (ddlNtfType.SelectedIndex > 0)
            {
                int seq = new SeqBO().nextIntVal(typeof(ETLNTF));
                ntf = new ETLNTF()
                {
                    PRJ_ID = Convert.ToInt32(hdnProjectId.Value),
                    JOB_FLOW_ID = jfwId,
                    NTF_ID = txtNTF_ID.Text,
                    NTF_TYPE = ddlNtfType.SelectedValue.ToCharArray()[0],
                    NTF_TXT = tbxNTF_TXT.Text,
                    AP_ID = seq,
                    TBL_UPD_TIM= DateTime.Now,
                    TBL_UPDATER = UserName
                };
            }
            
            ResultBean result = this.setMessage(
                bo.replace(
                    jfwId, 
                    had_start_dt ? _job_flow_start_dt : NoDate, 
                    had_end_dt ? _job_flow_end_dt : NoDate, 
                    _job_flow_status, 
                    _run_freq_id,
                    ntf));
        }

        protected void lnkJFW_Click(object sender, EventArgs e)
        {
            TreeView1_SelectedNodeChanged(null, null);
        }

        protected void ddlJobFlowType_DataBind()
        {
            this.ddlJobFlowType.DataSource = new JobFlowDAO().selectDistinctTypes(Project_Id);
            this.ddlJobFlowType.DataBind();
            string jobFlowType = Request.QueryString["JobFlowType"];
            if (!string.IsNullOrEmpty(jobFlowType))
            {
                ListItem item = this.ddlJobFlowType.Items.FindByValue(jobFlowType);
                if (item != null)
                {
                    item.Selected = true;
                }
            }
        }
    }
}
