﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gbs.bao.etl.util;
using gbs.bao.etl.dao;
using gbs.bao.etl.entity.proxy;
using gbs.bao.etl.bo;
using gbs.bao.etl.entity;
using System.Xml;

namespace ETLAdm.sys
{
    public partial class JFCommandBatch : EtlAdmPage
    {
        private string _TheSort;

        public string TheSort
        {
            get
            {
                _TheSort = ViewState["TheSort"] as string;
                return _TheSort;
            }
            set
            {
                _TheSort = value;
                ViewState["TheSort"] = _TheSort;
            }
        }
        private int defaultFlowId { get; set; }

        protected override void Page_Init(object sender, EventArgs e)
        {
            base.Page_Init(sender, e);
            // ((SiteMaster)Page.Master).HideTop1 = true;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            defaultFlowId = -1;
            if (!IsPostBack)
            {
                
                TheSort = this.GridView1.ID + "&" + "RUN_FREQ" + "&" + SortDirection.Ascending.ToString();
                GridView_DataBind();

                jobFlowType.DataSource = new JobFlowDAO().selectDistinctTypes(this.Project_Id);
                jobFlowType.DataBind();
            }
        }
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            GridView_DataBind();
        }
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            List<int> values = new List<int>();
            foreach (var key in Request.Form.AllKeys.Where(x => x.EndsWith("$checkJobFlowId")).Select(x=>x))
            {
                values.Add(Convert.ToInt32(Request.Form[key]));
            }
            if (values.Count == 0)
            {
                setMessage(false, "請勾選Job Flow");
            }
            else
            {                
                ClientScript.RegisterStartupScript(GetType(), "Edit", "<script type='text/javascript'>Edit_Click();</script>");
                Session["FlowIDs"] = values;
                
            }
        }
        protected void GridView_DataBind()
        {
            JobFlowDAO dao = new JobFlowDAO();

            List<int> flowsAP_IDs = new List<int>();
            if (Session["FlowIDs"] != null)
                flowsAP_IDs.AddRange((List<int>)Session["FlowIDs"]);            
            Session.Remove("FlowIDs");


            string inName = jobFlowName.Text.Trim();
            List<string> inFlowType = jobFlowType.Items.Cast<ListItem>()
                                            .Where(li => li.Selected)
                                            .Select(li => li.Value)
                                            .ToList();

            List<string> inRunFreq = runFreqTypes.Items.Cast<ListItem>()
                                            .Where(li => li.Selected)
                                            .Select(li => li.Value)
                                            .ToList();

            var v = dao.selectSomeJoinNTF(this.Project_Id, inName, inFlowType, inRunFreq)
                .Where(x => flowsAP_IDs.Count == 0 || flowsAP_IDs.Contains(x.e1.AP_ID))                
                .Select(_v => ETLJFW_JFQ_NTFProxy.proxy(_v.e1, _v.e2, _v.e3));
                

            
            
            
            string sortExpression = "";
            string sortDirection = "";

            if (!string.IsNullOrEmpty(TheSort))
            {
                string[] t = TheSort.Split("&".ToCharArray());
                sortExpression = t[1];
                sortDirection = t[2];
            }

            if (SortDirection.Ascending.ToString().Equals(sortDirection))
            {
                if ("JOB_FLOW_NAME".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.JOB_FLOW_NAME).ToList();
                }                
                else if ("JOB_FLOW_START_DT".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.JOB_FLOW_START_DT).ToList();
                }
                else if ("JOB_FLOW_END_DT".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.JOB_FLOW_END_DT).ToList();
                }
                else if ("RUN_FREQ_NAME".Equals(sortExpression))
                {
                    v = v.OrderBy(x => x.RUN_FREQ_ID).ToList();
                }
                else if ("JOB_FLOW_STATUS".Equals(sortExpression))
                {
                    v = v.OrderBy(x => ("X".Equals(x.JOB_FLOW_STATUS.ToString())?"X":"V")).ToList();
                }
                else if ("NTF_TYPE".Equals(sortExpression))
                {
                    v = v.OrderBy(x => ("M".Equals(x.NTF_TYPE.ToString()) ? "Mail" : ("S".Equals(x.NTF_TYPE)?"SMS":""))).ToList();
                }else
                {
                    v = v.OrderBy(x => x.JOB_FLOW_NAME).ToList();
                }

            }
            else
            {
                if ("JOB_FLOW_NAME".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.JOB_FLOW_NAME).ToList();
                }                
                else if ("JOB_FLOW_START_DT".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.JOB_FLOW_START_DT).ToList();
                }
                else if ("JOB_FLOW_END_DT".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.JOB_FLOW_END_DT).ToList();
                }
                else if ("RUN_FREQ_NAME".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => x.RUN_FREQ_ID).ToList();
                }
                else if ("JOB_FLOW_STATUS".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => ("X".Equals(x.JOB_FLOW_STATUS.ToString()) ? "X" : "V")).ToList();
                }
                else if ("NTF_TYPE".Equals(sortExpression))
                {
                    v = v.OrderByDescending(x => ("M".Equals(x.NTF_TYPE.ToString()) ? "Mail" : ("S".Equals(x.NTF_TYPE) ? "SMS" : ""))).ToList();
                }
                else
                {
                    v = v.OrderByDescending(x => x.JOB_FLOW_NAME).ToList();
                }
            }
            
            GridView1.DataSource = v;
            GridView1.Visible = true;
            GridView1.DataBind();
        }

        protected void GridView_Type_Sorting(object sender, GridViewSortEventArgs e)
        {
            GridView view = sender as GridView;
            if (string.IsNullOrEmpty(TheSort))
            {
                TheSort = view.ID + "&" + e.SortExpression + "&" + e.SortDirection;
            }
            else
            {
                string[] theSort = TheSort.Split("&".ToCharArray());
                if (view.ID.Equals(theSort[0]))
                {
                    if (e.SortExpression.Equals(theSort[1]))
                    {
                        if (SortDirection.Ascending.ToString().Equals(theSort[2]))
                        {
                            TheSort = view.ID + "&" + e.SortExpression + "&" + SortDirection.Descending;
                        }
                        else
                        {
                            TheSort = view.ID + "&" + e.SortExpression + "&" + SortDirection.Ascending;
                        }
                    }
                    else
                    {
                        TheSort = view.ID + "&" + e.SortExpression + "&" + e.SortDirection;
                    }
                }
                else
                {
                    TheSort = view.ID + "&" + e.SortExpression + "&" + e.SortDirection;
                }
            }
            GridView_DataBind();
        }
    }
}