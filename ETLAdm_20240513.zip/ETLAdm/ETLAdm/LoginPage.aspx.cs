﻿using System;
using System.Web.UI.WebControls;

using NLog;

using gbs.bao.etl.bo;
using gbs.bao.etl.util;
using gbs.bao.etl.entity;
using System.Web.Security;
using System.Web;
using gbs.bao.etl.dao;
using System.Text.RegularExpressions;
using System.Configuration;

namespace ETLAdm
{
    public partial class LoginPage : System.Web.UI.Page
    {
        private Logger logger = LogManager.GetCurrentClassLogger();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (User != null && User.Identity.IsAuthenticated)
            {
                Response.Redirect("~/static/AccessDenied.aspx" + (Request.UrlReferrer == null ? "" : "?UrlReferrer=" + Server.UrlEncode(Request.UrlReferrer.ToString())));
            }
            System.Diagnostics.Debug.WriteLine("TEST BY AIDEN");
            //HttpCookie cookie = Request.Cookies["lastdomain"];
            //TextBox txt_domain = this.FindControl("txt_domain") as TextBox;
            //txt_domain.Text = cookie.Value;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
        {
            System.Web.UI.WebControls.Login login = (System.Web.UI.WebControls.Login) sender;

            string name = (login.FindControl("UserName") as TextBox).Text;
            TextBox Password = login.FindControl("Password") as TextBox;
            string pwd = Password.Text;
            string prjId = (login.FindControl("Project") as DropDownList).SelectedValue;
            string domain = (login.FindControl("txt_domain") as TextBox).Text;
            UserBO bo = new UserBO();
            bo.UserName = name;
            ResultBean bean = bo.login(name, pwd, Convert.ToInt32(prjId), domain);

            e.Authenticated = bean.success;
            if (e.Authenticated)
            {
                Session.Add("User", name);
                AuthenticatedSuccessHandler(login, bean, name);                
            }
            else
            {
                Password.Attributes.Add("value", pwd);
                AuthenticatedFailHandler(login, bean, name, pwd);
            }
        }

        /// <summary>
        /// authenticated success
        /// </summary>
        /// <param name="login"></param>
        /// <param name="bean"></param>
        private void AuthenticatedSuccessHandler(Login login, ResultBean bean, string name)
        {
            DropDownList project = login.FindControl("Project") as DropDownList;

            System.Web.Configuration.AuthenticationSection authSection =
                (System.Web.Configuration.AuthenticationSection)
                ConfigurationManager.GetSection("system.web/authentication");
            System.Web.Configuration.FormsAuthenticationConfiguration
            formsAuthenticationSection = authSection.Forms;
            
            FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(1,
                name,
                DateTime.Now,
                //DateTime.Now.AddDays(1),
                DateTime.Now.Add(formsAuthenticationSection.Timeout),
                false,
                bean.data as string,
                FormsAuthentication.FormsCookiePath);
            
            System.Configuration.ConfigurationManager.GetSection("system.web/authentication");
                
            
            string encTicket = FormsAuthentication.Encrypt(ticket);

            // Create the cookie.
            Response.Cookies.Add(new HttpCookie(FormsAuthentication.FormsCookieName, encTicket));

            string retunUrl = Request.QueryString["ReturnUrl"];

            if (retunUrl == null || Regex.IsMatch(retunUrl, "^/ETLAdm/?$"))
            {
                retunUrl = "~/Default.aspx";
            }
            Response.Redirect(retunUrl, true);
        }

        /// <summary>
        /// authenticate fail
        /// </summary>
        /// <param name="login"></param>
        /// <param name="bean"></param>
        private void AuthenticatedFailHandler(Login login, ResultBean bean, string name, string pwd)
        {   
            Page.ClientScript.RegisterStartupScript(this.GetType(), "error", string.Format( "alert('{0}');" , bean.message), true );
            logger.Warn(string.Format("{0}:{1} {2} at {3}", bean.message, name, "", Request.UserHostAddress));
        }

        protected void Page_Error(object sender, EventArgs e)
        {
            Exception ex = Server.GetLastError();
            logger.ErrorException(ex.Message, ex);
        }

    }
}
